package com.campusconnect.app;

import android.Manifest;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;

import androidx.core.app.NotificationManagerCompat;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import org.json.JSONArray;
import org.json.JSONException;

@CapacitorPlugin(name = "CallWatch")
public class CallWatchPlugin extends Plugin {
    private static final String PREFS = "campus_connect_call_watch";

    @PluginMethod
    public void start(PluginCall call) {
        String url = call.getString("url", "");
        String key = call.getString("publishableKey", "");
        String userId = call.getString("userId", "");
        String accessToken = call.getString("accessToken", "");
        String refreshToken = call.getString("refreshToken", "");
        if (url.isEmpty() || key.isEmpty() || userId.isEmpty() || accessToken.isEmpty()) {
            call.reject("A signed-in Campus Connect session is required to receive calls.");
            return;
        }

        android.content.SharedPreferences preferences = getContext()
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        android.content.SharedPreferences.Editor editor = preferences.edit()
            .putString("url", url)
            .putString("key", key)
            .putString("userId", userId)
            .putString("accessToken", accessToken)
            .putString("refreshToken", refreshToken)
            .putBoolean("pushLive", "1".equals(call.getString("pushLive", "")))
            .putBoolean("enabled", true);
        if (!preferences.contains("messageCursor")) {
            editor.putLong("messageCursor", System.currentTimeMillis() - 15000L);
        }
        editor.apply();
        startService(CallWatchService.ACTION_START);
        call.resolve(stateObject());
    }

    @PluginMethod
    public void state(PluginCall call) {
        call.resolve(stateObject());
    }

    @PluginMethod
    public void setListening(PluginCall call) {
        boolean listening = call.getBoolean("listening", false);
        getContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean("listening", listening).apply();
        startService(listening ? CallWatchService.ACTION_LISTENING : CallWatchService.ACTION_BACKGROUND);
        call.resolve();
    }

    @PluginMethod
    public void holdCall(PluginCall call) {
        boolean on = call.getBoolean("on", false);
        getContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean("holdCall", on).apply();
        startService(on ? CallWatchService.ACTION_HOLD : CallWatchService.ACTION_BACKGROUND);
        call.resolve();
    }

    @PluginMethod
    public void stop(PluginCall call) {
        getContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean("enabled", false)
            .putBoolean("pushLive", false)
            .remove("accessToken")
            .remove("refreshToken")
            .remove("messageCursor")
            .remove("notifiedMessageIds")
            .apply();
        getContext().stopService(new Intent(getContext(), CallWatchService.class));
        call.resolve();
    }

    @PluginMethod
    public void ring(PluginCall call) {
        boolean played = CallWatchService.ring(getContext());
        JSObject result = new JSObject();
        result.put("played", played);
        call.resolve(result);
    }

    @PluginMethod
    public void ringStop(PluginCall call) {
        CallWatchService.stopRinging();
        CallWatchService.dismissIncoming(getContext());
        call.resolve();
    }

    @PluginMethod
    public void answerTarget(PluginCall call) {
        String callId = take("answerTargetCallId");
        JSObject result = new JSObject();
        result.put("callId", callId);
        call.resolve(result);
    }

    @PluginMethod
    public void launchTarget(PluginCall call) {
        String callId = take("launchTargetCallId");
        String peerId = take("launchTargetPeerId");
        String chatPeerId = take("launchTargetChatPeerId");
        JSObject result = new JSObject();
        result.put("callId", callId);
        result.put("peerId", peerId);
        result.put("chatPeerId", chatPeerId);
        call.resolve(result);
    }

    @PluginMethod
    public void missedCalls(PluginCall call) {
        JSObject result = new JSObject();
        String saved = getContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString("missedCalls", "[]");
        try {
            result.put("calls", JSArray.from(new JSONArray(saved)));
        } catch (JSONException error) {
            result.put("calls", new JSArray());
        }
        call.resolve(result);
    }

    @PluginMethod
    public void clearMissed(PluginCall call) {
        getContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString("missedCalls", "[]").apply();
        call.resolve();
    }

    @PluginMethod
    public void setBadge(PluginCall call) {
        // Android launchers do not expose a portable badge-count API.
        call.resolve();
    }

    @PluginMethod
    public void askNotifications(PluginCall call) {
        openSettings(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            .putExtra(Settings.EXTRA_APP_PACKAGE, getContext().getPackageName()));
        call.resolve();
    }

    @PluginMethod
    public void askFullScreenIntents(PluginCall call) {
        if (Build.VERSION.SDK_INT >= 34) {
            openSettings(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT)
                .setData(Uri.parse("package:" + getContext().getPackageName())));
        }
        call.resolve();
    }

    @PluginMethod
    public void askBatteryExemption(PluginCall call) {
        PowerManager power = (PowerManager) getContext().getSystemService(Context.POWER_SERVICE);
        if (Build.VERSION.SDK_INT >= 23 && power != null
            && !power.isIgnoringBatteryOptimizations(getContext().getPackageName())) {
            openSettings(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                .setData(Uri.parse("package:" + getContext().getPackageName())));
        }
        call.resolve();
    }

    private void openSettings(Intent intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            getContext().startActivity(intent);
        } catch (Exception ignored) {
            // The Calls menu still reports the setting as unavailable.
        }
    }

    private void startService(String action) {
        Intent intent = new Intent(getContext(), CallWatchService.class).setAction(action);
        if (Build.VERSION.SDK_INT >= 26) {
            getContext().startForegroundService(intent);
        } else {
            getContext().startService(intent);
        }
    }

    private String take(String key) {
        android.content.SharedPreferences preferences = getContext()
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String value = preferences.getString(key, "");
        preferences.edit().remove(key).apply();
        return value == null ? "" : value;
    }

    private JSObject stateObject() {
        android.content.SharedPreferences prefs = getContext()
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        JSObject state = new JSObject();
        boolean enabled = prefs.getBoolean("enabled", false);
        boolean hasSession = !prefs.getString("accessToken", "").isEmpty();
        PowerManager power = (PowerManager) getContext().getSystemService(Context.POWER_SERVICE);
        boolean batteryExempt = Build.VERSION.SDK_INT < 23 || power == null
            || power.isIgnoringBatteryOptimizations(getContext().getPackageName());
        boolean fullScreen = true;
        if (Build.VERSION.SDK_INT >= 34) {
            NotificationManager manager = (NotificationManager) getContext()
                .getSystemService(Context.NOTIFICATION_SERVICE);
            fullScreen = manager != null && manager.canUseFullScreenIntent();
        }
        state.put("supported", true);
        state.put("enabled", enabled);
        state.put("hasSession", hasSession);
        state.put("running", CallWatchService.isRunning());
        state.put("notificationsAllowed", NotificationManagerCompat.from(getContext()).areNotificationsEnabled());
        state.put("batteryExempt", batteryExempt);
        state.put("fullScreenAllowed", fullScreen);
        return state;
    }
}
