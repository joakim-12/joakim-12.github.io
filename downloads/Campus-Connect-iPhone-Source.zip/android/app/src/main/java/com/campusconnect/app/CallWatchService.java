package com.campusconnect.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Base64;

import androidx.core.app.NotificationCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Keeps Campus Connect calls and messages reachable while its WebView is asleep. */
public class CallWatchService extends Service {
    public static final String ACTION_START = "com.campusconnect.app.callwatch.START";
    public static final String ACTION_STOP = "com.campusconnect.app.callwatch.STOP";
    public static final String ACTION_LISTENING = "com.campusconnect.app.callwatch.LISTENING";
    public static final String ACTION_BACKGROUND = "com.campusconnect.app.callwatch.BACKGROUND";
    public static final String ACTION_HOLD = "com.campusconnect.app.callwatch.HOLD";
    public static final String ACTION_ANSWER = "com.campusconnect.app.callwatch.ANSWER";
    public static final String ACTION_DECLINE = "com.campusconnect.app.callwatch.DECLINE";

    private static final String PREFS = "campus_connect_call_watch";
    private static final int SERVICE_NOTIFICATION_ID = 7401;
    private static final int INCOMING_NOTIFICATION_ID = 7402;
    private static final String SERVICE_CHANNEL = "campus-connect-call-watch";
    private static final String CALL_CHANNEL = "campus-connect-calls-v2";
    private static final String MESSAGE_CHANNEL = "campus-connect-messages-v2";
    private static final long POLL_MS = 5000L;
    private static final long OFFER_WINDOW_MS = 55000L;
    private static final long MESSAGE_LOOKBACK_MS = 15000L;
    private static final long TOKEN_REFRESH_MS = 5 * 60 * 1000L;
    private static volatile boolean running = false;
    private static volatile Ringtone ringtone;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private boolean pollQueued = false;

    private final Runnable pollLoop = new Runnable() {
        @Override public void run() {
            if (!running) return;
            if (!pollQueued) {
                pollQueued = true;
                worker.execute(() -> {
                    try {
                        pollCalls();
                    } catch (Exception error) {
                        android.util.Log.w("CampusConnectCallWatch", "Call check failed", error);
                    } finally {
                        try {
                            pollMessages();
                        } catch (Exception error) {
                            android.util.Log.w("CampusConnectCallWatch", "Message check failed", error);
                        } finally {
                            pollQueued = false;
                            handler.postDelayed(this, POLL_MS);
                        }
                    }
                });
            } else {
                handler.postDelayed(this, POLL_MS);
            }
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        running = true;
        createChannels();
        startForeground(SERVICE_NOTIFICATION_ID, serviceNotification());
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopWatch();
            return START_NOT_STICKY;
        }
        if (ACTION_LISTENING.equals(action) || ACTION_HOLD.equals(action)) {
            cancelIncoming();
            stopRinging();
        }
        if (ACTION_ANSWER.equals(action)) {
            handleAnswer();
        } else if (ACTION_DECLINE.equals(action)) {
            worker.execute(this::handleDecline);
        }
        handler.removeCallbacks(pollLoop);
        handler.post(pollLoop);
        return START_STICKY;
    }

    @Override public void onDestroy() {
        running = false;
        handler.removeCallbacksAndMessages(null);
        stopRinging();
        worker.shutdownNow();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    public static boolean isRunning() { return running; }

    public static boolean ring(Context context) {
        try {
            synchronized (CallWatchService.class) {
                if (ringtone != null && ringtone.isPlaying()) return true;
                Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
                if (uri == null) uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                if (uri == null) return false;
                ringtone = RingtoneManager.getRingtone(context.getApplicationContext(), uri);
                if (ringtone == null) return false;
                if (Build.VERSION.SDK_INT >= 21) {
                    ringtone.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build());
                }
                if (Build.VERSION.SDK_INT >= 28) ringtone.setLooping(true);
                ringtone.play();
                return true;
            }
        } catch (Exception error) {
            return false;
        }
    }

    public static void stopRinging() {
        synchronized (CallWatchService.class) {
            try {
                if (ringtone != null && ringtone.isPlaying()) ringtone.stop();
            } catch (Exception ignored) { }
            ringtone = null;
        }
    }

    public static void dismissIncoming(Context context) {
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) manager.cancel(INCOMING_NOTIFICATION_ID);
        android.content.SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String callId = prefs.getString("activeCallId", "");
        android.content.SharedPreferences.Editor editor = prefs.edit();
        if (!callId.isEmpty()) editor.putString("lastCallId", callId);
        editor.remove("activeCallId").remove("activePeerId").remove("activePeerName")
            .remove("activeCreatedAt").apply();
    }

    private android.content.SharedPreferences prefs() {
        return getSharedPreferences(PREFS, MODE_PRIVATE);
    }

    private void createChannels() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager == null) return;
        NotificationChannel serviceChannel = new NotificationChannel(
            SERVICE_CHANNEL, "Call availability", NotificationManager.IMPORTANCE_LOW);
        serviceChannel.setDescription("Keeps Campus Connect ready to receive calls and messages when closed.");
        manager.createNotificationChannel(serviceChannel);
        NotificationChannel callChannel = new NotificationChannel(
            CALL_CHANNEL, "Campus Connect calls", NotificationManager.IMPORTANCE_HIGH);
        callChannel.setDescription("Incoming voice and video calls.");
        callChannel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        callChannel.enableVibration(true);
        callChannel.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE),
            new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE).build());
        manager.createNotificationChannel(callChannel);
        NotificationChannel messageChannel = new NotificationChannel(
            MESSAGE_CHANNEL, "Campus Connect messages", NotificationManager.IMPORTANCE_HIGH);
        messageChannel.setDescription("New private messages.");
        messageChannel.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
        messageChannel.enableVibration(true);
        messageChannel.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),
            new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build());
        manager.createNotificationChannel(messageChannel);
    }

    private Notification serviceNotification() {
        return new NotificationCompat.Builder(this, SERVICE_CHANNEL)
            .setSmallIcon(getApplicationInfo().icon)
            .setContentTitle("Campus Connect is ready")
            .setContentText("Calls and messages can arrive while the app is closed.")
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setOngoing(true)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .build();
    }

    private void pollCalls() throws Exception {
        android.content.SharedPreferences p = prefs();
        if (!p.getBoolean("enabled", false) || p.getBoolean("listening", false)
            || p.getBoolean("holdCall", false)) return;
        String base = p.getString("url", "");
        String key = p.getString("key", "");
        String userId = p.getString("userId", "");
        String token = p.getString("accessToken", "");
        if (base.isEmpty() || key.isEmpty() || userId.isEmpty() || token.isEmpty()) return;
        token = refreshIfNeeded(base, key, token);

        String activeId = p.getString("activeCallId", "");
        if (!activeId.isEmpty()) {
            checkActiveCall(base, key, userId, token, activeId);
            return;
        }
        String cutoff = isoTime(System.currentTimeMillis() - OFFER_WINDOW_MS);
        String query = "/rest/v1/call_signals?select=id,call_id,sender_id,created_at"
            + "&recipient_id=eq." + enc(userId)
            + "&kind=eq.offer&created_at=gte." + enc(cutoff)
            + "&order=created_at.desc&limit=1";
        JSONArray offers = requestArray(base + query, key, token);
        if (offers.length() == 0) return;
        JSONObject offer = offers.getJSONObject(0);
        String callId = offer.optString("call_id", "");
        String peerId = offer.optString("sender_id", "");
        if (callId.isEmpty() || peerId.isEmpty()
            || callId.equals(p.getString("lastCallId", ""))) return;

        String peerName = loadPeerName(base, key, token, peerId);
        String peerAvatar = loadPeerAvatar(base, key, token, peerId);
        prefs().edit().putString("activeCallId", callId)
            .putString("activePeerId", peerId).putString("activePeerName", peerName).apply();
        showIncoming(callId, peerId, peerName, peerAvatar);
        ring(getApplicationContext());
    }

    /** Fallback for installations without working Firebase push configuration. */
    private void pollMessages() throws Exception {
        android.content.SharedPreferences p = prefs();
        if (!p.getBoolean("enabled", false) || p.getBoolean("listening", false)
            || p.getBoolean("holdCall", false) || p.getBoolean("pushLive", false)) return;
        String base = p.getString("url", "");
        String key = p.getString("key", "");
        String userId = p.getString("userId", "");
        String token = p.getString("accessToken", "");
        if (base.isEmpty() || key.isEmpty() || userId.isEmpty() || token.isEmpty()) return;
        token = refreshIfNeeded(base, key, token);

        long now = System.currentTimeMillis();
        long cursor = p.getLong("messageCursor", 0L);
        if (cursor == 0L) cursor = now - MESSAGE_LOOKBACK_MS;
        String query = "/rest/v1/messages?select=id,sender_id,created_at"
            + "&receiver_id=eq." + enc(userId)
            + "&is_read=eq.false&created_at=gte." + enc(isoTime(cursor))
            + "&order=created_at.desc&limit=10";
        JSONArray messages = requestArray(base + query, key, token);
        JSONArray savedIds = new JSONArray(p.getString("notifiedMessageIds", "[]"));
        java.util.LinkedHashSet<String> seen = new java.util.LinkedHashSet<>();
        for (int i = 0; i < savedIds.length(); i++) {
            String id = savedIds.optString(i, "");
            if (!id.isEmpty()) seen.add(id);
        }

        java.util.LinkedHashSet<String> newPeers = new java.util.LinkedHashSet<>();
        for (int i = messages.length() - 1; i >= 0; i--) {
            JSONObject message = messages.getJSONObject(i);
            String messageId = message.optString("id", "");
            String senderId = message.optString("sender_id", "");
            if (messageId.isEmpty() || senderId.isEmpty() || seen.contains(messageId)) continue;
            seen.add(messageId);
            newPeers.add(senderId);
        }
        for (String senderId : newPeers) {
            showMessage(senderId, loadPeerName(base, key, token, senderId));
        }

        while (seen.size() > 100) seen.remove(seen.iterator().next());
        JSONArray updatedIds = new JSONArray();
        for (String id : seen) updatedIds.put(id);
        prefs().edit().putLong("messageCursor", now - 5000L)
            .putString("notifiedMessageIds", updatedIds.toString()).apply();
    }

    private void showMessage(String peerId, String peerName) {
        Intent open = new Intent(this, MainActivity.class).setAction(Intent.ACTION_VIEW)
            .setData(Uri.parse("com.campusconnect.app://message?chat=" + enc(peerId)))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pending = PendingIntent.getActivity(this,
            8100 + (peerId.hashCode() & 0x7fffffff) % 100000, open,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification notification = new NotificationCompat.Builder(this, MESSAGE_CHANNEL)
            .setSmallIcon(getApplicationInfo().icon)
            .setContentTitle(peerName == null || peerName.trim().isEmpty() ? "New message" : peerName)
            .setContentText("Open Campus Connect to read your message.")
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setContentIntent(pending)
            .setAutoCancel(true)
            .build();
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) manager.notify(8100 + (peerId.hashCode() & 0x7fffffff) % 100000, notification);
    }

    private void checkActiveCall(String base, String key, String userId, String token, String callId)
        throws Exception {
        String query = "/rest/v1/call_signals?select=kind,created_at"
            + "&recipient_id=eq." + enc(userId)
            + "&call_id=eq." + enc(callId)
            + "&order=created_at.desc&limit=5";
        JSONArray signals = requestArray(base + query, key, token);
        boolean finished = false;
        for (int i = 0; i < signals.length(); i++) {
            String kind = signals.getJSONObject(i).optString("kind", "");
            if ("end".equals(kind) || "reject".equals(kind) || "busy".equals(kind)
                || "answer".equals(kind)) {
                finished = true;
                break;
            }
        }
        long offeredAt = timestampMillis(prefs().getString("activeCreatedAt", ""));
        if (finished || (offeredAt > 0 && System.currentTimeMillis() - offeredAt > OFFER_WINDOW_MS)) {
            if (!finished) addMissedCall(callId, prefs().getString("activePeerId", ""),
                prefs().getString("activePeerName", "Student"));
            clearIncoming();
        }
    }

    private String loadPeerName(String base, String key, String token, String peerId) {
        try {
            JSONArray rows = requestArray(base + "/rest/v1/profiles?select=full_name,username&id=eq."
                + enc(peerId) + "&limit=1", key, token);
            if (rows.length() == 0) return "Campus Connect member";
            JSONObject row = rows.getJSONObject(0);
            String name = row.optString("full_name", "").trim();
            return name.isEmpty() ? row.optString("username", "Campus Connect member") : name;
        } catch (Exception error) {
            return "Campus Connect member";
        }
    }

    private String loadPeerAvatar(String base, String key, String token, String peerId) {
        try {
            JSONArray rows = requestArray(base + "/rest/v1/profiles?select=avatar_url&id=eq."
                + enc(peerId) + "&limit=1", key, token);
            return rows.length() == 0 ? "" : rows.getJSONObject(0).optString("avatar_url", "");
        } catch (Exception error) {
            return "";
        }
    }

    private Bitmap downloadCallerAvatar(String avatarUrl) {
        if (avatarUrl == null || !avatarUrl.startsWith("https://")) return null;
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(avatarUrl).openConnection();
            connection.setConnectTimeout(2500);
            connection.setReadTimeout(2500);
            connection.setInstanceFollowRedirects(true);
            if (connection.getContentLength() > 2_000_000) return null;
            try (InputStream input = connection.getInputStream();
                 ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[8192];
                int total = 0;
                int count;
                while ((count = input.read(buffer)) != -1) {
                    total += count;
                    if (total > 2_000_000) return null;
                    output.write(buffer, 0, count);
                }
                byte[] bytes = output.toByteArray();
                BitmapFactory.Options bounds = new BitmapFactory.Options();
                bounds.inJustDecodeBounds = true;
                BitmapFactory.decodeByteArray(bytes, 0, bytes.length, bounds);
                int sample = 1;
                while (bounds.outWidth / sample > 256 || bounds.outHeight / sample > 256) sample *= 2;
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inSampleSize = sample;
                return BitmapFactory.decodeByteArray(bytes, 0, bytes.length, options);
            }
        } catch (Exception error) {
            return null;
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private void showIncoming(String callId, String peerId, String peerName, String peerAvatarUrl) {
        prefs().edit().putString("activeCreatedAt", isoTime(System.currentTimeMillis()))
            .putString("launchTargetCallId", callId).putString("launchTargetPeerId", peerId).apply();
        Intent open = new Intent(this, MainActivity.class).setAction(Intent.ACTION_VIEW)
            .setData(Uri.parse("com.campusconnect.app://call?call=" + enc(callId) + "&peer=" + enc(peerId)))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent fullScreen = PendingIntent.getActivity(this, 7402, open,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent answer = new Intent(this, CallWatchService.class).setAction(ACTION_ANSWER)
            .putExtra("callId", callId).putExtra("peerId", peerId)
            .setData(Uri.parse("campusconnect://answer/" + callId));
        PendingIntent answerPending = PendingIntent.getService(this, 7403, answer,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent decline = new Intent(this, CallWatchService.class).setAction(ACTION_DECLINE)
            .putExtra("callId", callId).putExtra("peerId", peerId)
            .setData(Uri.parse("campusconnect://decline/" + callId));
        PendingIntent declinePending = PendingIntent.getService(this, 7404, decline,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Bitmap callerAvatar = downloadCallerAvatar(peerAvatarUrl);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CALL_CHANNEL)
            .setSmallIcon(getApplicationInfo().icon)
            .setContentTitle("Incoming Campus Connect call")
            .setContentText(peerName + " is calling")
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setFullScreenIntent(fullScreen, true)
            .setContentIntent(fullScreen)
            .setOngoing(true)
            .setAutoCancel(false)
            .addAction(android.R.drawable.sym_action_call, "Answer", answerPending)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Decline", declinePending);
        if (callerAvatar != null) builder.setLargeIcon(callerAvatar);
        Notification notification = builder.build();
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) manager.notify(INCOMING_NOTIFICATION_ID, notification);
    }

    private void handleAnswer() {
        String callId = getIntentCallId();
        String peerId = prefs().getString("activePeerId", "");
        if (callId.isEmpty()) return;
        prefs().edit().putString("answerTargetCallId", callId)
            .putString("launchTargetCallId", callId)
            .putString("launchTargetPeerId", peerId)
            .putString("lastCallId", callId).apply();
        stopRinging();
        cancelIncoming();
        Intent open = new Intent(this, MainActivity.class).setAction(Intent.ACTION_VIEW)
            .setData(Uri.parse("com.campusconnect.app://call?call=" + enc(callId) + "&peer=" + enc(peerId)))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(open);
        prefs().edit().remove("activeCallId").remove("activePeerId").remove("activePeerName")
            .remove("activeCreatedAt").apply();
    }

    private String getIntentCallId() {
        // The notification action identifies the active offer. The most recent
        // one is authoritative, so no URL or account data is accepted from UI.
        return prefs().getString("activeCallId", "");
    }

    private void handleDecline() {
        String callId = getIntentCallId();
        String peerId = prefs().getString("activePeerId", "");
        String base = prefs().getString("url", "");
        String key = prefs().getString("key", "");
        String token = prefs().getString("accessToken", "");
        String userId = prefs().getString("userId", "");
        if (!callId.isEmpty() && !base.isEmpty() && !token.isEmpty()) {
            try {
                JSONObject signal = new JSONObject();
                signal.put("call_id", callId);
                signal.put("sender_id", userId);
                signal.put("recipient_id", peerId);
                signal.put("kind", "reject");
                signal.put("payload", new JSONObject());
                request(base + "/rest/v1/call_signals", key, token, "POST", signal.toString());
            } catch (Exception error) {
                android.util.Log.w("CampusConnectCallWatch", "Could not decline call", error);
            }
        }
        prefs().edit().putString("lastCallId", callId).apply();
        clearIncoming();
    }

    private void addMissedCall(String callId, String peerId, String peerName) {
        try {
            JSONArray calls = new JSONArray(prefs().getString("missedCalls", "[]"));
            JSONObject item = new JSONObject();
            item.put("callId", callId);
            item.put("peerId", peerId);
            item.put("peerName", peerName);
            item.put("createdAt", System.currentTimeMillis());
            calls.put(item);
            while (calls.length() > 100) calls.remove(0);
            prefs().edit().putString("missedCalls", calls.toString()).apply();
        } catch (Exception ignored) { }
    }

    private void clearIncoming() {
        stopRinging();
        cancelIncoming();
        String active = prefs().getString("activeCallId", "");
        android.content.SharedPreferences.Editor editor = prefs().edit();
        if (!active.isEmpty()) editor.putString("lastCallId", active);
        editor.remove("activeCallId").remove("activePeerId")
            .remove("activePeerName").remove("activeCreatedAt").apply();
    }

    private void cancelIncoming() {
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) manager.cancel(INCOMING_NOTIFICATION_ID);
    }

    private void stopWatch() {
        prefs().edit().putBoolean("enabled", false).remove("accessToken")
            .remove("refreshToken").apply();
        clearIncoming();
        running = false;
        handler.removeCallbacksAndMessages(null);
        stopForeground(true);
        stopSelf();
    }

    private String refreshIfNeeded(String base, String key, String token) throws Exception {
        long expires = jwtExpiry(token);
        if (expires == 0 || expires - System.currentTimeMillis() > TOKEN_REFRESH_MS) return token;
        String refresh = prefs().getString("refreshToken", "");
        if (refresh.isEmpty()) return token;
        JSONObject body = new JSONObject();
        body.put("refresh_token", refresh);
        JSONObject response = new JSONObject(request(base + "/auth/v1/token?grant_type=refresh_token",
            key, key, "POST", body.toString()));
        String nextAccess = response.optString("access_token", "");
        String nextRefresh = response.optString("refresh_token", refresh);
        if (!nextAccess.isEmpty()) {
            prefs().edit().putString("accessToken", nextAccess)
                .putString("refreshToken", nextRefresh).apply();
            return nextAccess;
        }
        return token;
    }

    private long jwtExpiry(String token) {
        try {
            String[] parts = token.split("\\.");
            if (parts.length < 2) return 0;
            byte[] bytes = Base64.decode(parts[1], Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
            long seconds = new JSONObject(new String(bytes, StandardCharsets.UTF_8)).optLong("exp", 0);
            return seconds * 1000L;
        } catch (Exception ignored) { return 0; }
    }

    private JSONArray requestArray(String url, String key, String token) throws Exception {
        return new JSONArray(request(url, key, token, "GET", null));
    }

    private String request(String url, String key, String token, String method, String body) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
        connection.setRequestMethod(method);
        connection.setConnectTimeout(7000);
        connection.setReadTimeout(7000);
        connection.setRequestProperty("apikey", key);
        connection.setRequestProperty("Authorization", "Bearer " + token);
        connection.setRequestProperty("Accept", "application/json");
        if (body != null) {
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("Prefer", "return=minimal");
            try (OutputStream output = connection.getOutputStream()) {
                output.write(body.getBytes(StandardCharsets.UTF_8));
            }
        }
        int code = connection.getResponseCode();
        InputStream stream = code >= 400 ? connection.getErrorStream() : connection.getInputStream();
        StringBuilder text = new StringBuilder();
        if (stream != null) {
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) text.append(line);
            }
        }
        connection.disconnect();
        if (code < 200 || code >= 300) throw new IllegalStateException("Supabase request returned " + code);
        return text.toString();
    }

    private String isoTime(long millis) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
        format.setTimeZone(TimeZone.getTimeZone("UTC"));
        return format.format(new Date(millis));
    }

    private long timestampMillis(String value) {
        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
            format.setTimeZone(TimeZone.getTimeZone("UTC"));
            return format.parse(value).getTime();
        } catch (Exception ignored) { return 0; }
    }

    private String enc(String value) {
        try { return URLEncoder.encode(value, "UTF-8"); }
        catch (Exception ignored) { return value; }
    }
}
