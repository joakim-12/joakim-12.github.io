package com.campusconnect.app;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(CallWatchPlugin.class);
        registerPlugin(MessageTonePlugin.class);
        super.onCreate(savedInstanceState);
        applyIncomingCallWindow(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        applyIncomingCallWindow(intent);
    }

    private void applyIncomingCallWindow(Intent intent) {
        if (intent == null || !Intent.ACTION_VIEW.equals(intent.getAction()) || intent.getData() == null) return;
        if ("message".equals(intent.getData().getHost())) {
            String peerId = intent.getData().getQueryParameter("chat");
            if (peerId != null && peerId.matches("(?i)[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}")) {
                getSharedPreferences("campus_connect_call_watch", MODE_PRIVATE)
                    .edit().putString("launchTargetChatPeerId", peerId).apply();
            }
            return;
        }
        if (!"call".equals(intent.getData().getHost())) return;
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        }
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }
}
