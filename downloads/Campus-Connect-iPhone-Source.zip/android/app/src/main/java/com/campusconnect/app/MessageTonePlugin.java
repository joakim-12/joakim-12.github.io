package com.campusconnect.app;

import android.media.AudioAttributes;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "MessageTone")
public class MessageTonePlugin extends Plugin {
    private Ringtone currentTone;

    @PluginMethod
    public void play(PluginCall call) {
        JSObject result = new JSObject();
        try {
            Uri sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            if (sound == null) {
                result.put("played", false);
                call.resolve(result);
                return;
            }

            if (currentTone != null && currentTone.isPlaying()) currentTone.stop();
            currentTone = RingtoneManager.getRingtone(getContext().getApplicationContext(), sound);
            if (currentTone == null) {
                result.put("played", false);
                call.resolve(result);
                return;
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                currentTone.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build());
            }
            currentTone.play();
            result.put("played", true);
        } catch (Exception error) {
            result.put("played", false);
        }
        call.resolve(result);
    }
}
