# Supabase setup for Campus Connect

Campus Connect uses Supabase for account sign-in, profile data, avatar storage, and incoming-call signaling. The mobile package cannot connect until it is built with the real project settings.

## 1. Configure the app

In the Supabase dashboard, open **Project Settings → API** and copy the **Project URL** and **publishable key** (or legacy anon key). In the project root, create `.env` from `.env.example` and set:

```dotenv
VITE_SUPABASE_URL=https://YOUR_REAL_PROJECT_ID.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=YOUR_REAL_PUBLISHABLE_OR_ANON_KEY
```

Do not use a service-role or secret key in the app. It is not safe to embed in Android or web assets. Run `npm run build` and `npx cap sync android` after configuring `.env`, then build and sign the Android release.

## 2. Configure authentication

- Enable email sign-in in **Authentication → Sign In / Providers**.
- For email/password accounts, users sign in with the password they set for their **Campus Connect account**. This is not automatically their Gmail, Outlook, or other mailbox password. If they forgot their Campus Connect password, use the app's **Forgot your password?** flow.
- Set the Supabase Site URL to the deployed app URL. Add that URL and the native callback `com.campusconnect.app://auth/callback` to the allowed redirect URLs.
- Configure a real SMTP sender in **Authentication → SMTP Settings** before relying on email confirmation and password-reset messages. Supabase's built-in sender is rate-limited.
- Phone/password registration uses Supabase Phone Auth: the person verifies the number with an SMS code during registration, then signs in with that phone number and the password they chose. Keep phone confirmation enabled. Turn on **Phone** under **Authentication → Sign In / Providers** and configure a supported SMS provider (for example Twilio, MessageBird, or Vonage) under the phone provider settings. Do not disable email confirmation to make phone registration work. Supabase test phone numbers can be used during development, but real users need a working SMS sender.
- Registration-number login also needs the included database migration and the `sign-in-by-identifier` Edge Function deployed through the authenticated Supabase CLI (`npm run auth:deploy`).

## 3. Configure storage and calls

The avatar bucket and policies are already applied to the configured Supabase project. The SQL at the end of `public/database/RUN_ALL.sql` creates the public `avatars` bucket, limits uploads to 10 MB image files, lets signed-in users upload only into their own user-ID folder, and allows public avatar reads. The bucket's public read permission exposes profile images to anyone with the URL.

Incoming Campus Connect calls use the `call_signals` table and its existing authenticated recipient policies from `RUN_ALL.sql`. Android displays Answer and Decline actions while the app is asleep; the recipient must allow notifications, full-screen call alerts, and battery background activity on the device. Android may still restrict background activity under user or manufacturer power settings.

## 4. Build the Android app

Use JDK 21 and Android SDK 36. Configure `.env` first, then:

```powershell
npm install
npm run build
npx cap sync android
cd android
.\gradlew.bat assembleRelease
```

The release APK must be signed with the same private key for future updates to install over this version. Keep the signing key and its password private and backed up separately from the APK.

## What the current package still needs

The production package is connected to the configured project, and avatar storage is set up. Before phone registration can send real codes, configure an SMS provider and enable Phone Auth in the Supabase dashboard. Email confirmation is currently enabled, so new email accounts must confirm their address. Registration-number login also needs its database migration and Edge Function. Background push calls still need Firebase project configuration, and reliable calls across restrictive mobile networks need TURN credentials. The app's publishable key cannot perform these administrator actions.
