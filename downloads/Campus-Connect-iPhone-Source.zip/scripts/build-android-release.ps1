param(
    [Parameter(Mandatory = $true)]
    [string]$KeystorePath,
    [Parameter(Mandatory = $true)]
    [string]$PasswordFile
)

$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$keystore = (Resolve-Path -LiteralPath $KeystorePath).Path
$passwordPath = (Resolve-Path -LiteralPath $PasswordFile).Path
$password = (Get-Content -LiteralPath $passwordPath -Raw).Trim()

if (-not $password) {
    throw 'The Android signing password file is empty.'
}

$env:CC_ANDROID_KEYSTORE = $keystore
$env:CC_ANDROID_STORE_PASSWORD = $password
$env:CC_ANDROID_KEY_ALIAS = 'campus-connect-release'
$env:CC_ANDROID_KEY_PASSWORD = $password

Push-Location $projectRoot
try {
    & npm run build
    if ($LASTEXITCODE -ne 0) {
        throw "Web app build failed with exit code $LASTEXITCODE."
    }
    & npx cap sync android
    if ($LASTEXITCODE -ne 0) {
        throw "Capacitor Android sync failed with exit code $LASTEXITCODE."
    }

    Push-Location (Join-Path $projectRoot 'android')
    try {
    & .\gradlew.bat assembleRelease
    if ($LASTEXITCODE -ne 0) {
        throw "Android release build failed with exit code $LASTEXITCODE."
    }
    } finally {
        Pop-Location
    }
} finally {
    Remove-Item Env:\CC_ANDROID_KEYSTORE -ErrorAction SilentlyContinue
    Remove-Item Env:\CC_ANDROID_STORE_PASSWORD -ErrorAction SilentlyContinue
    Remove-Item Env:\CC_ANDROID_KEY_ALIAS -ErrorAction SilentlyContinue
    Remove-Item Env:\CC_ANDROID_KEY_PASSWORD -ErrorAction SilentlyContinue
    Pop-Location
}

$apk = Join-Path $projectRoot 'android\app\build\outputs\apk\release\app-release.apk'
if (-not (Test-Path -LiteralPath $apk)) {
    throw 'Gradle completed without producing the signed release APK.'
}

Write-Output "Signed Android APK: $apk"
