import { createClient } from "npm:@supabase/supabase-js@2.117.3";

const corsHeaders = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-client-info",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const encoder = new TextEncoder();
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const FCM_SCOPE = "https://www.googleapis.com/auth/firebase.messaging";
const FCM_AUDIENCE = "https://oauth2.googleapis.com/token";
const FCM_ENDPOINT = "https://fcm.googleapis.com/v1/projects";

type ServiceAccount = {
    project_id: string;
    client_email: string;
    private_key: string;
};

type AlertRequest = {
    to_user?: unknown;
    kind?: unknown;
    call?: unknown;
    video?: unknown;
};

let cachedAccessToken = "";
let cachedAccessTokenExpiresAt = 0;
let importedSigningKey: CryptoKey | null = null;

function json(body: Record<string, unknown>, status = 200): Response {
    return new Response(JSON.stringify(body), {
        status,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
}

function base64Url(bytes: Uint8Array): string {
    let binary = "";
    for (const byte of bytes) binary += String.fromCharCode(byte);
    return btoa(binary).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
}

function encodeJson(value: Record<string, unknown>): string {
    return base64Url(encoder.encode(JSON.stringify(value)));
}

function decodePem(privateKey: string): Uint8Array {
    const body = privateKey
        .replace(/\\n/g, "\n")
        .replace(/-----BEGIN PRIVATE KEY-----/g, "")
        .replace(/-----END PRIVATE KEY-----/g, "")
        .replace(/\s/g, "");
    const binary = atob(body);
    return Uint8Array.from(binary, character => character.charCodeAt(0));
}

async function signingKey(account: ServiceAccount): Promise<CryptoKey> {
    if (importedSigningKey) return importedSigningKey;
    importedSigningKey = await crypto.subtle.importKey(
        "pkcs8",
        decodePem(account.private_key),
        { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
        false,
        ["sign"],
    );
    return importedSigningKey;
}

async function googleAccessToken(account: ServiceAccount): Promise<string> {
    if (cachedAccessToken && Date.now() < cachedAccessTokenExpiresAt) return cachedAccessToken;

    const now = Math.floor(Date.now() / 1000);
    const header = encodeJson({ alg: "RS256", typ: "JWT" });
    const claims = encodeJson({
        iss: account.client_email,
        scope: FCM_SCOPE,
        aud: FCM_AUDIENCE,
        iat: now,
        exp: now + 3600,
    });
    const unsigned = `${header}.${claims}`;
    const signature = await crypto.subtle.sign(
        "RSASSA-PKCS1-v1_5",
        await signingKey(account),
        encoder.encode(unsigned),
    );
    const assertion = `${unsigned}.${base64Url(new Uint8Array(signature))}`;
    const response = await fetch(FCM_AUDIENCE, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
            grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
            assertion,
        }),
        signal: AbortSignal.timeout(10000),
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok || typeof result.access_token !== "string") {
        console.error("Google did not issue an FCM access token", response.status);
        throw new Error("Push delivery is not configured correctly.");
    }
    cachedAccessToken = result.access_token;
    cachedAccessTokenExpiresAt = Date.now() + Math.max(60, Number(result.expires_in || 3600) - 60) * 1000;
    return cachedAccessToken;
}

function loadServiceAccount(): ServiceAccount {
    const raw = Deno.env.get("FIREBASE_SERVICE_ACCOUNT") || "";
    let account: Partial<ServiceAccount>;
    try {
        account = JSON.parse(raw);
    } catch {
        throw new Error("Push delivery is not configured correctly.");
    }
    if (!account.project_id || !account.client_email || !account.private_key) {
        throw new Error("Push delivery is not configured correctly.");
    }
    return account as ServiceAccount;
}

async function isAuthorizedAlert(
    admin: ReturnType<typeof createClient>,
    senderId: string,
    recipientId: string,
    kind: "call" | "message",
    callId: string,
): Promise<boolean> {
    const recent = new Date(Date.now() - (kind === "call" ? 60000 : 5 * 60_000)).toISOString();
    const query = kind === "call"
        ? admin.from("call_signals")
            .select("id")
            .eq("sender_id", senderId)
            .eq("recipient_id", recipientId)
            .eq("call_id", callId)
            .eq("kind", "offer")
            .gte("created_at", recent)
        : admin.from("messages")
            .select("id")
            .eq("sender_id", senderId)
            .eq("receiver_id", recipientId)
            .gte("created_at", recent);

    const { data, error } = await query.order("created_at", { ascending: false }).limit(1).maybeSingle();
    if (error) {
        console.error("Could not verify push source", error.code);
        return false;
    }
    return Boolean(data);
}

async function sendToDevice(
    accessToken: string,
    account: ServiceAccount,
    deviceToken: string,
    data: Record<string, string>,
): Promise<{ ok: boolean; unregistered: boolean }> {
    const isCall = data.kind === "call";
    const message: Record<string, unknown> = {
        token: deviceToken,
        data,
        android: {
            priority: "HIGH",
            ttl: "60s",
            ...(isCall ? {} : {
                notification: {
                    channel_id: "campus-connect-messages-v2",
                    sound: "default",
                },
            }),
        },
    };
    if (!isCall) {
        message.notification = {
            title: "Campus Connect",
            body: "You have a new message",
        };
    }

    const response = await fetch(`${FCM_ENDPOINT}/${encodeURIComponent(account.project_id)}/messages:send`, {
        method: "POST",
        headers: {
            Authorization: `Bearer ${accessToken}`,
            "Content-Type": "application/json",
        },
        body: JSON.stringify({ message }),
        signal: AbortSignal.timeout(10000),
    });
    if (response.ok) return { ok: true, unregistered: false };
    const body = await response.text();
    const unregistered = response.status === 404 || /UNREGISTERED|registration-token-not-registered/i.test(body);
    if (!unregistered) console.error("FCM rejected a device alert", response.status);
    return { ok: false, unregistered };
}

Deno.serve(async request => {
    if (request.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
    if (request.method !== "POST") return json({ error: "Method not allowed." }, 405);

    try {
        const authorization = request.headers.get("Authorization");
        if (!authorization?.startsWith("Bearer ")) return json({ error: "Sign in to send alerts." }, 401);
        const body = await request.json() as AlertRequest;
        const recipientId = String(body.to_user || "");
        const kind = body.kind === "call" ? "call" : body.kind === "message" ? "message" : "";
        const callId = String(body.call || "");
        if (!UUID.test(recipientId) || !kind || (kind === "call" && !UUID.test(callId))) {
            return json({ error: "This alert request is invalid." }, 400);
        }

        const url = Deno.env.get("SUPABASE_URL") || "";
        const anonKey = Deno.env.get("SUPABASE_ANON_KEY") || Deno.env.get("SUPABASE_PUBLISHABLE_KEY") || "";
        const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";
        if (!url || !anonKey || !serviceRoleKey) {
            console.error("Supabase function secrets are incomplete");
            return json({ error: "Push delivery is not configured correctly." }, 503);
        }

        const userClient = createClient(url, anonKey, {
            global: { headers: { Authorization: authorization } },
            auth: { autoRefreshToken: false, persistSession: false },
        });
        const { data: userData, error: userError } = await userClient.auth.getUser();
        if (userError || !userData.user) return json({ error: "Sign in to send alerts." }, 401);

        const admin = createClient(url, serviceRoleKey, {
            auth: { autoRefreshToken: false, persistSession: false },
        });
        if (userData.user.id === recipientId) return json({ error: "You cannot alert yourself." }, 400);
        if (!await isAuthorizedAlert(admin, userData.user.id, recipientId, kind, callId)) {
            return json({ error: "There is no recent message or call to notify about." }, 403);
        }

        const { data: devices, error: deviceError } = await admin
            .from("device_tokens")
            .select("token")
            .eq("user_id", recipientId)
            .eq("platform", "android");
        if (deviceError) {
            console.error("Could not find Android devices for push", deviceError.code);
            return json({ error: "Push delivery is not configured correctly." }, 503);
        }
        const tokens = [...new Set((devices || []).map(device => String(device.token || "")).filter(Boolean))];
        if (!tokens.length) return json({ delivered: 0 });

        const account = loadServiceAccount();
        const accessToken = await googleAccessToken(account);
        const data = {
            kind,
            from: userData.user.id,
            thread: userData.user.id,
            call: kind === "call" ? callId : "",
            video: kind === "call" && body.video === true ? "true" : "false",
        };
        const results = await Promise.all(tokens.map(token => sendToDevice(accessToken, account, token, data)));
        const invalidTokens = tokens.filter((_token, index) => results[index].unregistered);
        if (invalidTokens.length) {
            await admin.from("device_tokens").delete().in("token", invalidTokens);
        }
        const delivered = results.filter(result => result.ok).length;
        if (!delivered && results.some(result => !result.unregistered)) {
            return json({ error: "No alert could be delivered." }, 502);
        }
        return json({ delivered });
    } catch (error) {
        console.error("Push delivery failed", error instanceof Error ? error.message : "unknown error");
        return json({ error: error instanceof Error ? error.message : "Push delivery failed." }, 500);
    }
});
