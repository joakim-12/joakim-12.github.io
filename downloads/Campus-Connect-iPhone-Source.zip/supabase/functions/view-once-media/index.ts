import { createClient } from "npm:@supabase/supabase-js@2";

const projectUrl = Deno.env.get("SUPABASE_URL") ?? "";
const anonKey = Deno.env.get("SUPABASE_ANON_KEY") ?? "";
const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
const viewOnceMarker = "👻 View once\n";
const allowedOrigins = new Set([
    "https://joakim-12.github.io",
    "http://localhost:5173",
    "http://127.0.0.1:5173",
    "http://localhost",
    "https://localhost",
    "capacitor://localhost",
    "ionic://localhost"
]);

function corsHeaders(origin: string | null): HeadersInit {
    const allowedOrigin = origin && allowedOrigins.has(origin)
        ? origin
        : "https://joakim-12.github.io";
    return {
        "Access-Control-Allow-Origin": allowedOrigin,
        "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-client-info",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Expose-Headers": "Content-Type",
        "Vary": "Origin"
    };
}

function jsonResponse(origin: string | null, status: number, code: string, message: string) {
    return new Response(JSON.stringify({ code, message }), {
        status,
        headers: {
            ...corsHeaders(origin),
            "Content-Type": "application/json; charset=utf-8",
            "Cache-Control": "no-store, private"
        }
    });
}

Deno.serve(async (request: Request) => {
    const origin = request.headers.get("Origin");
    if (origin && origin !== "null" && !allowedOrigins.has(origin)) {
        return jsonResponse(origin, 403, "ORIGIN_NOT_ALLOWED", "This app origin is not allowed.");
    }
    if (request.method === "OPTIONS") {
        return new Response(null, { status: 204, headers: corsHeaders(origin) });
    }
    if (request.method !== "POST") {
        return jsonResponse(origin, 405, "METHOD_NOT_ALLOWED", "Use POST to open view-once media.");
    }
    if (!projectUrl || !anonKey || !serviceRoleKey) {
        return jsonResponse(origin, 500, "SERVER_NOT_CONFIGURED", "View-once media is not configured.");
    }

    const authorization = request.headers.get("Authorization") ?? "";
    if (!authorization.startsWith("Bearer ")) {
        return jsonResponse(origin, 401, "SIGN_IN_REQUIRED", "Sign in to open this media.");
    }

    const userClient = createClient(projectUrl, anonKey, {
        auth: { autoRefreshToken: false, persistSession: false },
        global: { headers: { Authorization: authorization } }
    });
    const adminClient = createClient(projectUrl, serviceRoleKey, {
        auth: { autoRefreshToken: false, persistSession: false }
    });
    const { data: authData, error: authError } = await userClient.auth.getUser();
    const user = authData.user;
    if (authError || !user) {
        return jsonResponse(origin, 401, "SIGN_IN_REQUIRED", "Sign in to open this media.");
    }

    let body: { messageId?: unknown };
    try {
        body = await request.json();
    } catch {
        return jsonResponse(origin, 400, "INVALID_REQUEST", "A message ID is required.");
    }
    const messageId = typeof body.messageId === "string" ? body.messageId : "";
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(messageId)) {
        return jsonResponse(origin, 400, "INVALID_REQUEST", "A valid message ID is required.");
    }

    const { data: message, error: messageError } = await userClient
        .from("messages")
        .select("id, sender_id, receiver_id, content, media_url, deleted_for_everyone")
        .eq("id", messageId)
        .maybeSingle();
    if (messageError) {
        console.error("Could not read the view-once message:", messageError.message);
        return jsonResponse(origin, 500, "MESSAGE_LOOKUP_FAILED", "This media could not be opened.");
    }
    if (!message || message.receiver_id !== user.id || message.deleted_for_everyone ||
        !String(message.content ?? "").startsWith(viewOnceMarker)) {
        return jsonResponse(origin, 404, "MEDIA_NOT_FOUND", "This view-once media is unavailable.");
    }

    const mediaUrl = String(message.media_url ?? "");
    let bucket: string;
    let path: string;
    if (mediaUrl.startsWith("view-once-media:")) {
        bucket = "campus-view-once-media";
        path = mediaUrl.slice("view-once-media:".length);
    } else if (mediaUrl.startsWith("private-media:")) {
        // Allow older view-once messages sent before the dedicated bucket existed.
        bucket = "campus-private-media";
        path = mediaUrl.slice("private-media:".length);
    } else {
        return jsonResponse(origin, 404, "MEDIA_NOT_FOUND", "This view-once media is unavailable.");
    }
    if (!path.startsWith(`${message.sender_id}/`) || path.includes("..") || path.includes("\\")) {
        return jsonResponse(origin, 404, "MEDIA_NOT_FOUND", "This view-once media is unavailable.");
    }

    const { data: existingOpen, error: openLookupError } = await adminClient
        .from("view_once_opens")
        .select("message_id")
        .eq("message_id", message.id)
        .maybeSingle();
    if (openLookupError) {
        console.error("Could not check view-once state:", openLookupError.message);
        return jsonResponse(origin, 503, "VIEW_ONCE_NOT_READY", "View-once is not ready on this server yet.");
    }
    if (existingOpen) {
        return jsonResponse(origin, 409, "ALREADY_OPENED", "This media has already been opened.");
    }

    const { data: file, error: downloadError } = await adminClient.storage.from(bucket).download(path);
    if (downloadError || !file || (!file.type.startsWith("image/") && !file.type.startsWith("video/"))) {
        console.error("Could not download view-once media:", downloadError?.message ?? "Unsupported media type");
        return jsonResponse(origin, 404, "MEDIA_NOT_FOUND", "This view-once media is unavailable.");
    }

    const { error: claimError } = await adminClient
        .from("view_once_opens")
        .insert({ message_id: message.id, viewer_id: user.id });
    if (claimError?.code === "23505") {
        return jsonResponse(origin, 409, "ALREADY_OPENED", "This media has already been opened.");
    }
    if (claimError) {
        console.error("Could not record view-once open:", claimError.message);
        return jsonResponse(origin, 503, "VIEW_ONCE_NOT_READY", "View-once is not ready on this server yet.");
    }

    return new Response(file, {
        status: 200,
        headers: {
            ...corsHeaders(origin),
            "Content-Type": file.type,
            "Content-Length": String(file.size),
            "Content-Disposition": "inline",
            "Cache-Control": "no-store, private, max-age=0",
            "Pragma": "no-cache",
            "X-Content-Type-Options": "nosniff"
        }
    });
});
