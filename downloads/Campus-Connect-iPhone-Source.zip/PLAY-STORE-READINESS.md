# Campus Connect — Google Play release readiness

## Prepared in this workspace

- Added the Capacitor Android project for application ID `com.campusconnect.app`.
- Set Android compile and target SDK to API 36.
- Built the shared web application and synced it into the Android project.
- Added Vite legacy bundles and polyfills for older Android System WebView versions.
- Added a native Android call watcher with lock-screen call notifications and Answer/Decline actions.
- Added a public `avatars` bucket and per-user upload policy to `public/database/RUN_ALL.sql`.
- Built and signed the v1.55 Android release APK with the certificate matching the existing v1.53 debug install, so it can update that install in place. The APK is release-mode and not debuggable.
- Added `SUPABASE-SETUP.md` with backend setup instructions.

**This is not ready for Play upload.** The compatibility APK is signed with an Android debug certificate so it matches the existing sideloaded app; do not publish it to Play. The source has no real Supabase configuration. Sign-in, avatar uploads, and background calls cannot connect until a real Supabase project is configured. Play publishing needs a separate protected upload key and Play App Signing configuration.

## Required before the app can appear in Play Store search

1. **Set up Play Console.** The account holder must be at least 18, accept Google's Developer Distribution Agreement, pay the one-time US$25 registration fee, and complete identity verification. Do not share passwords, identity documents, or payment details in chat. [Google Play Console setup](https://support.google.com/googleplay/android-developer/answer/6112435)

2. **Configure Supabase and Android signing.** Follow `SUPABASE-SETUP.md`. Copy `.env.example` to `.env`, then set the real Project URL and publishable (or anon) key from Supabase Settings → API. Example values produce a visible configuration error. Phone/password sign-in uses a private phone alias and requires email confirmation to be disabled for those accounts; it does not verify phone ownership. The avatar bucket and upload policies are included in `public/database/RUN_ALL.sql`. The local upload key must be backed up and retained for updates. JDK 21 and Android SDK 36 are available in the local build workspace. Build and sign an Android App Bundle (`.aab`) for Play upload.

3. **Complete the app's policy setup.**
   - Google requires an accurate Data safety form and a public privacy policy. The app's current policy says users can request account deletion through the developer's GitHub page; I did not find an in-app account-deletion request flow. Google requires a deletion mechanism and a web resource for apps that let users create accounts. This needs to be addressed before submission.
   - The Android project does not have `google-services.json`; Firebase push notifications for messages remain unconfigured. Background calls use the Android call watcher and still require the user to allow notifications, full-screen calls, and unrestricted battery use on their device.
   - Complete the content rating, target audience, app access instructions, ads declaration, support contact, screenshots, and other store-listing details based on the real app behavior.

4. **Test the app.** If the Play Console is a new personal developer account created after November 13, 2023, Google requires a closed test with at least 12 opted-in testers for 14 continuous days before applying for production access. [Google's testing requirement](https://support.google.com/googleplay/android-developer/answer/14151465)

5. **Submit the production release.** Google reviews the app and can ask for changes before it appears in search. A successful build does not guarantee approval.

## Useful links

- Play Console: https://play.google.com/console/
- Project repository: https://github.com/JOCHCIMAL/campus-connect-app
- Current web version: https://jochcimal.github.io/campus-connect-app/
- Privacy policy page: https://jochcimal.github.io/campus-connect-app/privacy.html
