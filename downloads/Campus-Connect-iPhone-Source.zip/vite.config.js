import { resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { defineConfig } from "vite";
import legacy from "@vitejs/plugin-legacy";

const projectRoot = fileURLToPath(new URL(".", import.meta.url));

export default defineConfig({
    plugins: [
        /* Android System WebView can lag behind the phone's OS for years. Keep
           the modern module build, then provide a transpiled SystemJS bundle and
           language polyfills to WebViews that cannot parse it. Chrome 49 is the
           oldest realistic Android WebView target supported by the app's APIs. */
        legacy({
            targets: ["Chrome >= 49"]
        })
    ],
    build: {
        /* A phone whose Android System WebView was ever updated is years behind,
           and a module it cannot parse is a blank screen with nothing to explain
           it. The default target of the bundler keeps optional chaining, nullish
           coalescing and class fields as they are, which needs a Chrome from
           2020. ES2017 folds those down to what a 2017 engine reads, and the
           whole app costs a few kilobytes more to get there. */
        target: "es2017",
        rollupOptions: {
            input: {
                main: resolve(projectRoot, "index.html"),
                world: resolve(projectRoot, "world.html"),
                messages: resolve(projectRoot, "messages.html"),
                classes: resolve(projectRoot, "classes.html"),
                companies: resolve(projectRoot, "companies.html"),
                services: resolve(projectRoot, "services.html")
            }
        }
    }
});
