// ==================================================
// CAMPUS CONNECT
// Social networking frontend prototype
// ==================================================

"use strict";

const STORAGE_KEY = "campusConnectPosts_v1";
const USER_KEY = "campusConnectUser";
const THEME_KEY = "campusConnectTheme";

const MAX_POST_LENGTH = 2000;
const MAX_COMMENT_LENGTH = 500;

// ==================================================
// DOM ELEMENTS
// ==================================================

const postForm = document.getElementById("post-form");
const postContent = document.getElementById("post-content");
const studentNameInput = document.getElementById("student-name");
const postsContainer = document.getElementById("posts-container");
const appStatus = document.getElementById("app-status");
const searchInput = document.getElementById("student-search");
const themeToggle = document.getElementById("theme-toggle");

// ==================================================
// SAFE LOCAL STORAGE
// ==================================================

function readStorage(key, fallback = null) {
    try {
        const value = localStorage.getItem(key);

        return value === null ? fallback : value;
    } catch (error) {
        console.error(`Could not read ${key}:`, error);
        return fallback;
    }
}

function writeStorage(key, value) {
    try {
        localStorage.setItem(key, value);
        return true;
    } catch (error) {
        console.error(`Could not save ${key}:`, error);

        showStatus(
            "Your browser could not save this information. Check available storage."
        );

        return false;
    }
}

// ==================================================
// STATUS MESSAGES
// ==================================================

function showStatus(message) {
    if (!appStatus) {
        console.info(message);
        return;
    }

    appStatus.textContent = message;

    clearTimeout(showStatus.timeoutId);

    showStatus.timeoutId = setTimeout(() => {
        appStatus.textContent = "";
    }, 4000);
}

// ==================================================
// CURRENT USER
// ==================================================

function getCurrentUser() {
    const inputName = studentNameInput?.value.trim();

    if (inputName) {
        return inputName;
    }

    return readStorage(USER_KEY, "Guest");
}

function rememberUser(name) {
    const cleanName = name.trim();

    if (cleanName) {
        writeStorage(USER_KEY, cleanName);
    }
}

// ==================================================
// POST STORAGE
// ==================================================

function loadPosts() {
    const savedPosts = readStorage(STORAGE_KEY, "[]");

    try {
        const parsedPosts = JSON.parse(savedPosts);

        if (!Array.isArray(parsedPosts)) {
            return [];
        }

        // Check and normalize each stored post.
        return parsedPosts
            .filter(post =>
                post &&
                typeof post.id === "string" &&
                typeof post.author === "string" &&
                typeof post.content === "string"
            )
            .map(post => ({
                id: post.id,
                author: post.author,
                content: post.content,
                createdAt:
                    typeof post.createdAt === "string"
                        ? post.createdAt
                        : new Date().toISOString(),
                likes: Array.isArray(post.likes)
                    ? post.likes.filter(
                        name => typeof name === "string"
                    )
                    : [],
                comments: Array.isArray(post.comments)
                    ? post.comments.filter(comment =>
                        comment &&
                        typeof comment.author === "string" &&
                        typeof comment.text === "string"
                    )
                    : []
            }));
    } catch (error) {
        console.error("Could not read saved posts:", error);
        showStatus("Saved posts could not be loaded.");
        return [];
    }
}

let posts = loadPosts();

function savePosts(updatedPosts) {
    return writeStorage(
        STORAGE_KEY,
        JSON.stringify(updatedPosts)
    );
}

// ==================================================
// ID GENERATION
// ==================================================

function createId() {
    if (
        window.crypto &&
        typeof window.crypto.randomUUID === "function"
    ) {
        return window.crypto.randomUUID();
    }

    return `${Date.now()}-${Math.random()
        .toString(36)
        .slice(2)}`;
}

// ==================================================
// POST CREATION
// ==================================================

function createPost(author, content) {
    return {
        id: createId(),
        author,
        content,
        createdAt: new Date().toISOString(),
        likes: [],
        comments: []
    };
}

// ==================================================
// SAFE HTML ELEMENTS
// ==================================================

function createElement(tag, className = "", text = undefined) {
    const element = document.createElement(tag);

    if (className) {
        element.className = className;
    }

    if (text !== undefined) {
        element.textContent = text;
    }

    return element;
}

function getInitials(name) {
    const parts = name.trim().split(/\s+/).filter(Boolean);

    return parts
        .slice(0, 2)
        .map(part => part.charAt(0).toUpperCase())
        .join("") || "S";
}

function createAvatar(name) {
    const avatar = createElement(
        "div",
        "avatar",
        getInitials(name)
    );

    avatar.setAttribute("role", "img");
    avatar.setAttribute("aria-label", `${name}'s avatar`);

    return avatar;
}

// ==================================================
// TIME FORMATTING
// ==================================================

function formatTime(dateString) {
    const date = new Date(dateString);

    if (Number.isNaN(date.getTime())) {
        return "Recently";
    }

    const seconds = Math.max(
        0,
        Math.floor((Date.now() - date.getTime()) / 1000)
    );

    if (seconds < 60) {
        return "Just now";
    }

    const minutes = Math.floor(seconds / 60);

    if (minutes < 60) {
        return `${minutes} minute${minutes === 1 ? "" : "s"} ago`;
    }

    const hours = Math.floor(minutes / 60);

    if (hours < 24) {
        return `${hours} hour${hours === 1 ? "" : "s"} ago`;
    }

    const days = Math.floor(hours / 24);

    if (days < 7) {
        return `${days} day${days === 1 ? "" : "s"} ago`;
    }

    return date.toLocaleDateString();
}

// ==================================================
// LIKE OR UNLIKE
// ==================================================

function toggleLike(postId) {
    const user = getCurrentUser();

    if (user === "Guest") {
        showStatus("Enter your name before liking a post.");
        return;
    }

    const updatedPosts = posts.map(post => {
        if (post.id !== postId) {
            return post;
        }

        const alreadyLiked = post.likes.includes(user);

        return {
            ...post,
            likes: alreadyLiked
                ? post.likes.filter(name => name !== user)
                : [...post.likes, user]
        };
    });

    if (!savePosts(updatedPosts)) {
        return;
    }

    posts = updatedPosts;
    renderPosts();
}

// ==================================================
// ADD A COMMENT
// ==================================================

function addComment(postId, text) {
    const cleanText = text.trim();

    if (!cleanText) {
        showStatus("Please write a comment first.");
        return;
    }

    if (cleanText.length > MAX_COMMENT_LENGTH) {
        showStatus(
            `Comments must be ${MAX_COMMENT_LENGTH} characters or fewer.`
        );
        return;
    }

    const author = getCurrentUser();

    if (author === "Guest") {
        showStatus("Enter your name before commenting.");
        return;
    }

    const updatedPosts = posts.map(post => {
        if (post.id !== postId) {
            return post;
        }

        return {
            ...post,
            comments: [
                ...post.comments,
                {
                    id: createId(),
                    author,
                    text: cleanText,
                    createdAt: new Date().toISOString()
                }
            ]
        };
    });

    if (!savePosts(updatedPosts)) {
        return;
    }

    posts = updatedPosts;
    renderPosts();

    showStatus("Comment added.");
}

// ==================================================
// DELETE A POST
// ==================================================

function deletePost(postId) {
    const post = posts.find(item => item.id === postId);

    if (!post) {
        showStatus("This post could not be found.");
        return;
    }

    const currentUser = getCurrentUser();

    if (post.author !== currentUser) {
        showStatus(
            "You can only delete posts created under your current name."
        );
        return;
    }

    if (!window.confirm("Are you sure you want to delete this post?")) {
        return;
    }

    const updatedPosts = posts.filter(
        item => item.id !== postId
    );

    if (!savePosts(updatedPosts)) {
        return;
    }

    posts = updatedPosts;
    renderPosts();

    showStatus("Post deleted.");
}

// ==================================================
// SHARE A POST
// ==================================================

async function sharePost(post) {
    const shareText =
        `${post.author} on Campus Connect: ${post.content}`;

    try {
        if (typeof navigator.share === "function") {
            await navigator.share({
                title: "Campus Connect",
                text: shareText
            });
            return;
        }

        if (
            navigator.clipboard &&
            typeof navigator.clipboard.writeText === "function"
        ) {
            await navigator.clipboard.writeText(shareText);
            showStatus("Post copied. You can now share it.");
            return;
        }

        showStatus("Sharing is not available in this browser.");
    } catch (error) {
        if (error.name !== "AbortError") {
            console.error("Sharing failed:", error);
            showStatus("Could not share this post.");
        }
    }
}

// ==================================================
// RENDER A POST
// ==================================================

function renderPost(post) {
    const article = createElement("article", "post-card");
    article.dataset.postId = post.id;

    // Header
    const header = createElement("div", "post-header");
    const user = createElement("div", "post-user");

    user.appendChild(createAvatar(post.author));

    const userInfo = createElement("div", "post-user-info");

    userInfo.appendChild(
        createElement("strong", "", post.author)
    );

    userInfo.appendChild(
        createElement("div", "post-location", "Campus Connect")
    );

    user.appendChild(userInfo);
    header.appendChild(user);

    // Menu button
    const moreButton = createElement("button", "more-button", "•••");

    moreButton.type = "button";
    moreButton.setAttribute("aria-label", "Delete post");

    moreButton.addEventListener("click", () => {
        deletePost(post.id);
    });

    header.appendChild(moreButton);
    article.appendChild(header);

    // Actions
    const actions = createElement("div", "post-actions");
    const currentUser = getCurrentUser();
    const liked = post.likes.includes(currentUser);

    const likeButton = createElement(
        "button",
        "like-button",
        liked ? "♥" : "♡"
    );

    likeButton.type = "button";
    likeButton.setAttribute(
        "aria-label",
        liked ? "Unlike post" : "Like post"
    );

    likeButton.setAttribute("aria-pressed", String(liked));

    likeButton.style.color = "#ed4956";

    likeButton.addEventListener("click", () => {
        toggleLike(post.id);
    });

    const commentButton = createElement(
        "button",
        "comment-button",
        "💬"
    );

    commentButton.type = "button";
    commentButton.setAttribute("aria-label", "Write a comment");

    const shareButton = createElement(
        "button",
        "share-button",
        "➤"
    );

    shareButton.type = "button";
    shareButton.setAttribute("aria-label", "Share post");

    shareButton.addEventListener("click", () => {
        sharePost(post);
    });

    actions.append(likeButton, commentButton, shareButton);
    article.appendChild(actions);

    // Likes
    article.appendChild(
        createElement(
            "div",
            "post-likes",
            `${post.likes.length} ${
                post.likes.length === 1 ? "like" : "likes"
            }`
        )
    );

    // Caption
    const caption = createElement("div", "post-caption");

    caption.appendChild(
        createElement("strong", "", post.author)
    );

    caption.appendChild(
        document.createTextNode(` ${post.content}`)
    );

    article.appendChild(caption);

    // Time
    article.appendChild(
        createElement("div", "post-time", formatTime(post.createdAt))
    );

    // Comments
    const commentsList = createElement("div", "post-comments");

    post.comments.forEach(comment => {
        const line = createElement("div", "post-caption");

        line.appendChild(
            createElement("strong", "", comment.author)
        );

        line.appendChild(
            document.createTextNode(` ${comment.text}`)
        );

        commentsList.appendChild(line);
    });

    article.appendChild(commentsList);

    // Comment form
    const commentForm = createElement("form", "comment-form");
    const commentInput = createElement("input");

    commentInput.type = "text";
    commentInput.name = "comment";
    commentInput.placeholder = "Add a comment...";
    commentInput.maxLength = MAX_COMMENT_LENGTH;
    commentInput.required = true;
    commentInput.setAttribute("aria-label", "Write a comment");

    const commentSubmit = createElement("button", "", "Post");
    commentSubmit.type = "submit";

    commentForm.append(commentInput, commentSubmit);

    commentForm.addEventListener("submit", event => {
        event.preventDefault();

        addComment(post.id, commentInput.value);
    });

    commentButton.addEventListener("click", () => {
        commentInput.focus();
    });

    article.appendChild(commentForm);

    return article;
}

// ==================================================
// RENDER ALL POSTS
// ==================================================

function renderPosts() {
    if (!postsContainer) {
        console.error(
            'Missing element with id="posts-container" in index.html.'
        );
        return;
    }

    // Preserve any static example content that is not generated here.
    postsContainer
        .querySelectorAll("[data-post-id]")
        .forEach(element => element.remove());

    const query = searchInput?.value.trim().toLowerCase() || "";

    posts.forEach(post => {
        const searchableText =
            `${post.author} ${post.content}`.toLowerCase();

        if (!searchableText.includes(query)) {
            return;
        }

        postsContainer.appendChild(renderPost(post));
    });
}

// ==================================================
// CREATE A NEW POST
// ==================================================

function setupPostForm() {
    if (!postForm || !postContent || !studentNameInput) {
        console.warn(
            "Post form not initialized. Check the IDs in index.html."
        );
        return;
    }

    const rememberedName = readStorage(USER_KEY, "");

    if (rememberedName) {
        studentNameInput.value = rememberedName;
    }

    postForm.addEventListener("submit", event => {
        event.preventDefault();

        const author = studentNameInput.value.trim();
        const content = postContent.value.trim();

        if (!author) {
            showStatus("Please enter your name.");
            studentNameInput.focus();
            return;
        }

        if (!content) {
            showStatus("Please write something before sharing.");
            postContent.focus();
            return;
        }

        if (content.length > MAX_POST_LENGTH) {
            showStatus(
                `Posts must be ${MAX_POST_LENGTH} characters or fewer.`
            );
            return;
        }

        rememberUser(author);

        const newPost = createPost(author, content);
        const updatedPosts = [newPost, ...posts];

        if (!savePosts(updatedPosts)) {
            return;
        }

        posts = updatedPosts;
        postContent.value = "";

        renderPosts();
        showStatus("Post published in this browser.");
    });
}

// ==================================================
// SEARCH POSTS
// ==================================================

function setupSearch() {
    if (!searchInput) {
        return;
    }

    searchInput.addEventListener("input", renderPosts);
}

// ==================================================
// MOBILE NAVIGATION
// ==================================================

function setupMobileNavigation() {
    const navToggle = document.getElementById("nav-toggle");
    const navigation = document.getElementById("main-navigation");

    if (!navToggle || !navigation) {
        return;
    }

    navToggle.addEventListener("click", () => {
        const expanded =
            navToggle.getAttribute("aria-expanded") === "true";

        navToggle.setAttribute(
            "aria-expanded",
            String(!expanded)
        );

        navigation.classList.toggle("open", !expanded);
    });
}

// ==================================================
// DARK MODE
// ==================================================

function setupTheme() {
    if (!themeToggle) {
        return;
    }

    const savedTheme = readStorage(THEME_KEY, "light");

    document.body.classList.toggle(
        "dark-mode",
        savedTheme === "dark"
    );

    function updateThemeButton() {
        const dark = document.body.classList.contains("dark-mode");

        themeToggle.textContent = dark
            ? "☀️ Day Mode"
            : "🌙 Night Mode";

        themeToggle.setAttribute(
            "aria-pressed",
            String(dark)
        );
    }

    updateThemeButton();

    themeToggle.addEventListener("click", () => {
        const dark =
            !document.body.classList.contains("dark-mode");

        document.body.classList.toggle("dark-mode", dark);

        if (!writeStorage(THEME_KEY, dark ? "dark" : "light")) {
            return;
        }

        updateThemeButton();
    });
}

// ==================================================
// START CAMPUS CONNECT
// ==================================================

function startApp() {
    setupPostForm();
    setupSearch();
    setupMobileNavigation();
    setupTheme();
    renderPosts();

    console.info("Campus Connect frontend is ready.");
}

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", startApp);
} else {
    startApp();
}
