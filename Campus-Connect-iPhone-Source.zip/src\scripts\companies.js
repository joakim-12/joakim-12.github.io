import "../lib/compat.js";
import "../lib/native-feel.js";
import { installVitePreloadRecovery } from "../lib/vite-preload-recovery.js";
import { initializeLanguageSelector, translate } from "../lib/language.js";
import { initializeTheme, isDark, toggleThemeMode } from "../lib/theme.js";
import { initializeAppInstallation } from "../lib/pwa.js";
import { supabase } from "../lib/supabase.js";
import { isMissingSchemaObject } from "../lib/profile-identity.js";
import { missingColumnName } from "../lib/profile-sync.js";
import { showSetupCard } from "../lib/db-setup.js";
import { resolveBootUser } from "../lib/offline-session.js";
import { setOfflineBanner } from "../lib/offline-banner.js";
import {
    addCompany,
    clearCompanyDirectory,
    isCompanyDirectoryMissing,
    loadCompanyDirectory,
    normalizeCompanyName,
    searchDirectory
} from "../lib/company-directory.js";

const clearPreloadRetry = installVitePreloadRecovery();
initializeLanguageSelector();
initializeAppInstallation();

const $ = id => document.getElementById(id);
const themeToggle = $("theme-toggle");

function renderThemeLabel() {
    themeToggle.textContent = translate(isDark() ? "☀️ Day Mode" : "🌙 Night Mode");
    themeToggle.setAttribute("aria-pressed", String(isDark()));
}

initializeTheme(renderThemeLabel);
themeToggle.addEventListener("click", () => {
    toggleThemeMode();
    renderThemeLabel();
});

const results = $("company-results");
const listHeading = $("list-heading");
const pageStatus = $("page-status");
const searchInput = $("company-search");
const minePanel = $("mine-panel");
const mineName = $("mine-name");
const mineRole = $("mine-role");

let user = null;
let directory = [];
let directoryReady = false;
let mine = { company: "", company_role: "" };

function setStatus(element, message, kind = "") {
    element.textContent = translate(message);
    element.className = `status ${kind}`.trim();
}

function state(message) {
    pageStatus.textContent = translate(message);
    pageStatus.hidden = !message;
}

function countryName(value) {
    const name = String(value || "").trim();
    if (!name) return "";
    try {
        return new Intl.DisplayNames(["en"], { type: "region" }).of(name.toUpperCase()) || name;
    } catch {
        return name;
    }
}

async function writeCompanyClaim(company, role) {
    const payload = { company, company_role: role };
    let columnsMissing = false;
    let result = await supabase.from("profiles")
        .update(payload)
        .eq("id", user.id)
        .select("id")
        .maybeSingle();

    while (result.error && isMissingSchemaObject(result.error)) {
        const column = missingColumnName(result.error);
        if (!column || !(column in payload)) break;
        delete payload[column];
        columnsMissing = true;
        result = await supabase.from("profiles")
            .update(payload)
            .eq("id", user.id)
            .select("id")
            .maybeSingle();
    }
    if (result.error) {
        /* One Director per company: the database refuses a second director for
           the same name. Say so plainly and point them at the seat they can
           take instead, rather than surfacing a raw constraint error. */
        if (result.error.code === "23505" && role === "director") {
            return { ok: false, message: `Another account is already the Director of ${company}. Join it as Staff instead.` };
        }
        return { ok: false, message: `Could not save it: ${result.error.message}` };
    }
    return { ok: true, columnsMissing };
}

/* The name is what the zone is built from, so a claim is written to the profile
   column when this database has it, and onto the account itself when it does
   not. Either way the app reads the same answer back. */
async function claimCompany(company, role) {
    const saved = await writeCompanyClaim(company, role);
    if (!saved.ok || !saved.columnsMissing) return saved;
    const { error } = await supabase.auth.updateUser({ data: { company, company_role: role } });
    if (error) {
        console.warn("The company was written to the profile, but not to the account:", error);
        return { ok: true, columnsMissing: false };
    }
    return { ok: true, columnsMissing: true };
}

function buildCard(company) {
    const card = document.createElement("article");
    card.className = "uni-card";

    const head = document.createElement("div");
    head.className = "uni-head";
    const name = document.createElement("h3");
    name.className = "uni-name";
    name.textContent = company.name;
    head.appendChild(name);
    const place = [company.city, countryName(company.country), company.industry]
        .filter(Boolean).join(" · ");
    if (place) {
        const meta = document.createElement("span");
        meta.className = "uni-meta";
        meta.textContent = place;
        head.appendChild(meta);
    }
    card.appendChild(head);

    if (company.website || company.note) {
        const links = document.createElement("div");
        links.className = "uni-links";
        if (company.website) {
            const link = document.createElement("a");
            link.className = "uni-link";
            link.href = company.website;
            link.target = "_blank";
            link.rel = "noopener noreferrer";
            const chip = document.createElement("span");
            chip.className = "kind-chip kind-site";
            chip.textContent = `🌐 ${translate("Official website")}`;
            const label = document.createElement("span");
            label.className = "label";
            label.textContent = company.website.replace(/^https?:\/\//i, "");
            link.append(chip, label);
            links.appendChild(link);
        }
        if (company.note) {
            const note = document.createElement("p");
            note.className = "uni-note";
            note.textContent = company.note;
            links.appendChild(note);
        }
        card.appendChild(links);
    }

    const mineMatch = normalizeCompanyName(mine.company) === company.key;
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = translate(mineMatch ? "You work here" : "I work here");
    button.className = mineMatch ? "claimed" : "";
    button.addEventListener("click", async () => {
        if (!user) {
            window.location.href = "/";
            return;
        }
        button.disabled = true;
        const saved = await claimCompany(company.name, mineRole.value);
        button.disabled = false;
        if (!saved.ok) {
            state(saved.message);
            return;
        }
        mine = { company: company.name, company_role: mineRole.value };
        renderMine();
        render();
        state(saved.columnsMissing
            ? "Your company is kept on the account until the database setup adds its columns."
            : `${company.name} is now the company your feed leads with.`);
    });
    card.appendChild(button);
    return card;
}

function renderMine() {
    if (!user) {
        minePanel.hidden = true;
        return;
    }
    minePanel.hidden = false;
    mineName.textContent = mine.company || translate("not named yet");
    mineRole.value = mine.company_role === "staff" ? "staff" : "director";
}

function render() {
    if (!directoryReady) {
        // The list could not be read at all, so the page says that once instead
        // of claiming the list is empty and pointing at a form that is hidden.
        listHeading.hidden = true;
        results.replaceChildren();
        return;
    }
    const matches = searchDirectory(directory, searchInput.value);
    listHeading.hidden = !matches.length;
    results.replaceChildren(...matches.map(buildCard));
    if (!matches.length) {
        const empty = document.createElement("p");
        empty.className = "state";
        empty.textContent = directory.length
            ? translate("No company in the list matches that search. Add it below if it is real.")
            : translate("The list is still empty. Add the first company below.");
        results.appendChild(empty);
    }
}

async function readMine() {
    mine = { company: "", company_role: "" };
    if (!user) return;
    mine.company = String(user.user_metadata?.company || "").slice(0, 120);
    mine.company_role = user.user_metadata?.company_role === "staff" ? "staff" : "director";
    const { data, error } = await supabase
        .from("profiles")
        .select("company, company_role")
        .eq("id", user.id)
        .maybeSingle();
    if (error || !data) return;
    if (data.company) {
        mine.company = data.company;
        mine.company_role = data.company_role === "staff" ? "staff" : "director";
    }
}

$("mine-save").addEventListener("click", async () => {
    if (!user || !mine.company) return;
    const saved = await claimCompany(mine.company, mineRole.value);
    if (!saved.ok) {
        state(saved.message);
        return;
    }
    mine.company_role = mineRole.value;
    renderMine();
    render();
    state("Kept as your company.");
});

$("mine-clear").addEventListener("click", async () => {
    if (!user) return;
    const saved = await claimCompany("", "");
    if (!saved.ok) {
        state(saved.message);
        return;
    }
    mine = { company: "", company_role: "director" };
    renderMine();
    render();
    state("No company leads your feed now.");
});

$("add-form").addEventListener("submit", async event => {
    event.preventDefault();
    if (!user) {
        setStatus($("add-status"), "Open the app and sign in before adding a company.", "error");
        return;
    }
    const typed = $("add-name").value.trim();
    const added = await addCompany(supabase, {
        name: typed,
        country: $("add-country").value,
        city: $("add-city").value,
        industry: $("add-industry").value,
        website: $("add-website").value,
        addedBy: user.id
    });
    setStatus($("add-status"), added.message, added.ok ? "success" : "error");
    if (!added.ok) {
        if (added.missing) mountSetupCard();
        return;
    }
    $("add-form").reset();
    directory = (await loadCompanyDirectory(supabase, { force: true })) || [];
    render();
    state("");
    // A brand new row is the one thing worth claiming straight away.
    mine = { company: added.name || typed, company_role: mine.company_role };
});

function mountSetupCard() {
    showSetupCard({
        target: listHeading,
        reason: "The company list is one of the tables the setup file creates. Run it once and this page fills up."
    });
}

async function start() {
    state("Reading the company list…");
    const boot = await resolveBootUser(supabase);
    user = boot.user;
    setOfflineBanner(boot.offline);

    const rows = await loadCompanyDirectory(supabase);
    directoryReady = Boolean(rows);
    if (!rows) {
        directory = [];
        state(isCompanyDirectoryMissing()
            ? "The company list has not been created in your database yet."
            : "The company list could not be read. Check your connection.");
        if (isCompanyDirectoryMissing()) mountSetupCard();
        $("add-panel").hidden = true;
        render();
        return;
    }
    directory = rows;
    await readMine();
    renderMine();
    render();
    state("");
}

let debounce;
searchInput.addEventListener("input", () => {
    window.clearTimeout(debounce);
    debounce = window.setTimeout(render, 150);
});
window.addEventListener("pagehide", () => {
    clearCompanyDirectory();
    clearPreloadRetry();
}, { once: true });

void start();
