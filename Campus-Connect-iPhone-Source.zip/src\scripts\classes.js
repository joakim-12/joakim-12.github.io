import "../lib/compat.js";
import "../lib/native-feel.js";
import { installVitePreloadRecovery } from "../lib/vite-preload-recovery.js";
import { initializeLanguageSelector, translate } from "../lib/language.js";
import { initializeTheme, isDark, toggleThemeMode } from "../lib/theme.js";
import { initializeAppInstallation } from "../lib/pwa.js";
import { showSetupCard } from "../lib/db-setup.js";
import { ensureStaffAccess } from "../lib/staff-verification.js";
import { ensureClassAccess } from "../lib/class-access.js";
import { sendMembersToBulletin } from "../lib/member-view.js";
import { resolveBootUser } from "../lib/offline-session.js";
import { setOfflineBanner } from "../lib/offline-banner.js";
import { checkIntoClass, loadAttendance, openRegister, registerState } from "../lib/class-register.js";

const clearPreloadRetry = installVitePreloadRecovery();
initializeLanguageSelector();
initializeAppInstallation();

const $ = (id) => document.getElementById(id);

const themeToggle = $("theme-toggle");

function renderThemeLabel() {
    themeToggle.textContent = translate(isDark() ? "☀️ Day Mode" : "🌙 Night Mode");
    themeToggle.setAttribute("aria-pressed", String(isDark()));
}

initializeTheme(renderThemeLabel);
themeToggle.addEventListener("click", () => {
    toggleThemeMode();
    renderThemeLabel();
});

let supabase;
let currentUser;
let myProfile = null;
let programmes = [];
let units = [];
let sessions = [];
let lecturerNames = new Map();
let catalogueReady = true;
let registerReady = true;

const WEEKDAYS = ["", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const REGISTER_CODES = ["42P01", "42703", "42883", "PGRST202", "PGRST204", "PGRST205"];
const REGISTER_COLUMNS = "checkin_code, checkin_opens_at, checkin_expires_at, checkin_occurrence";
const REGISTER_WINDOW_MINUTES = 20;
const myCheckins = new Set();

function registerUnavailable(error) {
    if (REGISTER_CODES.includes(String(error?.code || ""))) return true;
    return /checkin_code|checkin_opens_at|checkin_expires_at|checkin_occurrence|class_checkins/i
        .test(String(error?.message || ""));
}

function showNotice(message, isError = false) {
    const notice = $("classes-notice");
    notice.textContent = message ? translate(message) : "";
    notice.className = `notice ${isError ? "error" : ""}`.trim();
}

function programmeById(id) {
    return programmes.find(programme => programme.id === id);
}

function levelLabel({ programme_id: programmeId, study_year: studyYear, semester }) {
    const prefix = programmeById(programmeId)?.level === "masters" ? "M" :
        programmeById(programmeId)?.level === "phd" ? "P" : "";
    return `${prefix}${studyYear}.${semester}`;
}

function formatTime(value = "") {
    return value.slice(0, 5);
}

function cacheKey() {
    return `campus-classes-cache:${currentUser.id}`;
}

function saveSnapshot() {
    try {
        localStorage.setItem(cacheKey(), JSON.stringify({
            savedAt: Date.now(),
            programmes,
            units,
            sessions,
            profile: myProfile,
            lecturerNames: [...lecturerNames.entries()]
        }));
    } catch {
        // A full device storage only costs the offline view.
    }
}

function loadSnapshot() {
    try {
        const raw = JSON.parse(localStorage.getItem(cacheKey()) || "null");
        if (!raw?.programmes?.length) return false;
        programmes = raw.programmes;
        units = raw.units || [];
        sessions = raw.sessions || [];
        lecturerNames = new Map(raw.lecturerNames || []);
        if (!myProfile && raw.profile) myProfile = raw.profile;
        return true;
    } catch {
        return false;
    }
}

async function loadMyProfile() {
    const full = await supabase
        .from("profiles")
        .select("id, full_name, username, role, staff_id_number, requested_role, programme_id, study_year, semester")
        .eq("id", currentUser.id)
        .maybeSingle();
    if (!full.error) {
        myProfile = full.data;
        return;
    }
    const basic = await supabase
        .from("profiles")
        .select("id, full_name, username")
        .eq("id", currentUser.id)
        .maybeSingle();
    myProfile = basic.data ? { ...basic.data, role: "student" } : null;
    if (!myProfile) {
        // Nothing can be read without a connection, so the last known copy of
        // this student's own row is used to decide what the page may show.
        try {
            const raw = JSON.parse(localStorage.getItem(cacheKey()) || "null");
            if (raw?.profile?.id === currentUser.id) myProfile = raw.profile;
        } catch {
            // A broken cache leaves the page on its default (student) role.
        }
    }
}

function myRole() {
    return myProfile?.role || "student";
}

function canManage() {
    return catalogueReady && (myRole() === "lecturer" || myRole() === "admin");
}

const LEVEL_NAMES = {
    phd: "PhD",
    masters: "Masters",
    undergraduate: "Bachelor",
    diploma: "Diploma",
    certificate: "Certificate"
};

function populateProgrammeSelect() {
    const select = $("programme-filter");
    const level = $("level-filter").value;
    select.replaceChildren();
    const schools = new Map();
    for (const programme of programmes) {
        if (level && programme.level !== level) continue;
        if (!schools.has(programme.school)) schools.set(programme.school, []);
        schools.get(programme.school).push(programme);
    }
    for (const [school, list] of schools) {
        const group = document.createElement("optgroup");
        group.label = school;
        for (const programme of list) {
            const option = document.createElement("option");
            option.value = programme.id;
            option.textContent = programme.name;
            group.appendChild(option);
        }
        select.appendChild(group);
    }
    const firstOption = [...select.querySelectorAll("option")][0];
    const preferred = myProfile?.programme_id &&
        (!level || programmeById(myProfile.programme_id)?.level === level) &&
        programmes.some(programme => programme.id === myProfile.programme_id)
        ? myProfile.programme_id : firstOption?.value;
    if (preferred) select.value = preferred;
    select.disabled = !firstOption;
    populateYearSelects();
    renderProgrammeInfo();
}

function selectedProgramme() {
    return programmeById($("programme-filter").value);
}

function renderProgrammeInfo() {
    const info = $("programme-info");
    if (!info) return;
    info.replaceChildren();
    const programme = selectedProgramme();
    if (!programme) return;
    const head = document.createElement("p");
    const level = LEVEL_NAMES[programme.level] || programme.level;
    head.textContent = `🎓 ${translate(level)} · 📍 ${translate(programme.campus || "Main")}`;
    info.appendChild(head);
    if (programme.specializations) {
        const options = document.createElement("p");
        const strong = document.createElement("strong");
        strong.textContent = `${translate("Options:")} `;
        options.append(strong, programme.specializations);
        info.appendChild(options);
    }
}

function populateYearSelects() {
    const programme = selectedProgramme();
    const maxYear = programme?.max_year || 4;
    const isMasters = programme?.level === "masters" || programme?.level === "phd";
    const label = year => translate(isMasters ? `M Year ${year}` : `Year ${year}`);
    const yearFilter = $("year-filter");
    const allYears = yearFilter.querySelector("option")?.outerHTML ||
        `<option value="">${translate("All years")}</option>`;
    yearFilter.replaceChildren();
    yearFilter.insertAdjacentHTML("beforeend", allYears);
    $("unit-year").replaceChildren();
    $("study-year").replaceChildren();
    for (let year = 1; year <= maxYear; year += 1) {
        for (const select of [yearFilter, $("unit-year"), $("study-year")]) {
            const option = document.createElement("option");
            option.value = String(year);
            option.textContent = label(year);
            select.appendChild(option);
        }
    }
    if (myProfile?.study_year) {
        yearFilter.value = String(myProfile.study_year);
        $("study-year").value = String(myProfile.study_year);
    }
    if (myProfile?.semester) {
        $("semester-filter").value = String(myProfile.semester);
        $("study-semester").value = String(myProfile.semester);
    }
}

function visibleUnitIds() {
    const programmeId = $("programme-filter").value;
    const year = $("year-filter").value;
    const semester = $("semester-filter").value;
    const ids = new Set();
    for (const unit of units) {
        if (unit.programme_id !== programmeId) continue;
        if (year && unit.study_year !== Number(year)) continue;
        if (semester && unit.semester !== Number(semester)) continue;
        ids.add(unit.id);
    }
    return ids;
}

function renderMyClassLine() {
    const line = $("my-class-line");
    line.replaceChildren();
    if (!myProfile) return;
    const programme = programmeById(myProfile.programme_id);
    if (programme && myProfile.study_year && myProfile.semester) {
        const strong = document.createElement("strong");
        strong.textContent = `${translate("My class")}: ${levelLabel({
            programme_id: programme.id,
            study_year: myProfile.study_year,
            semester: myProfile.semester
        })} · ${programme.name}`;
        line.appendChild(strong);
    } else {
        line.textContent = translate("Set your programme and year in your profile to see your class here.");
        const link = document.createElement("a");
        link.href = "/#profile";
        link.textContent = ` ${translate("Open profile")}`;
        line.appendChild(link);
    }
}

function registerKey(session) {
    return `${session.id}:${session.checkin_occurrence || ""}`;
}

function note(message, kind = "") {
    const line = document.createElement("p");
    line.className = `register-note ${kind}`.trim();
    line.textContent = translate(message);
    return line;
}

function buildRegister(session) {
    if (!registerReady || !session.checkin_opens_at) return null;
    const state = registerState(session);
    const box = document.createElement("div");
    box.className = "session-register";

    if (myCheckins.has(registerKey(session))) {
        box.appendChild(note("You are on this class list.", "success"));
        return box;
    }
    if (!state.open) {
        box.appendChild(note("The register for this class has closed."));
        return box;
    }

    box.appendChild(note(`${translate("Register open")} · ${state.minutesLeft} ${translate("min left")}`, "success"));

    const row = document.createElement("div");
    row.className = "register-row";
    const input = document.createElement("input");
    input.className = "register-input";
    input.type = "text";
    input.autocomplete = "off";
    input.spellcheck = false;
    input.maxLength = 6;
    input.placeholder = translate("Code");
    input.setAttribute("aria-label", translate("Attendance code"));
    const button = document.createElement("button");
    button.type = "button";
    button.className = "register-button";
    button.textContent = translate("I am in class");
    const status = document.createElement("div");
    row.append(input, button, status);
    box.appendChild(row);

    button.addEventListener("click", async () => {
        button.disabled = true;
        status.replaceChildren();
        const result = await checkIntoClass(supabase, { classId: session.id, code: input.value });
        button.disabled = false;
        status.replaceChildren(note(result.message, result.ok ? "success" : "error"));
        if (!result.ok && result.missing) {
            registerReady = false;
            renderTimetable();
            return;
        }
        if (result.ok) {
            myCheckins.add(registerKey(session));
            input.value = "";
            renderTimetable();
        }
    });
    return box;
}

function renderTimetable() {
    const container = $("timetable");
    container.replaceChildren();
    const visible = visibleUnitIds();
    const unitById = new Map(units.map(unit => [unit.id, unit]));
    let shown = 0;

    for (let weekday = 1; weekday <= 6; weekday += 1) {
        const daySessions = sessions
            .filter(session => session.weekday === weekday && visible.has(session.unit_id))
            .sort((left, right) => left.start_time.localeCompare(right.start_time));
        if (!daySessions.length) continue;
        shown += daySessions.length;

        const group = document.createElement("div");
        group.className = "day-group";
        const title = document.createElement("h2");
        title.className = "day-title";
        title.textContent = translate(WEEKDAYS[weekday]);
        group.appendChild(title);

        for (const session of daySessions) {
            const unit = unitById.get(session.unit_id);
            if (!unit) continue;
            const card = document.createElement("div");
            card.className = "session-card";

            const time = document.createElement("div");
            time.className = "session-time";
            time.textContent = `${formatTime(session.start_time)}–${formatTime(session.end_time)}`;

            const body = document.createElement("div");
            const heading = document.createElement("p");
            heading.className = "session-unit";
            heading.textContent = `${unit.code} · ${unit.title}`;
            const chip = document.createElement("span");
            chip.className = "level-chip";
            chip.textContent = levelLabel(unit);
            heading.appendChild(chip);

            const meta = document.createElement("p");
            meta.className = "session-meta";
            const lecturer = lecturerNames.get(session.lecturer_id) || translate("Lecturer");
            meta.textContent = session.mode === "online"
                ? `${lecturer} · ${translate("Online")}`
                : `${lecturer} · 📍 ${session.location || translate("To be announced")}`;
            if (session.note) meta.textContent += ` · ${session.note}`;

            body.append(heading, meta);
            if (session.mode === "online" && session.link) {
                const open = document.createElement("a");
                open.className = "session-open";
                open.href = session.link;
                open.target = "_blank";
                open.rel = "noopener noreferrer";
                open.textContent = translate("Open class link");
                body.appendChild(open);
            }
            const register = buildRegister(session);
            if (register) body.appendChild(register);
            card.append(time, body);
            group.appendChild(card);
        }
        container.appendChild(group);
    }

    if (!shown) {
        const empty = document.createElement("div");
        empty.className = "empty-timetable";
        empty.textContent = translate("No classes planned for this selection yet.");
        container.appendChild(empty);
    }
}

async function loadCatalogue() {
    let programmeRows;
    let programmeError;
    const fullResult = await supabase
        .from("programmes")
        .select("id, school, name, level, max_year, campus, specializations")
        .order("school")
        .order("name")
        .limit(300);
    if (fullResult.error) {
        // A database that still has the old programmes table: try without
        // the campus and specializations columns before giving up.
        const oldResult = await supabase
            .from("programmes")
            .select("id, school, name, level, max_year")
            .order("school")
            .order("name")
            .limit(300);
        programmeRows = oldResult.data;
        programmeError = oldResult.error;
    } else {
        programmeRows = fullResult.data;
    }
    if (programmeError) {
        catalogueReady = false;
        const restored = loadSnapshot();
        if (!restored) {
            showSetupCard({
                target: "#classes-notice",
                reason: translate("Units and timetables need one database update before lecturers can add classes.")
            });
            $("lecturer-panel").hidden = true;
            renderTimetable();
            return false;
        }
        showNotice("Showing the saved copy of the timetable. Reconnect to refresh it.");
    } else {
        programmes = programmeRows || [];
    }

    if (catalogueReady) {
        const plainColumns = "id, unit_id, lecturer_id, weekday, start_time, end_time, mode, location, link, note";
        // A student's copy of the timetable never carries the code itself -
        // only the window it is valid for, so nobody can read another
        // class's register off the wire.
        const sessionColumns = canManage()
            ? `${plainColumns}, ${REGISTER_COLUMNS}`
            : `${plainColumns}, checkin_opens_at, checkin_expires_at, checkin_occurrence`;
        const [unitResult, firstSessionResult] = await Promise.all([
            supabase.from("units")
                .select("id, programme_id, code, title, study_year, semester, created_by")
                .limit(2000),
            supabase.from("class_sessions")
                .select(sessionColumns)
                .limit(2000)
        ]);
        let sessionResult = firstSessionResult;
        if (sessionResult.error && registerUnavailable(sessionResult.error)) {
            registerReady = false;
            sessionResult = await supabase.from("class_sessions")
                .select(plainColumns)
                .limit(2000);
        }
        if (unitResult.error || sessionResult.error) {
            catalogueReady = false;
            showNotice(`Could not load classes: ${unitResult.error?.message || sessionResult.error?.message}`, true);
            if (!loadSnapshot()) {
                units = [];
                sessions = [];
            }
        } else {
            units = unitResult.data || [];
            sessions = sessionResult.data || [];
            const lecturerIds = [...new Set(sessions.map(session => session.lecturer_id))];
            if (lecturerIds.length) {
                const { data: lecturers } = await supabase
                    .from("profiles")
                    .select("id, full_name, username")
                    .in("id", lecturerIds);
                lecturerNames = new Map((lecturers || [])
                    .map(profile => [profile.id, profile.full_name || profile.username || translate("Lecturer")]));
            } else {
                lecturerNames = new Map();
            }
            if (programmes.length) saveSnapshot();
        }
    }

    populateProgrammeSelect();
    renderMyClassLine();
    renderTimetable();
    renderExplore();
    $("lecturer-panel").hidden = !canManage();
    if (canManage()) renderMyProgramme();
    $("my-studies-card").hidden = !(currentUser && programmes.length);
    renderManagedList();
    return catalogueReady;
}

function unitOptionLabel(unit) {
    return `${unit.code} · ${unit.title} (${levelLabel(unit)})`;
}

function renderExplore() {
    const unitsList = $("explore-units-list");
    const lecturersList = $("explore-lecturers-list");
    if (!unitsList || !lecturersList) return;
    unitsList.replaceChildren();
    lecturersList.replaceChildren();

    const visible = visibleUnitIds();
    const sessionByUnit = new Map();
    for (const session of sessions) {
        if (visible.has(session.unit_id) && !sessionByUnit.has(session.unit_id)) {
            sessionByUnit.set(session.unit_id, session);
        }
    }

    const shownUnits = units
        .filter(unit => visible.has(unit.id))
        .sort((left, right) => left.code.localeCompare(right.code, "en"));
    for (const unit of shownUnits) {
        const row = document.createElement("div");
        row.className = "browse-row";
        const title = document.createElement("strong");
        title.textContent = `${unit.code} · ${unit.title}`;
        const chip = document.createElement("span");
        chip.className = "level-chip";
        chip.textContent = levelLabel(unit);
        const meta = document.createElement("p");
        meta.className = "browse-meta";
        const session = sessionByUnit.get(unit.id);
        if (session) {
            const lecturer = lecturerNames.get(session.lecturer_id) || translate("Lecturer");
            const where = session.mode === "online"
                ? translate("Online")
                : `📍 ${session.location || translate("To be announced")}`;
            meta.textContent = `${lecturer} · ${translate(WEEKDAYS[session.weekday])} ${formatTime(session.start_time)}–${formatTime(session.end_time)} · ${where}`;
        } else {
            meta.textContent = translate("No class planned yet.");
        }
        row.append(title, chip, meta);
        unitsList.appendChild(row);
    }
    if (!shownUnits.length) {
        const empty = document.createElement("p");
        empty.className = "browse-empty";
        empty.textContent = translate("No units match these filters yet. Lecturers add units from their tools below.");
        unitsList.appendChild(empty);
    }

    const byLecturer = new Map();
    for (const session of sessions) {
        if (!visible.has(session.unit_id)) continue;
        if (!byLecturer.has(session.lecturer_id)) byLecturer.set(session.lecturer_id, []);
        byLecturer.get(session.lecturer_id).push(session);
    }
    const unitById = new Map(units.map(unit => [unit.id, unit]));
    const lecturers = [...byLecturer.entries()]
        .map(([lecturerId, lecturerSessions]) => {
            const codes = [...new Set(lecturerSessions
                .map(session => unitById.get(session.unit_id)?.code)
                .filter(Boolean))];
            return {
                name: lecturerNames.get(lecturerId) || translate("Lecturer"),
                codes,
                days: [...new Set(lecturerSessions
                    .map(session => translate(WEEKDAYS[session.weekday])))]
            };
        })
        .sort((left, right) => left.name.localeCompare(right.name, "en"));
    for (const lecturer of lecturers) {
        const row = document.createElement("div");
        row.className = "browse-row lecturer-head";
        const avatar = document.createElement("span");
        avatar.className = "lecturer-avatar";
        avatar.textContent = (lecturer.name[0] || "?").toUpperCase();
        const body = document.createElement("div");
        const title = document.createElement("strong");
        title.textContent = lecturer.name;
        const meta = document.createElement("p");
        meta.className = "browse-meta";
        const unitCount = translate(lecturer.codes.length === 1 ? "unit" : "units");
        meta.textContent = `${lecturer.codes.length} ${unitCount}: ${lecturer.codes.join(", ")} · ${lecturer.days.join(", ")}`;
        body.append(title, meta);
        row.append(avatar, body);
        lecturersList.appendChild(row);
    }
    if (!lecturers.length) {
        const empty = document.createElement("p");
        empty.className = "browse-empty";
        empty.textContent = translate("No lecturers have planned classes in this selection yet.");
        lecturersList.appendChild(empty);
    }
}

function renderSessionUnitSelect() {
    const select = $("session-unit");
    select.replaceChildren();
    const programmeId = $("programme-filter").value;
    const mine = units.filter(unit =>
        unit.programme_id === programmeId &&
        (unit.created_by === currentUser.id || myRole() === "admin"));
    for (const unit of mine) {
        const option = document.createElement("option");
        option.value = unit.id;
        option.textContent = unitOptionLabel(unit);
        select.appendChild(option);
    }
    select.disabled = !mine.length;
}

function renderAttendanceRows(list, rows) {
    list.replaceChildren();
    if (!rows.length) {
        const empty = document.createElement("li");
        empty.textContent = translate("Nobody has pressed the code yet.");
        list.appendChild(empty);
        return;
    }
    for (const row of rows) {
        const line = document.createElement("li");
        line.textContent = row.full_name || row.username || translate("Member");
        const detail = document.createElement("span");
        const parts = [
            row.registration_number,
            row.programme && `${row.programme} ${row.study_year}.${row.semester}`,
            row.checked_at ? new Date(row.checked_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : ""
        ].filter(Boolean);
        detail.textContent = parts.length ? ` · ${parts.join(" · ")}` : "";
        line.appendChild(detail);
        list.appendChild(line);
    }
}

function buildLecturerRegister(session) {
    if (!registerReady) return null;
    const box = document.createElement("div");
    box.className = "register-box";
    const state = registerState(session);

    const row = document.createElement("div");
    row.className = "register-row";

    const openButton = document.createElement("button");
    openButton.type = "button";
    openButton.className = "register-button";
    openButton.textContent = translate("Open register");

    const listButton = document.createElement("button");
    listButton.type = "button";
    listButton.className = "register-button ghost";
    listButton.textContent = translate("Attendance list");

    const code = document.createElement("span");
    code.className = "register-code";
    code.textContent = state.open ? (session.checkin_code || "") : "";

    const status = document.createElement("div");
    const list = document.createElement("ul");
    list.className = "register-list";
    list.hidden = true;

    if (state.open) {
        status.replaceChildren(note(`${translate("Open for")} ${state.minutesLeft} ${translate("min")}`, "success"));
    }

    openButton.addEventListener("click", async () => {
        openButton.disabled = true;
        const result = await openRegister(supabase, { classId: session.id, minutes: REGISTER_WINDOW_MINUTES });
        openButton.disabled = false;
        if (!result.ok) {
            status.replaceChildren(note(result.message, "error"));
            if (result.missing) {
                registerReady = false;
                renderManagedList();
            }
            return;
        }
        const now = Date.now();
        session.checkin_code = result.code;
        session.checkin_opens_at = new Date(now).toISOString();
        session.checkin_expires_at = new Date(now + REGISTER_WINDOW_MINUTES * 60000).toISOString();
        code.textContent = result.code;
        status.replaceChildren(note(result.message, "success"));
    });

    listButton.addEventListener("click", async () => {
        listButton.disabled = true;
        const result = await loadAttendance(supabase, { classId: session.id });
        listButton.disabled = false;
        if (!result.rows) {
            status.replaceChildren(note(result.message, "error"));
            if (result.missing) {
                registerReady = false;
                renderManagedList();
            }
            return;
        }
        renderAttendanceRows(list, result.rows);
        list.hidden = false;
        status.replaceChildren(note(`${translate("On the list")}: ${result.rows.length}`, "success"));
    });

    row.append(openButton, listButton, code, status);
    box.append(row, list);
    return box;
}

function renderManagedList() {
    const list = $("managed-list");
    if (!list) return;
    list.replaceChildren();
    if (!canManage()) return;

    const myUnits = units.filter(unit => unit.created_by === currentUser.id || myRole() === "admin");
    const mySessions = sessions.filter(session => session.lecturer_id === currentUser.id || myRole() === "admin");
    const unitById = new Map(units.map(unit => [unit.id, unit]));

    for (const unit of myUnits) {
        const row = document.createElement("div");
        row.className = "managed-row";
        const label = document.createElement("span");
        label.textContent = `${translate("Unit")}: ${unitOptionLabel(unit)}`;
        const remove = document.createElement("button");
        remove.type = "button";
        remove.className = "managed-delete";
        remove.textContent = translate("Remove");
        remove.addEventListener("click", async () => {
            if (!window.confirm(translate("Remove this unit and its class plans?"))) return;
            const { error } = await supabase.from("units").delete().eq("id", unit.id);
            if (error) showNotice(`Could not remove the unit: ${error.message}`, true);
            else await loadCatalogue();
        });
        row.append(label, remove);
        list.appendChild(row);
    }

    for (const session of mySessions) {
        const unit = unitById.get(session.unit_id);
        const row = document.createElement("div");
        row.className = "managed-row wrap";
        const label = document.createElement("span");
        label.textContent = `${translate("Class")}: ${unit ? unit.code : "?"} · ${translate(WEEKDAYS[session.weekday])} ${formatTime(session.start_time)}–${formatTime(session.end_time)} · ${session.mode === "online" ? translate("Online") : session.location}`;
        const remove = document.createElement("button");
        remove.type = "button";
        remove.className = "managed-delete";
        remove.textContent = translate("Remove");
        remove.addEventListener("click", async () => {
            if (!window.confirm(translate("Remove this class plan?"))) return;
            const { error } = await supabase.from("class_sessions").delete().eq("id", session.id);
            if (error) showNotice(`Could not remove the class plan: ${error.message}`, true);
            else await loadCatalogue();
        });
        const register = buildLecturerRegister(session);
        row.append(label, remove);
        if (register) row.appendChild(register);
        list.appendChild(row);
    }

    if (!myUnits.length && !mySessions.length) {
        const hint = document.createElement("p");
        hint.className = "session-meta";
        hint.textContent = translate("Nothing added yet. Create a unit, then plan its weekly class.");
        list.appendChild(hint);
    }
}

$("programme-filter").addEventListener("change", () => {
    populateYearSelects();
    renderProgrammeInfo();
    renderTimetable();
    renderExplore();
    renderSessionUnitSelect();
});
$("level-filter").addEventListener("change", () => {
    populateProgrammeSelect();
    renderTimetable();
    renderExplore();
    renderSessionUnitSelect();
});
$("year-filter").addEventListener("change", () => { renderTimetable(); renderExplore(); });
$("semester-filter").addEventListener("change", () => { renderTimetable(); renderExplore(); });

async function saveMyStudies(clear) {
    if (!currentUser) return;
    const programme = selectedProgramme();
    if (!clear && !programme) {
        showNotice("Pick a programme at the top first.", true);
        return;
    }
    const values = clear ? {
        programme_id: null,
        study_year: null,
        semester: null
    } : {
        programme_id: programme.id,
        study_year: Number($("study-year").value) || 1,
        semester: Number($("study-semester").value) || 1
    };
    const { error } = await supabase.from("profiles").update(values).eq("id", currentUser.id);
    if (error) {
        showNotice(clear
            ? `Could not remove your programme: ${error.message}`
            : `Could not save your programme: ${error.message}`.trim(), true);
        return;
    }
    await loadMyProfile();
    renderMyClassLine();
    showNotice(clear
        ? translate("Your programme was removed from your profile.")
        : translate(`Saved: ${programme.name} (${levelLabel(values)}).`));
}

$("save-studies").addEventListener("click", () => void saveMyStudies(false));
$("clear-studies").addEventListener("click", () => void saveMyStudies(true));

/* The private corner of the lecturer area: he fixes the one programme his work
   belongs to. The list is the school's own catalogue, so nothing invented can
   be saved; only his profile row is written; and every lecturer keeps exactly
   the same tools either way. */
function renderMyProgramme() {
    const select = $("my-programme");
    if (!select) return;
    const current = myProfile?.programme_id || "";
    select.replaceChildren();
    const blank = document.createElement("option");
    blank.value = "";
    blank.textContent = translate("Not fixed yet");
    select.append(blank);
    const schools = new Map();
    for (const programme of programmes) {
        if (!schools.has(programme.school)) schools.set(programme.school, []);
        schools.get(programme.school).push(programme);
    }
    for (const [school, list] of schools) {
        const group = document.createElement("optgroup");
        group.label = school;
        for (const programme of list) {
            const option = document.createElement("option");
            option.value = programme.id;
            option.textContent = programme.name;
            group.appendChild(option);
        }
        select.appendChild(group);
    }
    if (current && programmeById(current)) select.value = current;
    const chosen = programmeById(current);
    $("my-programme-line").textContent = chosen
        ? `${translate("Fixed:")} ${chosen.name} · ${chosen.school}`
        : translate("Pick the programme you teach. You can change it whenever you want.");
}

async function saveMyProgramme() {
    if (!currentUser) return;
    const programmeId = $("my-programme").value || null;
    const { error } = await supabase
        .from("profiles")
        .update({ programme_id: programmeId })
        .eq("id", currentUser.id);
    if (error) {
        showNotice(`Could not save your programme: ${error.message}`, true);
        return;
    }
    await loadMyProfile();
    renderMyProgramme();
    populateProgrammeSelect();
    showNotice(programmeId
        ? `${translate("Fixed:")} ${programmeById(programmeId)?.name || ""}`.trim()
        : translate("Your programme was removed from your profile."));
}

$("save-my-programme").addEventListener("click", () => void saveMyProgramme());

$("session-mode").addEventListener("change", () => {
    const online = $("session-mode").value === "online";
    $("session-online-field").hidden = !online;
    $("session-room-field").hidden = online;
});

$("unit-form").addEventListener("submit", async event => {
    event.preventDefault();
    if (!canManage()) return;
    const programmeId = $("programme-filter").value;
    if (!programmeId) return;
    const code = $("unit-code").value.trim().toUpperCase();
    const title = $("unit-title").value.trim();
    if (!/^[A-Z][-. /A-Z0-9]{1,15}$/.test(code)) {
        showNotice("Unit codes start with a letter and use letters, numbers, dots, slashes or spaces (2-16 characters).", true);
        return;
    }
    if (title.length < 2) {
        showNotice("Give the unit a title.", true);
        return;
    }
    const { error } = await supabase.from("units").insert({
        programme_id: programmeId,
        code,
        title,
        study_year: Number($("unit-year").value) || 1,
        semester: Number($("unit-semester").value) || 1,
        created_by: currentUser.id
    });
    if (error) {
        showNotice(error.code === "23505"
            ? `The code ${code} already exists in this programme.`
            : `Could not add the unit: ${error.message}`, true);
        return;
    }
    $("unit-code").value = "";
    $("unit-title").value = "";
    showNotice(translate("Unit added."));
    await loadCatalogue();
});

$("session-form").addEventListener("submit", async event => {
    event.preventDefault();
    if (!canManage()) return;
    const unitId = $("session-unit").value;
    if (!unitId) {
        showNotice("Add a unit first, then plan its class.", true);
        return;
    }
    const startTime = $("session-start").value;
    const endTime = $("session-end").value;
    if (!startTime || !endTime || endTime <= startTime) {
        showNotice("The class must end after it starts.", true);
        return;
    }
    const mode = $("session-mode").value;
    const link = $("session-link").value.trim();
    if (mode === "online" && !/^https?:\/\/.+/.test(link)) {
        showNotice("Online classes need a full meeting link (https://...).", true);
        return;
    }
    const { error } = await supabase.from("class_sessions").insert({
        unit_id: unitId,
        lecturer_id: currentUser.id,
        weekday: Number($("session-weekday").value),
        start_time: startTime,
        end_time: endTime,
        mode,
        location: mode === "physical" ? $("session-location").value.trim() : "",
        link: mode === "online" ? link : "",
        note: $("session-note").value.trim()
    });
    if (error) {
        showNotice(`Could not save the class plan: ${error.message}`, true);
        return;
    }
    $("session-note").value = "";
    showNotice(translate("Class plan saved."));
    await loadCatalogue();
});

async function initialize() {
    renderThemeLabel();
    try {
        ({ supabase } = await import("../lib/supabase.js"));
        clearPreloadRetry();
        const boot = await resolveBootUser(supabase);
        currentUser = boot.user;
        setOfflineBanner(boot.offline);
        if (sendMembersToBulletin(currentUser)) return;
        if (!currentUser) {
            showNotice("Sign in on the home page to open Classes.", true);
            return;
        }
        await loadMyProfile();
        void ensureStaffAccess();
        if (!(await ensureClassAccess(myProfile))) return;
        await loadCatalogue();
        renderSessionUnitSelect();
    } catch (error) {
        console.error("Could not initialize classes:", error);
        showNotice(error.message || "Classes could not connect.", true);
    }
}

document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible" && currentUser && catalogueReady) {
        void loadCatalogue();
    }
});

void initialize();
