import "../lib/compat.js";
import "../lib/native-feel.js";
import { installVitePreloadRecovery } from "../lib/vite-preload-recovery.js";
import { initializeLanguageSelector, translate } from "../lib/language.js";
import { initializeTheme, isDark, toggleThemeMode } from "../lib/theme.js";
import { initializeAppInstallation } from "../lib/pwa.js";
import { supabase } from "../lib/supabase.js";
import { resolveBootUser } from "../lib/offline-session.js";
import { setOfflineBanner } from "../lib/offline-banner.js";
import { showSetupCard } from "../lib/db-setup.js";
import {
    addChaplaincyEvent,
    addHostel,
    addMealPlan,
    addRoom,
    answerPrayerRequest,
    bookHostelRoom,
    cancelBedRequest,
    clearCampusServices,
    decideBed,
    isCampusServicesMissing,
    loadBedRequestsForSchool,
    loadHostelAvailability,
    loadCampusServices,
    loadMyBedRequests,
    loadPrayerRequests,
    normalizeSchool,
    saveSchoolSwitches,
    updateHostelRoom,
    sendPrayerRequest
} from "../lib/campus-services.js";
import { readNumberFromPhoto } from "../lib/read-number.js";
import {
    FOUND_KINDS,
    KEPT_PLACES,
    foundKindLabel,
    isFoundItemsMissing,
    keptPlaceLabel,
    loadMyFoundItems,
    loadMyFoundReports,
    loadSchoolFoundItems,
    markFoundItemSeen,
    reportFoundItem,
    resolveFoundPhoto,
    setFoundItemResult
} from "../lib/found-items.js";

const clearPreloadRetry = installVitePreloadRecovery();
initializeLanguageSelector();
initializeAppInstallation();

const $ = id => document.getElementById(id);
const themeToggle = $("theme-toggle");

function renderThemeLabel() {
    themeToggle.textContent = translate(isDark() ? "☀️ Day Mode" : "🌙 Night Mode");
    themeToggle.setAttribute("aria-pressed", String(isDark()));
}

initializeTheme(renderThemeLabel);
themeToggle.addEventListener("click", () => {
    toggleThemeMode();
    renderThemeLabel();
});

const DEPARTMENTS = [
    { key: "accommodation", label: "🏠 Hostels", section: "bed-section" },
    { key: "catering", label: "🍽 Catering", section: "catering-section" },
    { key: "chaplaincy", label: "✝ Chaplaincy", section: "chaplaincy-section" }
];
const WEEKDAYS = ["", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

let user = null;
let profile = null;
let school = "";
let pack = null;
let packReady = false;
let hostelGenderFilter = "";
let selectedHostelId = "";
let myBeds = [];
let officeBeds = [];
let roomAvailability = new Map();
let roomAvailabilityReady = false;
let prayers = [];
let myFounds = [];
let myReports = [];
let deskFounds = [];

function state(message) {
    const element = $("page-status");
    element.textContent = translate(message);
    element.hidden = !message;
}

function setStatus(element, message, kind = "") {
    element.textContent = translate(message);
    element.className = `status ${kind}`.trim();
}

function loadFailed(message) {
    state(message);
    $("none-panel").hidden = true;
    $("dept-chips").hidden = true;
    DEPARTMENTS.forEach(department => { $(department.section).hidden = true; });
}

function moneyOf(value) {
    const amount = Number(value);
    if (!Number.isFinite(amount) || amount <= 0) return "";
    return `KES ${amount.toLocaleString("en-KE")}`;
}

function suggestedSemester() {
    const now = new Date();
    const year = now.getFullYear();
    return now.getMonth() >= 7 ? `${year}/${year + 1}-1` : `${year - 1}/${year}-2`;
}

/* Database words are never shown as they are - each one is looked up here
   first so every language gets a sentence rather than a code. */
const GENDER_LABELS = { men: "Men", women: "Women", mixed: "Mixed" };
const BED_STATUS = {
    pending: "waiting for the office",
    approved: "booked",
    rejected: "refused",
    cancelled: "withdrawn"
};
const MEAL_KINDS = {
    full: "Three meals a day",
    half: "Two meals a day",
    light: "One meal a day",
    self_catering: "Self catering",
    other: "Other"
};
const EVENT_KINDS = {
    chapel: "Chapel service",
    crusade: "Crusade",
    prayer: "Prayer meeting",
    fellowship: "Fellowship",
    service: "Worship service",
    retreat: "Retreat",
    other: "Something else"
};
const REQUEST_KINDS = {
    prayer: "A prayer",
    counsel: "Someone to talk to",
    thanksgiving: "Thanks",
    other: "Something else"
};

function isOffice() {
    if (!profile) return false;
    if (profile.role === "admin") return true;
    const sameSchool = normalizeSchool(profile.university) === normalizeSchool(school);
    return sameSchool
        && (profile.role === "lecturer" || profile.role === "security")
        && profile.employment_status !== "passive";
}

function isChaplain() {
    if (!profile) return false;
    if (profile.role === "admin") return true;
    return profile.role === "chaplain"
        && normalizeSchool(profile.university) === normalizeSchool(school);
}

/* ------------------------------------------------------------
 * Chips and section visibility
 * ------------------------------------------------------------ */

function renderChips() {
    const row = $("dept-chips");
    if (!packReady) {
        row.hidden = true;
        return;
    }
    const open = DEPARTMENTS.filter(department => Boolean(pack?.switches?.[department.key]));
    row.hidden = !open.length;
    row.replaceChildren(...open.map(department => {
        const chip = document.createElement("a");
        chip.className = "dept-chip on";
        chip.href = `#${department.section}`;
        chip.textContent = translate(department.label);
        return chip;
    }));
    DEPARTMENTS.forEach(department => {
        $(department.section).hidden = !open.some(item => item.key === department.key);
    });
    $("none-panel").hidden = Boolean(pack?.switches) && open.length > 0;
}

/* ------------------------------------------------------------
 * Accommodation
 * ------------------------------------------------------------ */

function bedRow(bed) {
    const card = document.createElement("div");
    card.className = "uni-card";
    const head = document.createElement("div");
    head.className = "uni-head";
    const name = document.createElement("h3");
    name.className = "uni-name";
    name.textContent = `${bed.hostel_name || bed.hostel || "—"} · ${bed.room_label || bed.room}`;
    const meta = document.createElement("span");
    meta.className = "uni-meta";
    meta.textContent = `${bed.semester} · ${translate(BED_STATUS[bed.status] || "waiting for the office")}`;
    head.append(name, meta);
    card.appendChild(head);

    if (bed.request_note) {
        const note = document.createElement("p");
        note.className = "uni-note";
        note.textContent = bed.request_note;
        card.appendChild(note);
    }
    if (bed.decision_note) {
        const note = document.createElement("p");
        note.className = "uni-note";
        note.textContent = `${translate("The office said")}: ${bed.decision_note}`;
        card.appendChild(note);
    }

    if (bed.status === "pending" || bed.status === "approved") {
        const cancel = document.createElement("button");
        cancel.type = "button";
        cancel.textContent = translate(bed.status === "approved" ? "Cancel this booking" : "Withdraw this request");
        cancel.addEventListener("click", async () => {
            cancel.disabled = true;
            const done = await cancelBedRequest(supabase, bed.booking_id || bed.id);
            state(done.message);
            if (done.ok) {
                await refreshBeds();
                await refreshRoomAvailability();
            }
            else cancel.disabled = false;
        });
        card.appendChild(cancel);
    }
    return card;
}

function roomRow(hostel, room) {
    const row = document.createElement("div");
    row.className = "room-row";
    const label = document.createElement("span");
    label.className = "room-label";
    label.textContent = room.label;
    const meta = document.createElement("span");
    meta.className = "room-meta";
    const fee = moneyOf(room.fee_semester);
    const available = roomAvailability.get(room.id);
    meta.textContent = [
        `${translate("Room capacity")}: ${room.capacity}`,
        available === undefined ? "" : `${available} ${translate("available")}`,
        room.meal_included ? translate("meals included") : "",
        fee ? `${translate("fee")} ${fee}` : ""
    ].filter(Boolean).join(" · ");
    row.append(label, meta);

    if (!user || profile?.role !== "student") return row;

    const ask = document.createElement("button");
    ask.type = "button";
    ask.className = "go";
    ask.textContent = translate("Book a place");
    ask.disabled = available === undefined || available < 1;
    if (available === undefined) ask.textContent = translate("Loading availability");
    else if (available < 1) ask.textContent = translate("Fully booked");
    ask.addEventListener("click", () => openAskForm(row, hostel, room, ask));
    row.appendChild(ask);
    return row;
}

/* The form for one room appears under that room, so the page never uses a
   browser dialog - an APK has no dialog box to answer. */
function openAskForm(row, hostel, room, ask) {
    if (row.querySelector(".ask-form")) {
        row.querySelector(".ask-form").remove();
        ask.textContent = translate("Book a place");
        return;
    }
    ask.textContent = translate("Close");
    const form = document.createElement("div");
    form.className = "ask-form";
    form.style.flexBasis = "100%";

    const semester = document.createElement("input");
    semester.type = "text";
    semester.maxLength = 40;
    semester.value = suggestedSemester();
    semester.setAttribute("aria-label", translate("Which semester"));

    const note = document.createElement("input");
    note.type = "text";
    note.maxLength = 400;
    note.placeholder = translate("Anything the office should know");
    note.setAttribute("aria-label", translate("Anything the office should know"));

    const send = document.createElement("button");
    send.type = "button";
    send.className = "go";
    send.textContent = translate("Confirm booking");
    send.addEventListener("click", async () => {
        send.disabled = true;
        const done = await bookHostelRoom(supabase, { roomId: room.id, semester: semester.value, note: note.value });
        setStatus($("hostel-status"), done.message, done.ok ? "success" : "error");
        if (done.missing) mountSetupCard();
        if (done.ok) {
            form.remove();
            await refreshBeds();
            await refreshRoomAvailability();
        } else {
            send.disabled = false;
            await refreshRoomAvailability();
        }
    });

    const style = { width: "100%", margin: "6px 0 0", padding: "8px 10px", border: "1px solid var(--border)", borderRadius: "10px", background: "var(--input)", color: "var(--text)", font: "inherit", fontSize: "14px" };
    Object.assign(semester.style, style);
    Object.assign(note.style, style);
    form.append(semester, note, send);
    row.appendChild(form);
}

function roomOfficeEditor(room) {
    if (!isOffice()) return null;
    const controls = document.createElement("div");
    controls.className = "room-row";
    const label = document.createElement("input");
    label.type = "text";
    label.maxLength = 40;
    label.value = room.label;
    label.setAttribute("aria-label", translate("Official room number"));
    const places = document.createElement("select");
    places.setAttribute("aria-label", translate("Students per room"));
    for (const count of [1, 2, 3]) {
        const option = document.createElement("option");
        option.value = String(count);
        option.textContent = `${count} ${translate(count === 1 ? "student" : "students")}`;
        places.appendChild(option);
    }
    places.value = String([1, 2, 3].includes(Number(room.capacity)) ? room.capacity : 1);
    const save = document.createElement("button");
    save.type = "button";
    save.textContent = translate("Save room details");
    save.addEventListener("click", async () => {
        save.disabled = true;
        const result = await updateHostelRoom(supabase, { roomId: room.id, label: label.value, capacity: places.value });
        setStatus($("hostel-status"), result.message, result.ok ? "success" : "error");
        if (result.ok) await loadSchool(school);
        else save.disabled = false;
    });
    const style = { minWidth: "110px", padding: "8px 10px", border: "1px solid var(--border)", borderRadius: "10px", background: "var(--input)", color: "var(--text)", font: "inherit", fontSize: "14px" };
    Object.assign(label.style, style);
    Object.assign(places.style, style);
    controls.append(label, places, save);
    return controls;
}

function renderHostels() {
    const list = $("hostel-list");
    list.replaceChildren();
    const hostels = pack?.hostels || [];
    if (!hostels.length) {
        const empty = document.createElement("p");
        empty.className = "state";
        empty.textContent = translate("This school has not named a hostel yet. Somebody who works there adds the first one below.");
        list.appendChild(empty);
    }
    if (hostels.length) {
        const categories = document.createElement("div");
        categories.className = "room-row";
        categories.setAttribute("aria-label", selectedHostelId ? "Return to hostels" : hostelGenderFilter ? "Return to hostel categories" : "Choose a hostel category");
        if (selectedHostelId) {
            const back = document.createElement("button");
            back.type = "button";
            back.textContent = "< Back to hostels";
            back.addEventListener("click", () => {
                selectedHostelId = "";
                renderHostels();
            });
            categories.appendChild(back);
        } else if (hostelGenderFilter) {
            const back = document.createElement("button");
            back.type = "button";
            back.textContent = "< Back to hostel options";
            back.addEventListener("click", () => {
                hostelGenderFilter = "";
                renderHostels();
            });
            categories.appendChild(back);
        } else {
            for (const category of [
                { gender: "women", label: "Women's hostels" },
                { gender: "men", label: "Men's hostels" }
            ]) {
                const button = document.createElement("button");
                button.type = "button";
                button.className = "go";
                button.textContent = category.label;
                button.setAttribute("aria-pressed", "false");
                button.addEventListener("click", () => {
                    hostelGenderFilter = category.gender;
                    selectedHostelId = "";
                    renderHostels();
                });
                categories.appendChild(button);
            }
        }
        list.appendChild(categories);
    }
    const visibleHostels = hostelGenderFilter
        ? hostels.filter(hostel => hostel.gender === hostelGenderFilter || hostel.gender === "mixed")
        : [];
    if (selectedHostelId && !visibleHostels.some(hostel => hostel.id === selectedHostelId)) {
        selectedHostelId = "";
    }
    if (hostelGenderFilter && !selectedHostelId) {
        for (const hostel of visibleHostels) {
            const button = document.createElement("button");
            button.type = "button";
            button.className = "go";
            const available = hostel.rooms.filter(room => (roomAvailability.get(room.id) || 0) > 0).length;
            const count = profile?.role === "student" && roomAvailabilityReady
                ? `${available} rooms available`
                : `${hostel.rooms.length} rooms`;
            button.textContent = `${hostel.name} · ${count}`;
            button.style.cssText = "display:block;width:100%;margin:8px 0;text-align:left";
            button.addEventListener("click", () => {
                selectedHostelId = hostel.id;
                renderHostels();
            });
            list.appendChild(button);
        }
    }
    const chosenHostel = selectedHostelId
        ? visibleHostels.find(hostel => hostel.id === selectedHostelId)
        : null;
    for (const hostel of (chosenHostel ? [chosenHostel] : [])) {
        const card = document.createElement("div");
        card.className = "uni-card";
        const head = document.createElement("div");
        head.className = "uni-head";
        const name = document.createElement("h3");
        name.className = "uni-name";
        name.textContent = hostel.name;
        const chip = document.createElement("span");
        chip.className = `kind-chip kind-${hostel.gender}`;
        chip.textContent = translate(GENDER_LABELS[hostel.gender] || "Mixed");
        head.append(name, chip);
        if (hostel.address || hostel.note) {
            const meta = document.createElement("span");
            meta.className = "uni-meta";
            meta.textContent = [hostel.address, hostel.note].filter(Boolean).join(" · ");
            head.appendChild(meta);
        }
        card.appendChild(head);

        const roomCount = document.createElement("p");
        roomCount.className = "uni-meta";
        const studentView = profile?.role === "student";
        const availableRoomCount = hostel.rooms.filter(room => (roomAvailability.get(room.id) || 0) > 0).length;
        roomCount.textContent = studentView
            ? roomAvailabilityReady
                ? `${availableRoomCount} / ${hostel.rooms.length} ${translate("rooms available this semester")}`
                : translate("Checking room availability")
            : `${hostel.rooms.length} ${translate("rooms listed")}`;
        card.appendChild(roomCount);

        if (studentView && !roomAvailabilityReady) {
            const waiting = document.createElement("p");
            waiting.className = "uni-note";
            waiting.textContent = translate("Room availability is unavailable. Apply the latest hostel booking database update.");
            card.appendChild(waiting);
        } else if (!hostel.rooms.length) {
            const none = document.createElement("p");
            none.className = "uni-note";
            none.textContent = translate("No room has been listed here yet.");
            card.appendChild(none);
        } else if (studentView && availableRoomCount < 1) {
            const none = document.createElement("p");
            none.className = "uni-note";
            none.textContent = translate("No rooms are available for this semester.");
            card.appendChild(none);
        }
        const visibleRooms = studentView
            ? hostel.rooms.filter(room => (roomAvailability.get(room.id) || 0) > 0)
            : hostel.rooms;
        for (const room of visibleRooms) {
            card.appendChild(roomRow(hostel, room));
            const editor = roomOfficeEditor(room);
            if (editor) card.appendChild(editor);
        }
        list.appendChild(card);
    }

    const select = $("room-hostel");
    select.replaceChildren(...hostels.map(hostel => {
        const option = document.createElement("option");
        option.value = hostel.id;
        option.textContent = hostel.name;
        return option;
    }));
    $("hostel-add-panel").hidden = !isOffice();
    $("office-panel").hidden = !isOffice();
}

function renderBeds() {
    const mine = $("my-bed-list");
    mine.replaceChildren();
    $("my-bed-heading").hidden = !myBeds.length;
    for (const bed of myBeds) mine.appendChild(bedRow(bed));

    const office = $("office-list");
    office.replaceChildren();
    for (const bed of officeBeds) {
        const card = document.createElement("div");
        card.className = "uni-card";
        const head = document.createElement("div");
        head.className = "uni-head";
        const name = document.createElement("h3");
        name.className = "uni-name";
        name.textContent = `${bed.student_name || translate("A student")} · ${bed.hostel_name} ${bed.room_label}`;
        const meta = document.createElement("span");
        meta.className = "uni-meta";
        const approved = `${bed.beds_approved || 0}/${bed.room_capacity || "?"}`;
        meta.textContent = `${bed.semester} · ${translate(BED_STATUS[bed.status] || bed.status)} · ${translate("beds given")} ${approved}`;
        head.append(name, meta);
        card.appendChild(head);

        if (bed.registration_number) {
            const reg = document.createElement("p");
            reg.className = "uni-note";
            reg.textContent = bed.registration_number;
            card.appendChild(reg);
        }
        if (bed.request_note) {
            const note = document.createElement("p");
            note.className = "uni-note";
            note.textContent = bed.request_note;
            card.appendChild(note);
        }

        if (bed.status === "pending") {
            const decide = document.createElement("div");
            decide.className = "room-row";
            const note = document.createElement("input");
            note.type = "text";
            note.maxLength = 400;
            note.placeholder = translate("Say why, so the student knows");
            note.setAttribute("aria-label", translate("Say why, so the student knows"));
            note.style.cssText = "flex:1;min-width:140px;padding:8px 10px;border:1px solid var(--border);border-radius:10px;background:var(--input);color:var(--text);font:inherit;font-size:14px";
            decide.appendChild(note);
            for (const decision of ["approved", "rejected"]) {
                const button = document.createElement("button");
                button.type = "button";
                button.className = decision === "approved" ? "go" : "";
                button.textContent = translate(decision === "approved" ? "Give the bed" : "Refuse");
                button.addEventListener("click", async () => {
                    button.disabled = true;
                    const done = await decideBed(supabase, { bookingId: bed.booking_id, decision, note: note.value });
                    setStatus($("office-status"), done.message, done.ok ? "success" : "error");
                    if (done.ok) await refreshBeds();
                    else button.disabled = false;
                });
                decide.appendChild(button);
            }
            card.appendChild(decide);
        }
        office.appendChild(card);
    }
    if (isOffice() && !officeBeds.length) {
        const empty = document.createElement("p");
        empty.className = "state";
        empty.textContent = translate("No bed is waiting for a decision.");
        office.appendChild(empty);
    }
}

async function refreshBeds() {
    myBeds = user ? (await loadMyBedRequests(supabase)) || [] : [];
    officeBeds = isOffice() ? (await loadBedRequestsForSchool(supabase, school)) || [] : [];
    renderBeds();
}

async function refreshRoomAvailability() {
    roomAvailabilityReady = false;
    roomAvailability = new Map();
    if (user) {
        const availability = await loadHostelAvailability(supabase, { school, semester: suggestedSemester() });
        roomAvailability = availability || new Map();
        roomAvailabilityReady = Boolean(availability);
    }
    renderHostels();
}

/* ------------------------------------------------------------
 * Catering
 * ------------------------------------------------------------ */

function renderMeals() {
    const list = $("meal-list");
    list.replaceChildren();
    const plans = pack?.mealPlans || [];
    if (!plans.length) {
        const empty = document.createElement("p");
        empty.className = "state";
        empty.textContent = translate("The catering office has not put a plan up yet.");
        list.appendChild(empty);
    }
    for (const plan of plans) {
        const card = document.createElement("div");
        card.className = "uni-card";
        const head = document.createElement("div");
        head.className = "uni-head";
        const name = document.createElement("h3");
        name.className = "uni-name";
        name.textContent = plan.name;
        const chip = document.createElement("span");
        chip.className = "kind-chip kind-site";
        chip.textContent = translate(MEAL_KINDS[plan.kind] || "Other");
        head.append(name, chip);
        card.appendChild(head);

        const price = [moneyOf(plan.price_weekly) && `${translate("per week")} ${moneyOf(plan.price_weekly)}`,
            moneyOf(plan.price_semester) && `${translate("per semester")} ${moneyOf(plan.price_semester)}`]
            .filter(Boolean).join(" · ");
        if (price) {
            const meta = document.createElement("p");
            meta.className = "uni-meta";
            meta.textContent = price;
            card.appendChild(meta);
        }
        if (plan.menu) {
            const menu = document.createElement("p");
            menu.className = "uni-note";
            menu.textContent = plan.menu;
            menu.style.whiteSpace = "pre-line";
            card.appendChild(menu);
        }
        if (plan.note) {
            const note = document.createElement("p");
            note.className = "uni-note";
            note.textContent = plan.note;
            card.appendChild(note);
        }
        list.appendChild(card);
    }
    $("meal-add-panel").hidden = !isOffice();
}

/* ------------------------------------------------------------
 * Chaplaincy
 * ------------------------------------------------------------ */

function eventLine(event) {
    const card = document.createElement("div");
    card.className = "uni-card";
    const head = document.createElement("div");
    head.className = "uni-head";
    const name = document.createElement("h3");
    name.className = "uni-name";
    name.textContent = event.title;
    const chip = document.createElement("span");
    chip.className = "kind-chip kind-site";
    chip.textContent = translate(EVENT_KINDS[event.kind] || "Worship service");
    head.append(name, chip);
    if (event.term) {
        const term = document.createElement("span");
        term.className = "uni-meta";
        term.textContent = event.term;
        head.appendChild(term);
    }
    card.appendChild(head);

    const when = event.repeat !== "none"
        ? `${translate("Every")} ${translate(WEEKDAYS[event.weekday] || "")} ${event.start_time || ""}`
        : formatWhen(event.starts_at, event.ends_at);
    const meta = document.createElement("p");
    meta.className = "uni-meta";
    meta.textContent = [when, event.venue].filter(Boolean).join(" · ");
    card.appendChild(meta);

    if (event.description) {
        const note = document.createElement("p");
        note.className = "uni-note";
        note.textContent = event.description;
        card.appendChild(note);
    }
    if (event.contact) {
        const contact = document.createElement("p");
        contact.className = "uni-note";
        contact.textContent = `${translate("Ask")}: ${event.contact}`;
        card.appendChild(contact);
    }
    return card;
}

function formatWhen(startsAt, endsAt) {
    const start = new Date(startsAt);
    if (Number.isNaN(start.getTime())) return "";
    const date = start.toLocaleDateString(undefined, { weekday: "short", day: "numeric", month: "short", year: "numeric" });
    const time = start.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" });
    if (!endsAt) return `${date} · ${time}`;
    const end = new Date(endsAt);
    if (Number.isNaN(end.getTime())) return `${date} · ${time}`;
    const sameDay = end.toDateString() === start.toDateString();
    return sameDay
        ? `${date} · ${time}–${end.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" })}`
        : `${date} · ${time} → ${end.toLocaleDateString(undefined, { day: "numeric", month: "short" })}`;
}

function renderEvents() {
    const list = $("event-list");
    list.replaceChildren();
    const events = pack?.events || [];
    if (!events.length) {
        const empty = document.createElement("p");
        empty.className = "state";
        empty.textContent = translate("The chaplaincy has not published this year's programme yet.");
        list.appendChild(empty);
        return;
    }
    const byTerm = new Map();
    for (const event of events) {
        const term = event.term || translate("Undated");
        if (!byTerm.has(term)) byTerm.set(term, []);
        byTerm.get(term).push(event);
    }
    for (const [term, items] of byTerm) {
        const heading = document.createElement("div");
        heading.className = "uni-meta";
        heading.textContent = term;
        list.appendChild(heading);
        for (const event of items) list.appendChild(eventLine(event));
    }
    $("event-add-panel").hidden = !isChaplain();
    $("prayer-panel").hidden = !isChaplain();
    renderPrayers();
}

function renderPrayers() {
    const list = $("prayer-list");
    list.replaceChildren();
    for (const request of prayers) {
        const card = document.createElement("div");
        card.className = "uni-card";
        const body = document.createElement("p");
        body.className = "uni-note";
        body.textContent = request.request;
        card.appendChild(body);

        const meta = document.createElement("p");
        meta.className = "uni-meta";
        meta.textContent = `${translate(REQUEST_KINDS[request.kind] || "A prayer")} · ${translate(request.status === "answered" ? "answered" : "waiting")}`;
        card.appendChild(meta);

        if (request.reply) {
            const reply = document.createElement("p");
            reply.className = "uni-note";
            reply.textContent = `${translate("Your reply")}: ${request.reply}`;
            card.appendChild(reply);
        } else if (request.answerable) {
            const box = document.createElement("input");
            box.type = "text";
            box.maxLength = 1000;
            box.placeholder = translate("Write what you want to say back");
            box.setAttribute("aria-label", translate("Write what you want to say back"));
            box.style.cssText = "width:100%;padding:8px 10px;border:1px solid var(--border);border-radius:10px;background:var(--input);color:var(--text);font:inherit;font-size:14px";
            const send = document.createElement("button");
            send.type = "button";
            send.className = "go";
            send.textContent = translate("Reply");
            send.addEventListener("click", async () => {
                send.disabled = true;
                const done = await answerPrayerRequest(supabase, { requestId: request.id, chaplainId: user?.id, reply: box.value });
                setStatus($("prayer-status"), done.message, done.ok ? "success" : "error");
                if (done.ok) await refreshPrayers();
                else send.disabled = false;
            });
            card.append(box, send);
        }
        list.appendChild(card);
    }
    if (isChaplain() && !prayers.length) {
        const empty = document.createElement("p");
        empty.className = "state";
        empty.textContent = translate("Nothing has been sent in.");
        list.appendChild(empty);
    }
}

async function refreshPrayers() {
    prayers = isChaplain() ? (await loadPrayerRequests(supabase)) || [] : [];
    renderPrayers();
}

/* ------------------------------------------------------------
 * Found and lost
 * ------------------------------------------------------------ */

function fillFoundSelects() {
    $("found-kind").replaceChildren(...FOUND_KINDS.map(item => {
        const option = document.createElement("option");
        option.value = item.value;
        option.textContent = translate(item.label);
        return option;
    }));
    $("found-here").replaceChildren(...KEPT_PLACES.map(item => {
        const option = document.createElement("option");
        option.value = item.value;
        option.textContent = translate(item.label);
        return option;
    }));
}

function whenLabel(value) {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "";
    return `${date.toLocaleDateString(undefined, { day: "numeric", month: "short" })} · ` +
        `${date.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" })}`;
}

function actionRow(card, runner, failureTarget) {
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = translate(runner.label);
    if (runner.primary) button.className = "go";
    button.addEventListener("click", async () => {
        button.disabled = true;
        const done = await runner.run();
        setStatus(failureTarget, done.message, done.ok ? "success" : "error");
        if (done.ok) await refreshFound();
        else button.disabled = false;
    });
    card.appendChild(button);
}

/* The owner reads a place, a time and their own number. There is no finder in
   this row because there is no finder in the rows the database sends back. */
function ownerFoundRow(row) {
    const card = document.createElement("div");
    card.className = `uni-card${row.owner_seen_at ? "" : " found-alert"}`;
    const head = document.createElement("div");
    head.className = "uni-head";
    const name = document.createElement("h3");
    name.className = "uni-name";
    name.textContent = translate(row.status === "returned"
        ? "Was found and given back"
        : "Something of yours was found");
    const meta = document.createElement("span");
    meta.className = "uni-meta";
    meta.textContent = `${translate(foundKindLabel(row.kind))}${row.number_key ? ` · ${row.number_key}` : ""}`;
    head.append(name, meta);
    card.append(head);

    const where = document.createElement("p");
    where.className = "uni-note";
    where.textContent = `${translate("Found at")}: ${row.place}`;
    const when = document.createElement("p");
    when.className = "uni-note";
    when.textContent = `${translate("When")}: ${whenLabel(row.found_at)}`;
    const kept = document.createElement("p");
    kept.className = "uni-note";
    kept.textContent = `${translate("It is with")}: ${translate(keptPlaceLabel(row.held_at))}`;
    card.append(where, when, kept);

    if (row.status !== "returned") {
        actionRow(card, {
            label: "I have picked it up",
            primary: true,
            run: () => collectFoundItem(supabase, row.item_id)
        }, $("found-mine-status"));
    }
    if (!row.owner_seen_at) {
        actionRow(card, {
            label: "This is not mine",
            run: () => hideFoundItem(supabase, row.item_id)
        }, $("found-mine-status"));
    }
    return card;
}

async function collectFoundItem(supabase, itemId) {
    const done = await setFoundItemResult(supabase, { itemId, status: "returned" });
    if (done.ok) await markFoundItemSeen(supabase, itemId);
    return done;
}

async function hideFoundItem(supabase, itemId) {
    const done = await markFoundItemSeen(supabase, itemId);
    return done.ok
        ? { ok: true, message: "The alert is gone. The desk still holds the record." }
        : done;
}

function myReportRow(row) {
    const card = document.createElement("div");
    card.className = "uni-card";
    const head = document.createElement("div");
    head.className = "uni-head";
    const name = document.createElement("h3");
    name.className = "uni-name";
    name.textContent = translate(foundKindLabel(row.kind));
    const meta = document.createElement("span");
    meta.className = "uni-meta";
    meta.textContent = `${row.number_key} · ${whenLabel(row.found_at)}`;
    head.append(name, meta);
    card.append(head);

    const where = document.createElement("p");
    where.className = "uni-note";
    where.textContent = `${translate("Found at")}: ${row.place} · ${translate(keptPlaceLabel(row.held_at))}`;
    const answer = document.createElement("p");
    answer.className = "uni-note";
    answer.textContent = row.status === "returned"
        ? translate("Given back.")
        : (row.was_matched
            ? translate("Its owner was told, privately.")
            : translate("No account here carries that number yet."));
    card.append(where, answer);

    if (row.status !== "returned") {
        actionRow(card, {
            label: "It has been given back",
            primary: true,
            run: () => setFoundItemResult(supabase, { itemId: row.item_id, status: "returned" })
        }, $("found-reports-status"));
    }
    return card;
}

/* The desk is the one screen allowed to know whose hands the document passed
   through, and the only screen that can open the photograph. */
function deskFoundRow(row) {
    const card = document.createElement("div");
    card.className = "uni-card";
    const head = document.createElement("div");
    head.className = "uni-head";
    const name = document.createElement("h3");
    name.className = "uni-name";
    name.textContent = `${translate(foundKindLabel(row.kind))} · ${row.number_input || row.number_key || "—"}`;
    const meta = document.createElement("span");
    meta.className = "uni-meta";
    meta.textContent = `${whenLabel(row.found_at)} · ${translate(keptPlaceLabel(row.held_at))}`;
    head.append(name, meta);
    card.append(head);

    const where = document.createElement("p");
    where.className = "uni-note";
    where.textContent = `${translate("Found at")}: ${row.place}`;
    const finder = document.createElement("p");
    finder.className = "uni-note";
    finder.textContent = `${translate("Handed in by")}: ${row.finder_name || "—"}${row.finder_phone ? ` · ${row.finder_phone}` : ""}`;
    card.append(where, finder);

    if (row.owner_name) {
        const owner = document.createElement("p");
        owner.className = "uni-note";
        owner.textContent = `${translate("Belongs to")}: ${row.owner_name}${row.owner_phone ? ` · ${row.owner_phone}` : ""}`;
        card.append(owner);
    }

    if (row.photo_path) {
        const open = document.createElement("button");
        open.type = "button";
        open.textContent = translate("Open the photo");
        open.addEventListener("click", async () => {
            open.disabled = true;
            const url = await resolveFoundPhoto(supabase, row.photo_path);
            if (!url) {
                setStatus($("found-desk-status"), "That photograph could not be opened.", "error");
                open.disabled = false;
                return;
            }
            const image = document.createElement("img");
            image.className = "found-photo";
            image.alt = translate("The photograph of the document");
            image.src = url;
            card.append(image);
            open.remove();
        });
        card.appendChild(open);
    }

    if (row.status !== "returned") {
        actionRow(card, {
            label: "Marked as given back",
            primary: true,
            run: () => setFoundItemResult(supabase, { itemId: row.item_id, status: "returned" })
        }, $("found-desk-status"));
    } else {
        actionRow(card, {
            label: "Open the record again",
            run: () => setFoundItemResult(supabase, { itemId: row.item_id, status: "open" })
        }, $("found-desk-status"));
    }
    return card;
}

function renderFound() {
    const signed = Boolean(user);
    $("found-section").hidden = !signed;
    if (!signed) return;

    const unseen = myFounds.filter(row => !row.owner_seen_at);
    $("found-report-panel").hidden = false;
    $("found-mine-list").replaceChildren(...myFounds.map(ownerFoundRow));
    $("found-mine-panel").hidden = !myFounds.length;
    if (unseen.length) $("found-mine-heading").textContent = translate("🔎 Something of yours was found");
    else $("found-mine-heading").textContent = translate("Things of yours that were found");
    $("found-reports-panel").hidden = !myReports.length;
    $("found-reports-list").replaceChildren(...myReports.map(myReportRow));
    const desk = isOffice() && Boolean(school);
    $("found-desk-panel").hidden = !desk;
    if (desk) $("found-desk-list").replaceChildren(...deskFounds.map(deskFoundRow));
}

async function refreshFound() {
    if (!user) {
        myFounds = [];
        myReports = [];
        deskFounds = [];
        renderFound();
        return;
    }
    const wanted = isOffice() && Boolean(school);
    const results = await Promise.all([
        loadMyFoundItems(supabase),
        loadMyFoundReports(supabase),
        wanted ? loadSchoolFoundItems(supabase, school) : Promise.resolve([])
    ]);
    myFounds = results[0] || [];
    myReports = results[1] || [];
    deskFounds = results[2] || [];
    renderFound();
    if (isFoundItemsMissing()) {
        $("found-section").hidden = true;
        mountSetupCard();
    }
}

/* ------------------------------------------------------------
 * The whole page
 * ------------------------------------------------------------ */

function render() {
    renderChips();
    if (!packReady) return;
    $("switch-panel").hidden = !isOffice();
    const switches = pack?.switches;
    $("switch-accommodation").checked = Boolean(switches?.accommodation);
    $("switch-catering").checked = Boolean(switches?.catering);
    $("switch-chaplaincy").checked = Boolean(switches?.chaplaincy);
    renderHostels();
    renderBeds();
    renderMeals();
    renderEvents();
}

async function loadSchool(name) {
    school = String(name || "").trim();
    $("school-input").value = school;
    if (!school) {
        packReady = false;
        pack = null;
        render();
        state("Type your school's name to see what it offers.");
        return;
    }
    state("Reading what this school offers…");
    $("none-panel").hidden = true;
    const result = await loadCampusServices(supabase, school, { force: true });
    packReady = Boolean(result);
    pack = result;
    if (!result) {
        DEPARTMENTS.forEach(department => { $(department.section).hidden = true; });
        $("dept-chips").hidden = true;
        loadFailed(isCampusServicesMissing()
            ? "The campus service tables have not been created in your database yet."
            : "This school could not be read. Check your connection.");
        if (isCampusServicesMissing()) mountSetupCard();
        return;
    }
    state("");
    render();
    await Promise.all([refreshBeds(), refreshPrayers(), refreshRoomAvailability()]);
}

function mountSetupCard() {
    showSetupCard({
        target: $("page-status"),
        reason: "The campus service tables are the ones the setup file creates. Run it once and this page fills up."
    });
}

async function readMyProfile() {
    profile = null;
    if (!user) return;
    const { data } = await supabase
        .from("profiles")
        .select("id, full_name, role, university, employment_status")
        .eq("id", user.id)
        .maybeSingle();
    profile = data || null;
    if (!profile?.university) {
        const claim = String(user.user_metadata?.university || "").trim();
        if (claim) profile = { ...(profile || { id: user.id, role: "student" }), university: claim };
    }
}

$("school-go").addEventListener("click", () => void lookUpSchool($("school-input").value));
$("school-input").addEventListener("keydown", event => {
    if (event.key === "Enter") {
        event.preventDefault();
        void lookUpSchool($("school-input").value);
    }
});

$("switch-save").addEventListener("click", async () => {
    const button = $("switch-save");
    button.disabled = true;
    const saved = await saveSchoolSwitches(supabase, {
        school,
        updatedBy: user?.id,
        switches: {
            accommodation: $("switch-accommodation").checked,
            catering: $("switch-catering").checked,
            chaplaincy: $("switch-chaplaincy").checked
        }
    });
    setStatus($("switch-status"), saved.message, saved.ok ? "success" : "error");
    button.disabled = false;
    if (saved.ok) await loadSchool(school);
});

$("hostel-form").addEventListener("submit", async event => {
    event.preventDefault();
    const button = $("hostel-form").querySelector("button[type=submit]");
    button.disabled = true;
    const added = await addHostel(supabase, {
        school,
        name: $("hostel-name").value,
        gender: $("hostel-gender").value,
        address: $("hostel-address").value,
        note: $("hostel-note").value,
        addedBy: user?.id
    });
    setStatus($("hostel-status"), added.message, added.ok ? "success" : "error");
    button.disabled = false;
    if (!added.ok) {
        if (added.missing) mountSetupCard();
        return;
    }
    $("hostel-form").reset();
    await loadSchool(school);
});

$("room-save").addEventListener("click", async () => {
    const button = $("room-save");
    const hostelId = $("room-hostel").value;
    if (!hostelId) {
        setStatus($("hostel-status"), "Add the hostel first, then its rooms.", "error");
        return;
    }
    button.disabled = true;
    const added = await addRoom(supabase, {
        hostelId,
        label: $("room-label").value,
        sharing: $("room-sharing").value,
        capacity: $("room-beds").value,
        feeSemester: $("room-fee").value,
        mealIncluded: $("room-meals").checked
    });
    setStatus($("hostel-status"), added.message, added.ok ? "success" : "error");
    button.disabled = false;
    if (added.ok) {
        $("room-label").value = "";
        $("room-fee").value = "";
        await loadSchool(school);
    }
});

$("meal-form").addEventListener("submit", async event => {
    event.preventDefault();
    const button = $("meal-form").querySelector("button[type=submit]");
    button.disabled = true;
    const added = await addMealPlan(supabase, {
        school,
        name: $("meal-name").value,
        kind: $("meal-kind").value,
        priceWeekly: $("meal-week").value,
        priceSemester: $("meal-term").value,
        menu: $("meal-menu").value,
        createdBy: user?.id
    });
    setStatus($("meal-status"), added.message, added.ok ? "success" : "error");
    button.disabled = false;
    if (added.ok) {
        $("meal-form").reset();
        await loadSchool(school);
    }
});

$("event-repeat").addEventListener("change", () => {
    const series = $("event-repeat").value !== "none";
    $("event-series").hidden = !series;
    $("event-dated").hidden = series;
});

$("event-form").addEventListener("submit", async event => {
    event.preventDefault();
    if (!user) {
        setStatus($("event-status"), "Open the app and sign in first.", "error");
        return;
    }
    const button = $("event-form").querySelector("button[type=submit]");
    button.disabled = true;
    const added = await addChaplaincyEvent(supabase, {
        school,
        title: $("event-title").value,
        kind: $("event-kind").value,
        term: $("event-term").value,
        repeat: $("event-repeat").value,
        weekday: $("event-weekday").value,
        startTime: $("event-time").value,
        startsAt: $("event-start").value,
        endsAt: $("event-end").value,
        venue: $("event-venue").value,
        description: $("event-about").value,
        createdBy: user.id
    });
    setStatus($("event-status"), added.message, added.ok ? "success" : "error");
    button.disabled = false;
    if (added.ok) {
        $("event-form").reset();
        await loadSchool(school);
    }
});

$("request-form").addEventListener("submit", async event => {
    event.preventDefault();
    if (!user) {
        setStatus($("request-status"), "Open the app and sign in first.", "error");
        return;
    }
    const button = $("request-form").querySelector("button[type=submit]");
    button.disabled = true;
    const sent = await sendPrayerRequest(supabase, {
        school: profile?.university || school,
        studentId: user.id,
        request: $("request-text").value,
        kind: $("request-kind").value,
        answerable: $("request-answerable").checked
    });
    setStatus($("request-status"), sent.message, sent.ok ? "success" : "error");
    button.disabled = false;
    if (sent.ok) $("request-text").value = "";
});

/* A photo is read before the report is sent, never instead of the finder: one
   eaten slash turns one student's number into another's, so the box always shows
   what was recognised and stays editable. */
let photoReads = 0;

$("found-photo").addEventListener("change", async () => {
    const field = $("found-number");
    const status = $("found-read-status");
    const file = $("found-photo").files?.[0];
    const attempt = ++photoReads;
    if (!file) {
        status.textContent = "";
        return;
    }
    if (field.value.trim() && field.dataset.read !== "1") {
        setStatus(status, "You typed the number, so the photo is left alone.");
        return;
    }
    setStatus(status, "Reading the photo…");
    const read = await readNumberFromPhoto(file, stage => {
        if (attempt === photoReads && stage === "engine") setStatus(status, "Fetching the reader, only the first time…");
    });
    if (attempt !== photoReads) return;
    if (!read.ok) {
        setStatus(status, read.message, "error");
        return;
    }
    field.value = read.number;
    field.dataset.read = "1";
    setStatus(status, `${translate("Read from the photo:")} ${read.number}`, "success");
});

$("found-form").addEventListener("submit", async event => {
    event.preventDefault();
    if (!user) {
        setStatus($("found-status"), "Open the app and sign in first.", "error");
        return;
    }
    const button = $("found-form").querySelector("button[type=submit]");
    button.disabled = true;
    setStatus($("found-status"), "Reading the number on it…");
    const sent = await reportFoundItem(supabase, {
        userId: user.id,
        kind: $("found-kind").value,
        number: $("found-number").value,
        place: $("found-place").value,
        heldAt: $("found-here").value,
        photo: $("found-photo").files?.[0] || null,
        foundAt: $("found-when").value
    });
    setStatus($("found-status"), sent.message, sent.ok ? "success" : "error");
    button.disabled = false;
    if (!sent.ok) {
        if (isFoundItemsMissing()) mountSetupCard();
        return;
    }
    $("found-form").reset();
    $("found-number").dataset.read = "";
    $("found-read-status").textContent = "";
    await refreshFound();
});

/* The desk list belongs to whichever school the page is reading, so a lookup
   pulls the found documents again as well. */
async function lookUpSchool(name) {
    await loadSchool(name);
    await refreshFound();
}

fillFoundSelects();

async function start() {
    state("Reading the campus services…");
    const boot = await resolveBootUser(supabase);
    user = boot.user;
    setOfflineBanner(boot.offline);
    await readMyProfile();
    await Promise.all([loadSchool(profile?.university || ""), refreshFound()]);
}

window.addEventListener("pagehide", () => {
    clearCampusServices();
    clearPreloadRetry();
}, { once: true });

void start();
