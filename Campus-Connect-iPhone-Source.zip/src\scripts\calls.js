import {
    acquireWarmStream,
    borrowCallStream,
    grantCameraTrack,
    grantedAlready,
    grantCallStream,
    plainCallMicrophone,
    probeMedia,
    setPlainCallMicrophone,
    stopWarmStream
} from "../lib/media-grant.js";
import { Capacitor } from "@capacitor/core";
import { callWatchRing, callWatchRingStop, callWatchAnswerTarget, callWatchListening, holdCallWatch } from "../lib/call-watch.js";
import { canOpenPhoneSettings, permissionHint } from "../lib/media-hint.js";
import {
    askNativeMedia,
    deviceAllowed,
    openMediaSettings,
    watchDevicePermissions
} from "../lib/native-permissions.js";
import { stopVoicePlayback } from "../lib/voice-player.js";
import { addCallEntry, addScheduledCall } from "../lib/call-log.js";
import { showSetupCard } from "../lib/db-setup.js";
import { translate } from "../lib/language.js";
import { announcePush } from "../lib/push.js";
import { attachLevelMeter, meterRequested, setMeterRequested, metersSupported } from "../lib/call-meter.js";
import { beginCallRoute, callRouteSupported, endCallRoute, setCallSpeaker } from "../lib/call-audio-route.js";
import { applyAudioBudget, lowLatencyAudio } from "../lib/call-sdp.js";
import { CALL_STATS_MS, formatCallStats, readAudioStats } from "../lib/call-latency.js";
import { buildIceServers, hasRelay } from "../lib/call-ice.js";
import {
    canvasShareSupported,
    createWhiteboard,
    grantScreenTrack,
    screenShareSupported
} from "../lib/call-share.js";

const voiceButton = document.getElementById("voice-call-button");
const videoButton = document.getElementById("video-call-button");
const incomingDialog = document.getElementById("incoming-call-dialog");
const incomingDescription = document.getElementById("incoming-call-description");
const incomingTitle = document.getElementById("incoming-call-title");
const incomingKind = document.getElementById("incoming-call-kind");
const incomingAvatar = document.getElementById("incoming-call-avatar");
const incomingSelfView = document.getElementById("incoming-self-view");
const endAndAcceptButton = document.getElementById("end-and-accept-button");
const acceptCallButton = document.getElementById("accept-call-button");
const callDialog = document.getElementById("call-dialog");
const callTitle = document.getElementById("call-title");
const callStatus = document.getElementById("call-state");
const localVideo = document.getElementById("local-video");
const remoteVideo = document.getElementById("remote-video");
const remoteAudio = document.getElementById("remote-audio");
const microphoneButton = document.getElementById("toggle-mic-button");
const speakerButton = document.getElementById("toggle-speaker-button");
const cameraButton = document.getElementById("toggle-camera-button");
const startVideoButton = document.getElementById("start-video-button");
const shareScreenButton = document.getElementById("share-screen-button");
const shareNotesButton = document.getElementById("share-notes-button");
const callMeters = document.getElementById("call-meters");
const meterLocal = document.getElementById("meter-local");
const meterRemote = document.getElementById("meter-remote");
const remoteSoundChip = document.getElementById("remote-sound-chip");
const notesDialog = document.getElementById("notes-dialog");
const notesCanvas = document.getElementById("notes-canvas");
const notesPenButton = document.getElementById("notes-pen-button");
const notesEraserButton = document.getElementById("notes-eraser-button");
const notesUndoButton = document.getElementById("notes-undo-button");
const notesClearButton = document.getElementById("notes-clear-button");
const notesStopButton = document.getElementById("notes-stop-button");
const notesCloseButton = document.getElementById("notes-close-button");
const plainMicButton = document.getElementById("plain-mic-button");
const meterToggleButton = document.getElementById("call-meter-button");
const callsMenuDialog = document.getElementById("calls-menu-dialog");
const testMediaButton = document.getElementById("test-media-button");
const mediaTestDialog = document.getElementById("media-test-dialog");
const mediaTestMicrophone = document.getElementById("media-test-microphone");
const mediaTestCamera = document.getElementById("media-test-camera");
const mediaTestHelp = document.getElementById("media-test-help");
const mediaTestClose = document.getElementById("media-test-close");
const mediaTestSettings = document.getElementById("media-test-settings");
const callNetworkLine = document.getElementById("call-network-line");

// The person being called owns the decision. Their ring window has to fit
// inside the caller's patience, otherwise the caller hangs up first and a late
// tap lands on a call that no longer exists. Grace keeps the Accept button live
// for a few seconds after the ring ends so a slow tap still connects.
const INCOMING_CALL_RING_TIMEOUT_MS = 60000;
const LATE_ACCEPT_GRACE_MS = 10000;
const CALL_ANSWER_TIMEOUT_MS = 75000;
const CONNECT_DEADLINE_MS = 20000;
const SIGNAL_POLL_MS = 2500;
/* 55 s sits INSIDE both clocks a dead call runs by - the page's own 60 s ring
   window and the caller's 75 s patience - so a phone opening late can never
   ring for a call both sides have already given up on. The old 80 s sat above
   both, which is what made dead calls ring late. */
const STALE_OFFER_MS = 55000;
/* A student walking out of the library hands the call from Wi-Fi to his data
   bundle in one second, and the address pair the call was speaking through dies
   with the old route. The phone reports that as "disconnected" and then waits
   forever, so it is given a short grace period - networks often heal themselves
   inside it - before the call is asked for a completely new set of addresses. */
const ICE_RECOVERY_MS = 2500;
const ICE_RESTART_LIMIT = 2;
/* A screen that is merely off is not a phone that stopped listening. Android
   slows a hidden page right down instead of killing it, so the check for a
   ringing call keeps running there, just less often than in the foreground. */
const BACKGROUND_SWEEP_EVERY = 3;

/* A student who pressed End is owed his screen back, not a database reply.
   Four seconds is long enough for a slow campus signal and short enough that
   nobody keeps staring at a call that is already over. The notice still goes
   out in the background, so the other phone can still learn the call ended. */
const END_SIGNAL_WAIT_MS = 4000;

/* The watch that rings a phone whose app is shut learns a call was cancelled by
   reading the very row this page just finished with. Deleting it the instant the
   page is done leaves that watch ringing at an empty screen until its own minute
   runs out - which is the "it kept ringing after he hung up" complaint. So a row
   that ENDS a call is left where it is for a few seconds, long enough for the
   watch's next look. Nothing reads it twice: the page has already marked the
   signal seen, and a fresh session finds no live call to match it and returns. */
const TERMINAL_SIGNAL_KINDS = new Set(["answer", "reject", "busy", "end"]);
const TERMINAL_SIGNAL_HOLD_MS = 30000;

/* The loudspeaker choice is remembered per phone: a student who once picked the
   earpiece because he is in a library should not have to pick it again every
   call, and a call with no sound at all is the mistake he must never make. */
const SPEAKER_KEY = "campus-connect-call-speaker";

function speakerPreferred() {
    try {
        return window.localStorage.getItem(SPEAKER_KEY) !== "0";
    } catch {
        return true;
    }
}

function rememberSpeakerPreference(on) {
    try {
        window.localStorage.setItem(SPEAKER_KEY, on ? "1" : "0");
    } catch {
        // A private window keeps the choice for this call only.
    }
}

/* Which addresses a call may try, and why a relay is the difference between a
   call that rings and a call that connects: see lib/call-ice.js. */
function getIceServers() {
    return buildIceServers(import.meta.env);
}

function relayConfigured() {
    return hasRelay(getIceServers());
}

/* "Could not connect. Check TURN settings" was written for the developer, and a
   student cannot act on it. The two ways a media path really dies now have
   their own sentences, and the second one says plainly that this phone has no
   way of reaching the other network rather than blaming the student. */
function describeMediaFailure() {
    if (relayConfigured()) {
        return translate("The call could not find a path between the two phones.");
    }
    return translate(
        "This phone and the other one are on networks that cannot reach each other directly, and no relay is set up."
    );
}

function isMissingTableError(error) {
    const code = String(error?.code || "");
    if (["42P01", "PGRST202", "PGRST205"].includes(code)) return true;
    return /does not exist|could not find the|schema cache/i.test(String(error?.message || ""));
}

const AUTH_ERROR_CODES = ["PGRST301", "401"];

/* "Calls are not ready yet" told him nothing he could act on, so every way this
   phone can fail to reach the signaling table now gets its own sentence. His
   phone is the only witness, so the witness has to speak. */
function describeSignalingError(error) {
    if (isMissingTableError(error)) {
        return translate("The calls database is not set up yet. Run the setup SQL in Supabase.");
    }
    const message = String(error?.message || error || "").trim();
    const code = String(error?.code || "");
    if (AUTH_ERROR_CODES.includes(code) || /jwt|token|expired|unauthorized|invalid api key/i.test(message)) {
        return translate("This login has expired on this phone. Sign out, sign in again, then call.");
    }
    if (!code && /failed to fetch|networkerror|load failed|client exception|timeout|network request failed/i.test(message)) {
        return translate("This phone cannot reach the Campus Connect server. Check the connection and try again.");
    }
    return message || translate("Call signaling did not answer.");
}

function formatReminderTime(at) {
    const date = new Date(at);
    const time = date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    const sameDay = date.toDateString() === new Date().toDateString();
    return sameDay
        ? time
        : `${date.toLocaleDateString([], { day: "numeric", month: "short" })} ${time}`;
}

// The phone's own ringtone where one can be reached - Android hands it over
// through the call-watch plugin, the same ringer that wakes the student when
// the app is closed - and a calm two-tone WebAudio ring everywhere else, so
// no audio file is needed. Browsers may ignore the beep without a prior user
// gesture; the in-app dialog still shows either way.
let ringContext = null;
let ringTimer = null;
let ringNative = false;
let ringSeq = 0;

async function startRingtone({ quiet = false } = {}) {
    stopRingtone();
    const seq = ++ringSeq;
    if (quiet) {
        /* A second call landing on a live one may not put its ring tone through
           the speaker the microphone is recording from - that is the echo the
           first student hears. The phone still buzzes. */
        if (!navigator.vibrate) return;
        ringTimer = window.setInterval(() => {
            try { navigator.vibrate([220, 300, 220]); } catch { /* ignore */ }
        }, 1800);
        return;
    }
    let played = null;
    try {
        played = await callWatchRing();
    } catch { /* the beep remains the honest fallback */ }
    ringNative = played === true;
    if (seq !== ringSeq) {
        // The call ended while the phone was being asked; do not leave it ringing.
        if (ringNative) {
            ringNative = false;
            callWatchRingStop();
        }
        return;
    }
    if (ringNative) {
        // The real ringtone owns the speaker; the buzz rides along with it.
        if (navigator.vibrate) {
            try { navigator.vibrate([220, 300, 220]); } catch { /* ignore */ }
            ringTimer = window.setInterval(() => {
                try { navigator.vibrate([220, 300, 220]); } catch { /* ignore */ }
            }, 1800);
        }
        return;
    }
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextClass) return;
    try {
        ringContext = new AudioContextClass();
    } catch {
        ringContext = null;
        return;
    }
    const beep = () => {
        if (!ringContext) return;
        if (ringContext.state === "suspended") ringContext.resume().catch(() => {});
        const now = ringContext.currentTime;
        for (const [offset, frequency] of [[0, 880], [0.2, 660]]) {
            const oscillator = ringContext.createOscillator();
            const gain = ringContext.createGain();
            oscillator.type = "sine";
            oscillator.frequency.value = frequency;
            gain.gain.setValueAtTime(0.0001, now + offset);
            gain.gain.exponentialRampToValueAtTime(0.16, now + offset + 0.03);
            gain.gain.exponentialRampToValueAtTime(0.0001, now + offset + 0.17);
            oscillator.connect(gain);
            gain.connect(ringContext.destination);
            oscillator.start(now + offset);
            oscillator.stop(now + offset + 0.2);
        }
        if (navigator.vibrate) {
            try { navigator.vibrate([220, 300, 220]); } catch { /* ignore */ }
        }
    };
    beep();
    ringTimer = window.setInterval(beep, 1800);
}

function stopRingtone() {
    ringSeq++;
    window.clearInterval(ringTimer);
    ringTimer = null;
    if (navigator.vibrate) {
        try { navigator.vibrate(0); } catch { /* ignore */ }
    }
    ringNative = false;
    /* Asked to stop whether or not this page lit the ringer. The watch that
       rings a shut app keeps his phone noisy after the student opens it and
       reads that the call is over - this page rang nobody, so the old flag said
       there was nothing to quiet. One no-op call is cheaper than a ringing
       phone, and the website and the iPhone answer it by doing nothing. */
    callWatchRingStop();
    if (ringContext) {
        ringContext.close().catch(() => {});
        ringContext = null;
    }
}

/* The student who tapped Answer on the ringing alert already made his
   decision; the app opening underneath him should finish it, the way
   WhatsApp connects straight from the lock screen. The native side hands
   over the call id once, so it is kept briefly here - long enough for the
   offer to arrive on the next poll, and no longer: an answer is for one
   call, never a standing order. */
const ANSWER_TARGET_KEEP_MS = 90000;
const answerTargets = new Map();

async function noteAnswerTargets() {
    let target = "";
    try {
        target = await callWatchAnswerTarget();
    } catch { /* nobody answered on the alert; ring normally */ }
    if (!target) return;
    const now = Date.now();
    for (const [stale, until] of answerTargets) {
        if (until < now) answerTargets.delete(stale);
    }
    answerTargets.set(target, now + ANSWER_TARGET_KEEP_MS);
}

function shouldAutoAnswer(callId) {
    const until = answerTargets.get(callId);
    if (!until) return false;
    answerTargets.delete(callId);
    return Date.now() < until;
}

export function createCallManager(supabase, user, showNotice) {
    let selectedStudent = null;
    let activeCall = null;
    let callChannel = null;
    let subscribed = false;
    let pollingReady = false;
    let signalingProblem = "";
    let resubscribeTimer = 0;
    let cleanupTimer;
    let signalPollTimer;
    let migrationNoticeShown = false;
    let pendingIncoming = null;
    let dialogIncoming = null;
    let speakerOn = speakerPreferred();
    let localMeter = null;
    let remoteMeter = null;
    let latencyTimer = 0;
    let whiteboard = null;
    let notesTrack = null;
    const seenSignalIds = new Set();

    function reportCallSetup(error) {
        if (!isMissingTableError(error)) return error;
        if (!migrationNoticeShown) {
            migrationNoticeShown = true;
            showSetupCard({
                target: "#calls-recent-heading",
                position: "before",
                reason: translate("Calls need one database update before they can ring. Chats keep working meanwhile.")
            });
        }
        return new Error("Calls need the database setup SQL.");
    }

    function rememberSignal(signalId) {
        if (seenSignalIds.has(signalId)) return false;
        seenSignalIds.add(signalId);
        if (seenSignalIds.size > 300) seenSignalIds.delete(seenSignalIds.values().next().value);
        return true;
    }

    function setCallStatus(message) {
        callStatus.textContent = message;
    }

    function describeIncomingCall(call) {
        if (incomingKind) {
            incomingKind.textContent = call.mode === "video"
                ? "Incoming video call"
                : "Incoming voice call";
        }
        if (incomingTitle) incomingTitle.textContent = call.peerName || "Incoming call";
        if (incomingDescription) {
            incomingDescription.textContent = call.peerUsername ? `@${call.peerUsername}` : "";
        }
        if (incomingAvatar) {
            incomingAvatar.replaceChildren();
            if (call.peerAvatar) {
                const image = document.createElement("img");
                image.src = call.peerAvatar;
                image.alt = "";
                incomingAvatar.appendChild(image);
            } else {
                incomingAvatar.textContent =
                    (call.peerName || "?").trim().charAt(0).toUpperCase() || "?";
            }
        }
    }

    function closeIncomingDialog() {
        dialogIncoming = null;
        if (incomingDialog.open) incomingDialog.close();
        stopRingtone();
        hideSelfView();
    }

    // The caller offered while we are already on a call: drop the parked offer
    // and tell the other side we are busy.
    function clearPendingIncoming() {
        if (!pendingIncoming) return;
        const stale = pendingIncoming;
        pendingIncoming = null;
        window.clearTimeout(stale.ringTimer);
        closeIncomingDialog();
        void sendSignal(stale.peerId, stale.id, "busy").catch(error => {
            console.warn("Could not report being busy on a call:", error);
        });
    }

    // The ring ran out. That is a missed call, not a refusal, so the dialog
    // stays up with Answer still live for a few seconds: a caller who has not
    // given up yet has nowhere to go, and a slow thumb should not be reported
    // as "declined" to the other side.
    function expireIncoming() {
        const call = activeCall;
        if (!call || call.isCaller || call.ringExpired) return;
        call.ringExpired = true;
        window.clearTimeout(call.ringTimer);
        stopRingtone();
        hideSelfView();
        if (incomingKind) {
            incomingKind.textContent = translate("Answer now: the call is still open");
        }
        call.graceTimer = window.setTimeout(() => {
            if (activeCall !== call) return;
            finishCall(`Missed call from ${call.peerName || "a student"}`, "missed");
        }, LATE_ACCEPT_GRACE_MS);
    }

    function updateButtons() {
        const enabled = Boolean((subscribed || pollingReady) && selectedStudent && !activeCall);
        voiceButton.disabled = !enabled;
        videoButton.disabled = !enabled;
    }

    function setSelectedStudent(student) {
        selectedStudent = student;
        updateButtons();
    }

    async function sendSignal(recipientId, callId, kind, payload = {}) {
        const { error } = await supabase.from("call_signals").insert({
            call_id: callId,
            sender_id: user.id,
            recipient_id: recipientId,
            kind,
            payload
        });
        if (error) throw reportCallSetup(error);
    }

    async function deleteSignal(signalId) {
        const { error } = await supabase
            .from("call_signals")
            .delete()
            .eq("id", signalId)
            .eq("recipient_id", user.id);
        if (error) throw reportCallSetup(error);
    }

    /* An offer or a network address is this phone's to know alone, so it goes
       the moment it is read. A row that ENDS a call is a message to the native
       watch too, and gets the short hold above before the same delete. Nothing
       waits for it: the page has already done its part with the row. */
    function retireSignal(signal) {
        const discard = () => deleteSignal(signal.id).catch((error) => {
            console.error("Could not remove processed call signal:", error);
        });
        if (!TERMINAL_SIGNAL_KINDS.has(signal.kind)) {
            void discard();
            return;
        }
        window.setTimeout(discard, TERMINAL_SIGNAL_HOLD_MS);
    }

    async function cleanExpiredSignals() {
        const cutoff = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
        for (const participantField of ["sender_id", "recipient_id"]) {
            const { error } = await supabase
                .from("call_signals")
                .delete()
                .eq(participantField, user.id)
                .lt("created_at", cutoff);
            if (error) {
                if (isMissingTableError(error)) {
                    reportCallSetup(error);
                    return;
                }
                console.error("Could not remove expired call signaling data:", error);
                showNotice(`Could not clean up expired call data: ${error.message}`, true);
                return;
            }
        }
    }

    function callKindLabel(mode) {
        return mode === "video" ? translate("Video call") : translate("Voice call");
    }

    function refreshCallHeader(call = activeCall) {
        if (!call) return;
        const who = call.peerName || "";
        const kind = callKindLabel(call.mode);
        callTitle.textContent = who ? `${who} · ${kind}` : kind;
        refreshCallButtons(call);
    }

    /* Which picture this phone is sending decides which buttons mean anything.
       A phone gets no screen-share button at all, because Android cannot answer
       that request - a button that only ever fails is worse than no button. */
    function refreshCallButtons(call) {
        if (!call) return;
        const sharing = call.sharing || "off";
        cameraButton.hidden = sharing !== "camera";
        startVideoButton.hidden = sharing === "camera";
        startVideoButton.textContent = sharing === "off"
            ? translate("Turn on video")
            : translate("Switch to camera");
        shareScreenButton.hidden = !screenShareSupported();
        shareNotesButton.hidden = !canvasShareSupported();
        shareScreenButton.textContent = sharing === "screen"
            ? translate("Stop sharing")
            : translate("Share screen");
        shareNotesButton.textContent = sharing === "notes"
            ? translate("Stop sharing")
            : translate("Share notes");
        shareScreenButton.classList.toggle("is-on", sharing === "screen");
        shareNotesButton.classList.toggle("is-on", sharing === "notes");
        if (sharing !== "notes") notesStopButton?.setAttribute("hidden", "");
    }

    /* Android can move a call between the loudspeaker and the earpiece; a
       browser cannot, so the button appears only on the phones that really have
       that switch. */
    function refreshSpeakerButton() {
        if (!speakerButton) return;
        const supported = callRouteSupported();
        speakerButton.hidden = !supported;
        if (!supported) return;
        speakerButton.textContent = speakerOn
            ? translate("Speaker")
            : translate("Earpiece");
        speakerButton.classList.toggle("is-on", speakerOn);
    }

    function openCallDialog(mode, stateText) {
        activeCall.mode = mode;
        refreshCallHeader();
        refreshSpeakerButton();
        setCallStatus(stateText);
        callDialog.showModal();
    }

    function resetCallUI() {
        dialogIncoming = null;
        localVideo.srcObject = null;
        localVideo.style.display = "none";
        remoteVideo.srcObject = null;
        remoteAudio.srcObject = null;
        remoteVideo.style.display = "block";
        cameraButton.hidden = false;
        microphoneButton.textContent = translate("Mute");
        cameraButton.textContent = translate("Camera");
        stopMeters();
        stopLatencyLine();
        hideSoundChip();
        if (notesDialog?.open) notesDialog.close();
        if (callDialog.open) callDialog.close();
        if (incomingDialog.open) incomingDialog.close();
    }

    /* What he is sending - himself, his screen, or his notes - goes in the same
       small window, so he never has to wonder what the other side is looking at. */
    function showOutgoingPicture(track) {
        localVideo.srcObject = track ? new MediaStream([track]) : null;
        localVideo.style.display = track ? "block" : "none";
    }

    function stopMeters() {
        localMeter?.stop();
        remoteMeter?.stop();
        localMeter = null;
        remoteMeter = null;
        callMeters.hidden = true;
        meterLocal.style.width = "0%";
        meterRemote.style.width = "0%";
    }

    /* Only when the student asked for it in the Calls menu: opening a WebAudio
       graph mid-call can move the phone's audio route, and a call that already
       works must not be touched to satisfy a meter. */
    function startMeters(call) {
        if (!meterRequested() || !metersSupported()) {
            callMeters.hidden = true;
            return;
        }
        localMeter?.stop();
        remoteMeter?.stop();
        localMeter = null;
        remoteMeter = null;
        const mine = call.localStream?.getAudioTracks?.()[0];
        if (mine) localMeter = attachLevelMeter(meterLocal, new MediaStream([mine]));
        if (remoteAudio.srcObject) remoteMeter = attachLevelMeter(meterRemote, remoteAudio.srcObject);
        callMeters.hidden = !(localMeter || remoteMeter);
    }

    /* "His voice comes late" is one sentence with three possible causes behind
       it: the buffer waiting for packets, packets that never came, and the
       distance between the two phones. The line below names the numbers, so the
       next report can be read instead of guessed at. It only measures - it never
       decides whether the call is good, and it never interrupts one. */
    function startLatencyLine(call) {
        stopLatencyLine();
        const connection = call.peerConnection;
        if (!connection) return;
        callNetworkLine.textContent = "";
        callNetworkLine.hidden = false;
        latencyTimer = window.setInterval(() => {
            /* An ICE restart swaps the connection out from under this timer, so
               the old one measures nothing and stops rather than reporting zero. */
            if (call.peerConnection !== connection) {
                stopLatencyLine();
                return;
            }
            connection.getStats().then(report => {
                if (activeCall === call) {
                    callNetworkLine.textContent = formatCallStats(readAudioStats(report), translate);
                }
            }).catch(() => {});
        }, CALL_STATS_MS);
    }

    function stopLatencyLine() {
        if (latencyTimer) window.clearInterval(latencyTimer);
        latencyTimer = 0;
        callNetworkLine.hidden = true;
        callNetworkLine.textContent = "";
    }

    function showSoundChip() {
        if (remoteSoundChip) remoteSoundChip.hidden = false;
    }

    function hideSoundChip() {
        if (remoteSoundChip) remoteSoundChip.hidden = true;
    }

    function showSelfView(stream) {
        const track = stream?.getVideoTracks?.()[0];
        if (!track || !incomingSelfView) return;
        incomingSelfView.srcObject = new MediaStream([track]);
        incomingSelfView.classList.add("visible");
        incomingSelfView.play().catch(() => {
            // Autoplay can be blocked; the avatar and name still carry the UI.
        });
    }

    function hideSelfView() {
        if (!incomingSelfView) return;
        incomingSelfView.srcObject = null;
        incomingSelfView.classList.remove("visible");
    }

    function logCall(call, outcome, durationMs) {
        if (!call?.peerId) return;
        addCallEntry(user.id, {
            peerId: call.peerId,
            peerName: call.peerName,
            mode: call.mode,
            outcome,
            direction: call.isCaller ? "out" : "in",
            at: Date.now(),
            durationMs
        });
    }

    function finishCall(statusText = "Call ended", outcome = null) {
        stopRingtone();
        void endCallRoute();
        /* The call is over, so the CPU it was borrowing goes back to the phone. */
        void holdCallWatch(false);
        hideSelfView();
        const previousCall = activeCall;
        activeCall = null;
        window.clearTimeout(previousCall?.answerTimer);
        window.clearTimeout(previousCall?.ringTimer);
        window.clearTimeout(previousCall?.graceTimer);
        window.clearTimeout(previousCall?.connectTimer);
        window.clearTimeout(previousCall?.iceRecoveryTimer);
        updateButtons();

        if (previousCall) {
            const durationMs = previousCall.connectedAt
                ? Math.max(0, Date.now() - previousCall.connectedAt)
                : 0;
            logCall(previousCall, outcome || (durationMs > 0
                ? "ended"
                : previousCall.isCaller ? "unanswered" : "missed"), durationMs);
        }

        if (previousCall?.peerConnection) {
            previousCall.peerConnection.onicecandidate = null;
            previousCall.peerConnection.ontrack = null;
            previousCall.peerConnection.close();
        }
        // A screen left capturing after the call is a phone that says it is
        // still being watched.
        releaseCallMedia(previousCall);
        // The local stream is the session's warm mic/camera stream: keep its
        // tracks alive so iOS does not re-ask for permission on the next call.
        resetCallUI();
        if (statusText) {
            setCallStatus(statusText);
            showNotice(statusText);
        }
    }

    /* A voice note or a story left playing behind the call keeps feeding the
       speaker, and the microphone feeds it straight back to the other student.
       The call owns the audio channel, so everything else stops. */
    function pauseOtherMedia() {
        stopVoicePlayback();
        document.querySelectorAll("video, audio").forEach(media => {
            if (media === remoteAudio || media === remoteVideo || media === localVideo) return;
            if (!media.paused) media.pause();
        });
    }

    function createPeerConnection() {
        const connection = new RTCPeerConnection({
            iceServers: getIceServers(),
            /* One port for the whole call, because a campus network that blocks
               the extra ports a non-bundled call opens is a network that blocks
               the call. The small candidate pool is gathered before the offer is
               even sent, so a phone on a slow bundle is not still hunting for an
               address while the other student waits on "Connecting...". */
            bundlePolicy: "max-bundle",
            rtcpMuxPolicy: "require",
            iceCandidatePoolSize: 4
        });
        const call = activeCall;
        call.peerConnection = connection;

        connection.onicecandidate = event => {
            // A candidate for a call we already left must not be sent to the
            // student we were just talking to.
            if (!event.candidate || activeCall !== call) return;
            sendSignal(
                call.peerId,
                call.id,
                "ice",
                event.candidate.toJSON()
            ).catch(error => {
                console.error("Could not send call network information:", error);
                setCallStatus(`Call connection error: ${error.message}`);
            });
        };

        connection.ontrack = event => {
            if (activeCall !== call) return;
            const stream = event.streams[0] || new MediaStream([event.track]);
            const audioTracks = stream.getAudioTracks();
            const videoTracks = stream.getVideoTracks();
            /* A renegotiated call delivers its video in a second event. Wiping
               the audio slot because that event carries no audio track is how a
               picture would kill the voice, so each side is only ever replaced
               with something of its own kind. */
            if (audioTracks.length) {
                remoteAudio.srcObject = new MediaStream(audioTracks);
                remoteAudio.play().catch(error => {
                    console.warn("Remote call audio could not start automatically:", error);
                    showSoundChip();
                });
                startMeters(call);
            }
            if (videoTracks.length) {
                remoteVideo.srcObject = new MediaStream(videoTracks);
                call.mode = "video";
                // A first offer already carries video; only a mid-call upgrade
                // is worth interrupting the status line for.
                if (call.connectedAt) setCallStatus(translate("Video is on"));
            }
            remoteVideo.style.display = call.mode === "video" && videoTracks.length
                ? "block"
                : "none";
            refreshCallHeader(call);
        };

        connection.onconnectionstatechange = () => {
            if (activeCall !== call) return;

            if (connection.connectionState === "connected") {
                window.clearTimeout(call.answerTimer);
                window.clearTimeout(call.connectTimer);
                window.clearTimeout(call.ringTimer);
                window.clearTimeout(call.graceTimer);
                window.clearTimeout(call.iceRecoveryTimer);
                call.iceRecoveryTimer = 0;
                if (!call.connectedAt) call.connectedAt = Date.now();
                pauseOtherMedia();
                setCallStatus("Connected");
                startMeters(call);
                startLatencyLine(call);
                refreshCallHeader(call);
            } else if (connection.connectionState === "failed") {
                /* Both phones can still read each other's rows in the database,
                   so a dead media path is a routing problem rather than a person
                   problem. A new set of addresses is tried before anybody is
                   told the call is over. */
                if (!restartCallPath(call, connection)) {
                    void endCall(describeMediaFailure(), "failed", "no-connection");
                }
            } else if (connection.connectionState === "disconnected") {
                stopLatencyLine();
                setCallStatus(translate("Connection interrupted. Trying to reconnect..."));
                armIceRecovery(call, connection);
            }
        };

        for (const track of call.localStream.getTracks()) {
            const sender = connection.addTrack(track, call.localStream);
            if (track.kind === "video") {
                call.videoSender = sender;
            } else {
                /* The SDP line only says what this side can receive. Chrome will
                   still encode the microphone at its own rate until the sender is
                   told the budget as well, which is the half that travels. */
                applyAudioBudget(sender);
            }
        }
        return connection;
    }

    /* Candidates pile up while the phone is still ringing, and by the time the
       answer lands some of them are stale. One unusable address is worth
       nothing next to the whole call, so each is tried on its own. */
    async function flushPendingCandidates() {
        const call = activeCall;
        const connection = call?.peerConnection;
        if (!connection) return;
        const pending = call.pendingCandidates.splice(0);
        for (const candidate of pending) {
            try {
                await connection.addIceCandidate(candidate);
            } catch (error) {
                console.warn("Ignoring one stale call network address:", error);
            }
        }
    }

    /* A call never gets to choose the network the phone is on. Wi-Fi becomes the
       data bundle, the route the two phones picked stops existing, and the only
       way back is to throw that route away: ask for a fresh set of addresses and
       offer them to the other phone on the same call id. The far side already
       treats an offer for a live call as a mid-call change rather than a new
       ring, so nothing new has to be taught to either phone. */
    function restartAllowed(call) {
        return Boolean(call) && (call.iceRestarts || 0) < ICE_RESTART_LIMIT;
    }

    function restartCallPath(call, connection) {
        if (activeCall !== call || !connection || call.negotiating) return false;
        if (!restartAllowed(call)) return false;
        call.iceRestarts = (call.iceRestarts || 0) + 1;
        window.clearTimeout(call.iceRecoveryTimer);
        call.iceRecoveryTimer = 0;
        try {
            connection.restartIce();
        } catch {
            /* A WebView old enough to lack restartIce still gets the new offer
               below, which is the half that actually carries the addresses. */
        }
        setCallStatus(translate("Your network changed. Finding a new path for the call..."));
        // The path is only worth chasing for as long as the first one was.
        window.clearTimeout(call.connectTimer);
        call.connectTimer = window.setTimeout(() => {
            if (activeCall !== call || connection.connectionState === "connected") return;
            void endCall(describeMediaFailure(), "failed", "no-connection");
        }, CONNECT_DEADLINE_MS);
        void renegotiate(call).catch(error => {
            console.warn("Could not put the call on a new network path:", error);
            /* The new addresses never left this phone, so the description they
               were carried in is thrown away and a fresh set is gathered for the
               next try. Left alone, the second attempt would offer a description
               the other phone has already seen, and both tries would die for the
               same reason the first one did. */
            if (activeCall !== call || connection.connectionState === "connected") return;
            try {
                connection.restartIce();
            } catch {
                /* A WebView old enough to lack restartIce still gets a new offer
                   on the next attempt, which is the half that matters. */
            }
        });
        return true;
    }

    function armIceRecovery(call, connection) {
        if (call.iceRecoveryTimer || !restartAllowed(call)) {
            if (!restartAllowed(call) && connection.connectionState !== "connected") {
                void endCall(translate("The call dropped. The two phones lost each other's network."),
                    "failed", "no-connection");
            }
            return;
        }
        call.iceRecoveryTimer = window.setTimeout(() => {
            call.iceRecoveryTimer = 0;
            if (activeCall !== call) return;
            // A route that healed on its own needs nothing from us.
            if (["connected", "connecting", "new"].includes(connection.connectionState)) return;
            if (!restartCallPath(call, connection)) {
                void endCall(translate("The call dropped. The two phones lost each other's network."),
                    "failed", "no-connection");
            }
        }, ICE_RECOVERY_MS);
    }

    // The microphone is granted on its own first, so a blocked camera can only
    // ever downgrade the call to audio instead of killing it.
    /* A refusal the phone itself can undo gets one tap that opens exactly the
       right settings screen, so nobody has to walk through menus from memory. */
    function armSettingsShortcut(message, error) {
        const notice = document.getElementById("calls-notice");
        if (!notice) {
            showNotice(message, true);
            return;
        }
        if (!canOpenPhoneSettings(error)) {
            notice.onclick = null;
            showNotice(message, true);
            return;
        }
        showNotice(`${message} ${translate("Tap this message to open your phone's settings.")}`, true);
        notice.onclick = () => {
            notice.onclick = null;
            void openMediaSettings();
        };
    }

    /* The phone and the WebView can disagree: Android says recording is allowed
       and the page still gets a refusal. When the phone agrees, asking once
       more is exactly what a restart would have fixed, so the app does it
       itself instead of blaming the student's device. */
    async function getCallStream(mode) {
        try {
            return await openCallStream(mode);
        } catch (error) {
            if (error?.name !== "NotAllowedError" || error?.device !== "microphone") throw error;
            if (await deviceAllowed("microphone") !== true) throw error;
            stopWarmStream();
            return await openCallStream(mode);
        }
    }

    async function openCallStream(mode) {
        const call = await grantCallStream(mode);
        if (call.cameraBlocked) {
            armSettingsShortcut(
                `Camera was blocked, so this call started as audio only. ${permissionHint(call.cameraBlocked)}`,
                call.cameraBlocked
            );
        }
        return call;
    }

    /* Remembered on the call rather than looked up each time: after a track is
       replaced with nothing the sender still exists, and that sender is what a
       later picture has to be handed back to. */
    function primeCallMedia(call, stream, mode) {
        call.localStream = stream;
        call.outgoingTrack = mode === "video" ? stream.getVideoTracks()[0] || null : null;
        call.sharing = call.outgoingTrack ? "camera" : "off";
        call.videoSender = null;
        call.negotiating = false;
        /* Both phones ask for the voice path the moment they own a microphone:
           on Android that is what puts echo cancellation and the short buffers
           to work, and the phone gets its previous audio mode back at the end. */
        void beginCallRoute({ speaker: speakerOn });
        /* As soon as this phone owns a microphone the call is real, and a real call
           has to survive the screen going dark: Android suspends a sleeping phone,
           and the call's audio starves with it. Held until finishCall gives it back. */
        void holdCallWatch(true);
        refreshSpeakerButton();
    }

    async function renegotiate(call) {
        const connection = call.peerConnection;
        call.negotiating = true;
        // A peer who never replies must not leave this phone deaf to his own
        // next attempt.
        window.setTimeout(() => {
            if (activeCall === call) call.negotiating = false;
        }, 15000);
        try {
            const offer = await connection.createOffer();
            await connection.setLocalDescription(lowLatencyAudio(offer));
            await sendSignal(call.peerId, call.id, "offer", connection.localDescription.toJSON());
        } catch (error) {
            call.negotiating = false;
            throw error;
        }
    }

    /* One video slot per call. Filling it later - camera, screen or notes - is a
       track swap when the slot already exists, and one renegotiation when the
       call started as a voice call. Both ride the offer and answer rows the
       database already allows, so nobody has to run new SQL to be seen. */
    async function swapOutgoingVideo(call, track, source) {
        const connection = call.peerConnection;
        if (!connection) return false;
        const previous = call.outgoingTrack;
        const previousSource = call.sharing;
        let needsOffer = false;

        if (call.videoSender) {
            await call.videoSender.replaceTrack(track);
        } else if (track) {
            call.videoSender = connection.addTrack(track, call.localStream);
            needsOffer = true;
        }
        if (track) {
            for (const stale of call.localStream.getVideoTracks()) {
                if (stale !== track) call.localStream.removeTrack(stale);
            }
            if (!call.localStream.getVideoTracks().includes(track)) {
                call.localStream.addTrack(track);
            }
            call.mode = "video";
        }
        call.outgoingTrack = track;
        call.sharing = track ? source : "off";
        // The camera belongs to the session's warm grant and must outlive the
        // call; a screen or a canvas is ours and stops the moment he switches.
        if (previous && previous !== track && previousSource !== "camera") previous.stop();
        showOutgoingPicture(track);
        refreshCallHeader(call);
        if (needsOffer) await renegotiate(call);
        return true;
    }

    function notesVideoTrack() {
        if (!whiteboard) whiteboard = createWhiteboard(notesCanvas);
        if (!notesTrack || notesTrack.readyState !== "live") notesTrack = whiteboard.videoTrack();
        return notesTrack;
    }

    async function shareSource(source) {
        const call = activeCall;
        if (!call?.peerConnection) return;
        try {
            if (source === "camera") {
                await swapOutgoingVideo(call, await grantCameraTrack(), "camera");
                return;
            }
            if (source === "screen") {
                const track = await grantScreenTrack();
                await swapOutgoingVideo(call, track, "screen");
                // He can also stop from the browser's own picker.
                track.addEventListener("ended", () => {
                    if (activeCall === call && call.sharing === "screen") {
                        void swapOutgoingVideo(call, null, "off").catch(() => {});
                    }
                });
                return;
            }
            if (source === "notes") {
                // Shown first: a hidden canvas has no size, and a board captured
                // at one pixel would reach the other side as a blank dot.
                notesDialog?.showModal();
                if (!whiteboard) whiteboard = createWhiteboard(notesCanvas);
                whiteboard.resize();
                await swapOutgoingVideo(call, notesVideoTrack(), "notes");
                notesStopButton?.removeAttribute("hidden");
                return;
            }
            if (source === "off") {
                await swapOutgoingVideo(call, null, "off");
                if (notesDialog?.open) notesDialog.close();
            }
        } catch (error) {
            console.error("Could not change what the call sends:", error);
            showNotice(
                `${translate("That picture did not open on this phone.")} ${permissionHint(error)}`,
                true
            );
        }
    }

    function releaseCallMedia(call) {
        if (!call) return;
        if (call.outgoingTrack && call.sharing !== "camera") call.outgoingTrack.stop();
        if (call.sharing === "notes") notesTrack = null;
        call.outgoingTrack = null;
        call.videoSender = null;
        call.sharing = "off";
    }

    /* Both phones can tap the same button at the same moment. The student who
       dialled is the impolite one: his own offer stands and the second one is
       dropped, which is the classic answer to negotiation glare. */
    async function answerUpgradeOffer(signal) {
        const call = activeCall;
        const connection = call.peerConnection;
        if (!connection) {
            /* This side is still ringing and has no connection to answer with
               yet. Dropping the offer on the floor is how a call that changed
               network before the pickup would then be answered with the old
               addresses: the newest offer is the one the caller is still on, so
               it replaces the one this phone is holding for the tap. */
            if (!call.isCaller && call.peerId === signal.sender_id) {
                call.pendingOffer = signal.payload;
            }
            return;
        }
        if (call.negotiating && call.isCaller) return;
        call.negotiating = false;
        await connection.setRemoteDescription(lowLatencyAudio(signal.payload));
        await flushPendingCandidates();
        const answer = await connection.createAnswer();
        await connection.setLocalDescription(lowLatencyAudio(answer));
        await sendSignal(call.peerId, call.id, "answer", connection.localDescription.toJSON());
    }

    async function startCall(mode) {
        if (!selectedStudent || activeCall) return;
        if (!subscribed && !pollingReady) {
            /* Readiness is only a memory of the last attempt, and Android kills
               both the socket and the requests while the phone sleeps. So the
               tap re-checks instead of refusing on stale state, and only then
               says what actually went wrong. */
            await sweepMissedSignals();
            if (!subscribed) subscribeToCalls();
            if (!subscribed && !pollingReady) {
                scheduleResubscribe();
                showNotice(
                    [translate("Calls are not ready yet."), signalingProblem].filter(Boolean).join(" "),
                    true
                );
                return;
            }
        }

        if (!navigator.mediaDevices?.getUserMedia) {
            showNotice(Capacitor.isNativePlatform()
                ? "This installed app has no camera or microphone access at all. Reinstall Campus Connect and allow both when it asks."
                : "Calls need camera/microphone access on HTTPS or localhost.", true);
            return;
        }

        setCallStatus("Requesting microphone and camera access...");
        try {
            const call = await getCallStream(mode);
            const stream = call.stream;
            mode = call.mode;

            activeCall = {
                id: crypto.randomUUID(),
                peerId: selectedStudent.id,
                peerName: selectedStudent.full_name || selectedStudent.username || "Student",
                mode,
                isCaller: true,
                localStream: stream,
                peerConnection: null,
                pendingOffer: null,
                pendingCandidates: []
            };
            primeCallMedia(activeCall, stream, mode);
            updateButtons();
            showOutgoingPicture(activeCall.outgoingTrack);
            remoteVideo.style.display = mode === "video" ? "block" : "none";
            openCallDialog(mode, `Calling ${activeCall.peerName}...`);

            const connection = createPeerConnection();
            const offer = await connection.createOffer();
            await connection.setLocalDescription(lowLatencyAudio(offer));
            await sendSignal(activeCall.peerId, activeCall.id, "offer", connection.localDescription.toJSON());
            /* The offer rides on realtime, which a shut phone never sees. This
               is the only thing that can make the other phone ring at all. */
            void announcePush(supabase, {
                toUser: activeCall.peerId,
                kind: "call",
                title: `${activeCall.peerName} ${translate("is calling")}`,
                text: mode === "video" ? translate("Video call") : translate("Voice call"),
                thread: activeCall.peerId,
                call: activeCall.id,
                /* The phone that rings builds its own alert from a data-only
                   push, so voice-or-video has to travel with the push. */
                video: mode === "video"
            });
            activeCall.answerTimer = window.setTimeout(() => {
                if (!activeCall || activeCall.peerConnection?.connectionState === "connected") return;
                void endCall(
                    translate("No answer. The student may be offline or away from the app."),
                    "unanswered",
                    "no-answer"
                );
            }, CALL_ANSWER_TIMEOUT_MS);
        } catch (error) {
            console.error("Could not start call:", error);
            finishCall("");
            // A refused device must not stay "warm": the next call has to ask
            // again so a permission allowed in Settings takes effect.
            stopWarmStream();
            armSettingsShortcut(`Could not start call: ${permissionHint(error)}`, error);
        }
    }

    async function acceptCall() {
        const call = activeCall;
        if (!call?.pendingOffer) return;
        stopRingtone();
        window.clearTimeout(call.ringTimer);
        window.clearTimeout(call.graceTimer);
        pendingIncoming = null;
        dialogIncoming = null;
        endAndAcceptButton.hidden = true;
        hideSelfView();

        // Once the answer has left this phone the caller knows he was picked up.
        // From that point on a failure is "it did not connect", never "declined".
        let answerSent = false;
        let stage = "microphone";
        try {
            const media = await getCallStream(call.mode);
            if (activeCall !== call) return;
            call.mode = media.mode;
            primeCallMedia(call, media.stream, media.mode);
            showOutgoingPicture(call.outgoingTrack);

            const offer = call.pendingOffer;
            call.pendingOffer = null;
            incomingDialog.close();
            openCallDialog(media.mode, "Connecting...");

            const connection = createPeerConnection();
            stage = "call details";
            await connection.setRemoteDescription(lowLatencyAudio(offer));
            stage = "network addresses";
            await flushPendingCandidates();
            stage = "your answer";
            const answer = await connection.createAnswer();
            await connection.setLocalDescription(lowLatencyAudio(answer));
            stage = "sending your answer";
            await sendSignal(call.peerId, call.id, "answer", connection.localDescription.toJSON());
            answerSent = true;
            if (activeCall !== call) return;
            // Whoever called may have hung up while we were answering. Without a
            // deadline here the screen sits on "Connecting..." to nobody.
            call.connectTimer = window.setTimeout(() => {
                if (activeCall?.peerConnection?.connectionState === "connected") return;
                finishCall(translate("The other student is no longer on the call"), "missed");
            }, CONNECT_DEADLINE_MS);
        } catch (error) {
            console.error("Could not accept call:", error);
            stopWarmStream();
            if (answerSent) {
                void endCall(
                    translate("You answered, but the call could not connect."),
                    "failed",
                    "no-connection",
                );
            } else if (activeCall === call) {
                await reportCannotAnswer(error);
            }
            armSettingsShortcut(`Could not accept call at ${stage}: ${permissionHint(error)}`, error);
        }
    }

    /* He pressed Accept and the phone could not open a microphone or a camera
       for it. That is a failure on this side, not a refusal, so the caller is
       told why instead of being told "declined". */
    async function reportCannotAnswer(error) {
        const call = activeCall;
        if (!call) return;
        try {
            await sendSignal(call.peerId, call.id, "end", {
                reason: "cannot-answer",
                device: error?.device || "",
            });
        } catch (sendError) {
            console.error("Could not report the failed answer:", sendError);
        } finally {
            finishCall(translate("Could not answer the call."), "failed");
        }
    }

    async function declineCall(kind = "reject") {
        if (!activeCall) return;
        const call = activeCall;
        try {
            await sendSignal(call.peerId, call.id, kind);
        } catch (error) {
            console.error("Could not send call response:", error);
            showNotice(`Could not send call response: ${error.message}`, true);
        } finally {
            finishCall(kind === "reject" ? "Call declined" : "Call ended", "declined");
        }
    }

    // The `end` row already exists in the database, so why the call stopped
    // rides in its JSON payload instead of needing a new signal kind.
    async function endCall(statusText = "Call ended", outcome = null, reason = "") {
        if (!activeCall) return;
        const call = activeCall;
        const announced = sendSignal(call.peerId, call.id, "end", reason ? { reason } : {})
            .catch(error => {
                console.error("Could not notify the other student that the call ended:", error);
                showNotice(`Call ended locally, but the other student may not be notified: ${error.message}`, true);
            });
        const tooLate = new Promise(resolve => {
            window.setTimeout(resolve, END_SIGNAL_WAIT_MS);
        });
        try {
            await Promise.race([announced, tooLate]);
        } finally {
            finishCall(statusText, outcome);
        }
    }

    async function handleSignal(signal) {
        if (!rememberSignal(signal.id)) return;
        const offeredAt = Date.parse(signal.created_at || "");
        if (signal.kind === "offer" && Number.isFinite(offeredAt) &&
            Date.now() - offeredAt > STALE_OFFER_MS) {
            void deleteSignal(signal.id).catch(error => {
                console.warn("Could not remove a stale call offer:", error);
            });
            return;
        }
        try {
            if (signal.kind === "offer") {
                /* The same call offering again is not a second call: it is the
                   student who is already talking to us turning his picture on.
                   It has to be answered before the incoming-call screen sees it,
                   or a mid-call upgrade rings the phone it is already on. */
                if (activeCall?.id === signal.call_id && activeCall.peerId === signal.sender_id) {
                    await answerUpgradeOffer(signal);
                    return;
                }
                const mode = signal.payload?.type === "offer" && signal.payload?.sdp
                    ? (signal.payload?.sdp.includes("m=video") ? "video" : "voice")
                    : null;
                if (!mode) {
                    console.warn("Ignoring malformed incoming call offer.");
                    return;
                }

                // Ask whether the ringing alert already carried an Answer tap.
                await noteAnswerTargets();

                const incoming = {
                    id: signal.call_id,
                    peerId: signal.sender_id,
                    peerName: "Student",
                    mode,
                    isCaller: false,
                    localStream: null,
                    peerConnection: null,
                    pendingOffer: signal.payload,
                    pendingCandidates: []
                };

                if (activeCall) {
                    // Already on a call: offer WhatsApp's "End & accept" instead
                    // of silently replying busy.
                    clearPendingIncoming();
                    pendingIncoming = incoming;
                    dialogIncoming = incoming;
                    describeIncomingCall(incoming);
                    endAndAcceptButton.hidden = false;
                    incomingDialog.showModal();
                    startRingtone({ quiet: !!activeCall.connectedAt });
                    showSelfView(borrowCallStream(mode)?.stream);
                    incoming.ringTimer = window.setTimeout(() => {
                        clearPendingIncoming();
                    }, INCOMING_CALL_RING_TIMEOUT_MS);
                } else {
                    activeCall = incoming;
                    dialogIncoming = incoming;
                    updateButtons();
                    endAndAcceptButton.hidden = true;
                    describeIncomingCall(incoming);
                    incomingDialog.showModal();
                    startRingtone();
                    showSelfView(borrowCallStream(mode)?.stream);
                    incoming.ringTimer = window.setTimeout(expireIncoming, INCOMING_CALL_RING_TIMEOUT_MS);
                    if (shouldAutoAnswer(incoming.id)) {
                        // Answered on the alert already: connect, do not ask twice.
                        void acceptCall();
                    }
                }

                // Show the caller's real name and photo instead of "Student".
                void supabase
                    .from("profiles")
                    .select("full_name, username, avatar_url")
                    .eq("id", signal.sender_id)
                    .maybeSingle()
                    .then(({ data }) => {
                        if (!data) return;
                        const slot = activeCall?.id === signal.call_id && !activeCall.isCaller
                            ? activeCall
                            : pendingIncoming?.id === signal.call_id ? pendingIncoming : null;
                        if (!slot) return;
                        slot.peerName = data.full_name || data.username || "Student";
                        slot.peerUsername = data.username || "";
                        slot.peerAvatar = data.avatar_url || "";
                        describeIncomingCall(slot);
                    })
                    .catch(() => {});
                return;
            }

            if (!activeCall || signal.call_id !== activeCall.id || signal.sender_id !== activeCall.peerId) {
                return;
            }

            if (signal.kind === "answer" &&
                activeCall.peerConnection?.signalingState === "have-local-offer") {
                /* Whichever side spoke last is the one waiting: a mid-call
                   upgrade answers with the same row a first call is answered
                   with, so this cannot be pinned to "the caller". */
                activeCall.negotiating = false;
                await activeCall.peerConnection.setRemoteDescription(lowLatencyAudio(signal.payload));
                await flushPendingCandidates();
                if (activeCall.connectedAt) return;
                // They picked up: stop counting that as "no answer" and give the
                // media path its own short deadline instead.
                window.clearTimeout(activeCall.answerTimer);
                setCallStatus("Connecting...");
                activeCall.connectTimer = window.setTimeout(() => {
                    if (activeCall?.peerConnection?.connectionState === "connected") return;
                    void endCall(
                        translate("They answered but the call could not connect. Check the network."),
                        "failed",
                        "no-connection"
                    );
                }, CONNECT_DEADLINE_MS);
            } else if (signal.kind === "ice") {
                if (activeCall.peerConnection?.remoteDescription) {
                    try {
                        await activeCall.peerConnection.addIceCandidate(signal.payload);
                    } catch (error) {
                        console.warn("Ignoring one call network address:", error);
                    }
                } else {
                    activeCall.pendingCandidates.push(signal.payload);
                }
            } else if (signal.kind === "reject") {
                finishCall(`${activeCall.peerName} declined the call`, "declined");
            } else if (signal.kind === "busy") {
                finishCall(`${activeCall.peerName} is already on a call`, "busy");
            } else if (signal.kind === "end") {
                const reason = signal.payload?.reason;
                const name = activeCall.peerName || "a student";
                if (reason === "no-answer") {
                    finishCall(activeCall.isCaller
                        ? translate("No answer. The student may be offline or away from the app.")
                        : `Missed call from ${name}`,
                    activeCall.isCaller ? "unanswered" : "missed");
                } else if (reason === "no-connection") {
                    finishCall(translate("The call could not connect on their side."), "failed");
                } else if (reason === "cannot-answer") {
                    // He pressed Accept; their phone just could not open a
                    // microphone for it. Reporting that as a refusal is a lie.
                    finishCall(translate("They could not answer: the call would not open on their phone."), "failed");
                } else if (reason === "call-failed") {
                    finishCall(translate("Their app could not open the call."), "failed");
                } else {
                    // Never connected means the caller cancelled, not hung up mid-talk.
                    finishCall(activeCall.connectedAt
                        ? translate("The other student ended the call")
                        : `Missed call from ${name}`,
                    activeCall.connectedAt ? "ended" : "missed");
                }
            }
        } catch (error) {
            console.error("Could not process call signal:", error);
            if (signal.kind === "offer" && activeCall?.id === signal.call_id) {
                try {
                    // This phone could not even open the ring screen. The
                    // student who called has to learn that, not "declined".
                    await sendSignal(signal.sender_id, signal.call_id, "end", { reason: "call-failed" });
                } catch (responseError) {
                    console.error("Could not report the failed incoming call:", responseError);
                }
                finishCall(translate("Could not open the call."), "failed");
            }
            showNotice(`Call signaling error: ${error.message}`, true);
        } finally {
            retireSignal(signal);
        }
    }

    // Realtime can silently miss rows when the table is not in the publication,
    // so a slow sweep of the signaling table keeps calls reachable.
    async function sweepMissedSignals() {
        let result;
        try {
            result = await supabase
                .from("call_signals")
                .select("id, call_id, sender_id, recipient_id, kind, payload, created_at")
                .eq("recipient_id", user.id)
                /* Newest first: with the old ascending order, a busy table pushed
                   the live offer off the page before this sweep ever reached it,
                   and the phone sat silent while the call rang out upstream. */
                .order("created_at", { ascending: false })
                .limit(25);
        } catch (error) {
            // supabase-js throws instead of returning an error when the phone
            // cannot reach the server at all. Uncaught, that silently kept this
            // phone locked out of calls for the rest of the session.
            signalingProblem = describeSignalingError(error);
            console.error("Could not reach the call signaling table:", error);
            return false;
        }
        if (result.error) {
            signalingProblem = describeSignalingError(result.error);
            if (isMissingTableError(result.error)) {
                reportCallSetup(result.error);
                return false;
            }
            console.error("Could not check for incoming call signals:", result.error);
            return false;
        }
        signalingProblem = "";
        if (!subscribed && !pollingReady) setCallStatus("Ready for calls");
        pollingReady = true;
        updateButtons();
        /* Oldest to newest again, so an offer and the answer that followed it
           are still processed in the order they happened. */
        for (const signal of (result.data || []).slice().reverse()) {
            void handleSignal(signal);
        }
        return true;
    }

    function onCallPageVisible() {
        if (document.visibilityState !== "visible") return;
        void sweepMissedSignals();
        // Android drops the websocket while the phone sleeps, so coming back to
        // the foreground has to open it again instead of waiting for nothing.
        if (!subscribed) subscribeToCalls();
        /* An Answer tapped on the alert can reach this page AFTER the offer it
           was meant for - the phone wakes under a page that is still loading,
           and the call is already on screen asking him to decide. He decided
           once. Caught here, because this is the first moment the phone is
           willing to say what he tapped, and acceptCall() ignores a call it has
           already taken over. */
        void noteAnswerTargets().then(() => {
            if (!activeCall?.pendingOffer || activeCall.isCaller) return;
            if (shouldAutoAnswer(activeCall.id)) void acceptCall();
        });
    }

    /* Hidden is not the same as shut. A phone lying face down with the chats
       still open is the one case where a call can still be answered the second
       it lands, so the backup check keeps running there - every few ticks, so a
       screen that has been off for an hour costs a handful of small queries. */
    let hiddenTicks = 0;

    function pollCallSignals() {
        if (document.visibilityState === "visible") {
            hiddenTicks = 0;
            onCallPageVisible();
            return;
        }
        hiddenTicks += 1;
        if (hiddenTicks % BACKGROUND_SWEEP_EVERY !== 0) return;
        void sweepMissedSignals();
        if (!subscribed) subscribeToCalls();
    }

    /* The instant the phone changes network, everything the app was holding on
       the old route is already dead: the signalling socket, and, on a live call,
       the address pair the media was flowing through. Both are rebuilt here
       rather than waiting for the student to notice and reopen the app. */
    function onNetworkChanged() {
        void sweepMissedSignals();
        if (!subscribed) subscribeToCalls();
        const call = activeCall;
        if (call?.peerConnection) restartCallPath(call, call.peerConnection);
    }

    function networkStatus() {
        return navigator.connection || navigator.mozConnection || navigator.webkitConnection || null;
    }

    function watchNetworkChanges() {
        window.addEventListener("online", onNetworkChanged);
        networkStatus()?.addEventListener?.("change", onNetworkChanged);
    }

    function stopWatchingNetworkChanges() {
        window.removeEventListener("online", onNetworkChanged);
        networkStatus()?.removeEventListener?.("change", onNetworkChanged);
    }

    function subscribeToCalls() {
        if (callChannel) return;
        const channel = supabase.channel(`call-signals-${user.id}`);
        callChannel = channel;
        channel
            .on(
                "postgres_changes",
                {
                    event: "INSERT",
                    schema: "public",
                    table: "call_signals",
                    filter: `recipient_id=eq.${user.id}`
                },
                ({ new: signal }) => {
                    void handleSignal(signal);
                }
            )
            .subscribe(status => {
                if (status === "SUBSCRIBED") {
                    subscribed = true;
                    signalingProblem = "";
                    setCallStatus("Ready for calls");
                } else if (status === "CHANNEL_ERROR" || status === "TIMED_OUT" || status === "CLOSED") {
                    subscribed = false;
                    if (callChannel === channel) callChannel = null;
                    void supabase.removeChannel(channel).catch(() => {});
                    scheduleResubscribe();
                    if (!pollingReady) {
                        showNotice("Live call signaling is unavailable, so calls use slower backup checks. If calls do not connect, run database/RUN_ALL.sql in Supabase.", true);
                    }
                }
                updateButtons();
            });
    }

    function scheduleResubscribe() {
        if (resubscribeTimer) return;
        // A socket that died while the phone slept must be opened again on its
        // own; waiting for the student to reopen the app loses the call.
        resubscribeTimer = window.setTimeout(() => {
            resubscribeTimer = 0;
            if (subscribed) return;
            void sweepMissedSignals();
            subscribeToCalls();
        }, SIGNAL_POLL_MS * 2);
    }

    function listenForCalls() {
        subscribeToCalls();
        signalPollTimer = window.setInterval(pollCallSignals, SIGNAL_POLL_MS);
        // Coming back to the foreground is when a missed call is still
        // recoverable, so check straight away instead of waiting for the tick.
        document.addEventListener("visibilitychange", onCallPageVisible);
        watchNetworkChanges();
        /* This page can ring - tell the native watch so it may stand down while
           the app stays here, and only while it stays here. */
        void callWatchListening(true);
        void sweepMissedSignals();
    }

    function lowerListeningOnPageHide() {
        void callWatchListening(false);
    }

    voiceButton.addEventListener("click", () => void startCall("voice"));
    videoButton.addEventListener("click", () => void startCall("video"));

    // iOS re-asks for microphone/camera on every getUserMedia. Granting once
    // at a calm moment right after opening chats keeps later calls prompt-free.
    async function maybeShowCallSetup() {
        const seenKey = `campus-connect-call-setup:${user.id}`;
        try {
            if (localStorage.getItem(seenKey) === "done") return;
        } catch {
            // Private mode can block localStorage; the dialog still works.
        }
        if (!navigator.mediaDevices?.getUserMedia) return;
        if (await grantedAlready()) return;

        const dialog = document.createElement("dialog");
        dialog.innerHTML = `
            <div class="call-setup-body">
                <h3 style="margin:0 0 8px;font-size:1.05rem;">Prepare calls and voice messages</h3>
                <p style="margin:0 0 14px;">Allow the microphone and camera now, once, so calls and voice
                messages never interrupt you with permission popups again. Nothing is recorded until you
                tap call, video call, or the microphone button.</p>
                <p class="call-setup-status" style="margin:0 0 10px;min-height:1.2em;"></p>
                <div style="display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end;">
                    <button type="button" class="secondary call-setup-later">Later</button>
                    <button type="button" class="secondary call-setup-audio">Microphone only</button>
                    <button type="button" class="primary call-setup-allow">Allow microphone &amp; camera</button>
                </div>
            </div>`;
        const statusLine = dialog.querySelector(".call-setup-status");
        const allowButton = dialog.querySelector(".call-setup-allow");
        const audioButton = dialog.querySelector(".call-setup-audio");
        const laterButton = dialog.querySelector(".call-setup-later");

        const close = () => {
            try { localStorage.setItem(seenKey, "done"); } catch {
                // Private mode can block localStorage.
            }
            dialog.remove();
        };
        const grant = async (video) => {
            allowButton.disabled = audioButton.disabled = laterButton.disabled = true;
            statusLine.textContent = "Waiting for your choice…";
            try {
                // The phone's own dialog belongs here, at a calm moment, and not
                // inside a ringing call where it covers the Accept button.
                await askNativeMedia({ video });
                const mode = await acquireWarmStream({ video });
                statusLine.textContent = mode === "video"
                    ? "Microphone and camera are ready."
                    : "Microphone is ready.";
                showNotice("Calls and voice messages are ready. You will not be asked again.");
            } catch (error) {
                statusLine.textContent = "";
                const message = `Could not reach the microphone: ${permissionHint(error)}`;
                if (error?.name === "NotAllowedError") {
                    armSettingsShortcut(message, error);
                } else {
                    showNotice(message, true);
                }
            }
            close();
        };
        allowButton.addEventListener("click", () => void grant(true));
        audioButton.addEventListener("click", () => void grant(false));
        laterButton.addEventListener("click", close);
        dialog.addEventListener("cancel", event => {
            event.preventDefault();
            close();
        });

        document.body.appendChild(dialog);
        dialog.showModal();
    }
    window.setTimeout(() => void maybeShowCallSetup(), 1500);

    /* The answer to "I allowed everything, why does the call still fail?":
       every device is asked for on its own, so the screen says which one the
       phone is actually refusing and shows the fix for that device. */
    const MEDIA_ERROR_CAUSES = new Map([
        ["NotAllowedError", "permission is blocked"],
        ["NotFoundError", "this phone has no such device"],
        ["OverconstrainedError", "no matching device"],
        ["NotReadableError", "another app is using it"],
        ["SecurityError", "the app is not running over a secure connection"]
    ]);

    function mediaResultLine(label, result) {
        if (result?.ok) {
            /* A working microphone with no echo cancellation still gives the
               other student an echo, so the line says both. */
            const echo = typeof result.echoCancellation === "boolean"
                ? ` · ${translate(result.echoCancellation ? "Echo cancellation: on" : "Echo cancellation: off")}`
                : "";
            return `${label}: works ✓${echo}`;
        }
        const cause = MEDIA_ERROR_CAUSES.get(result?.name) || result?.name || "unknown error";
        return `${label}: blocked ✗ (${cause})`;
    }

    async function runMediaTest() {
        if (!navigator.mediaDevices?.getUserMedia) {
            mediaTestMicrophone.textContent = "Microphone: not available here";
            mediaTestCamera.textContent = "Camera: not available here";
            mediaTestHelp.textContent = Capacitor.isNativePlatform()
                ? "This installed app build has no camera or microphone access at all. Reinstall Campus Connect and allow both when it asks."
                : "Calls need HTTPS. Open the app over https:// and try again.";
            return;
        }
        mediaTestMicrophone.textContent = translate("Microphone: checking…");
        mediaTestCamera.textContent = translate("Camera: checking…");
        mediaTestHelp.textContent = "If a permission popup appears, tap Allow.";
        mediaTestSettings.hidden = true;
        const result = await probeMedia();
        mediaTestMicrophone.textContent = mediaResultLine("Microphone", result.microphone);
        mediaTestCamera.textContent = mediaResultLine("Camera", result.camera);
        const blocked = ["microphone", "camera"].filter(device => !result[device].ok);
        /* Only a refusal is worth a jump into the phone's settings; a missing
           microphone or one held by another app cannot be fixed there. */
        mediaTestSettings.hidden = !(blocked.length && Capacitor.isNativePlatform());
        mediaTestHelp.textContent = blocked.length
            ? blocked.map(device => permissionHint({
                name: result[device].name,
                device
            })).join(" ")
            : result.microphone.echoCancellation === false
                ? translate("Both devices work, but this phone did not switch echo cancellation on. Lower the volume or use earphones so the other student hears no echo.")
                : "Both devices work. If a call still fails, ask the other student to reopen the app.";
    }

    testMediaButton?.addEventListener("click", () => {
        callsMenuDialog?.close();
        mediaTestDialog?.showModal();
        void runMediaTest();
    });
    mediaTestClose?.addEventListener("click", () => mediaTestDialog?.close());
    mediaTestSettings?.addEventListener("click", () => {
        mediaTestDialog?.close();
        void openMediaSettings();
    });

    /* He is allowed to fix the phone's own switch in his own time. When he walks
       back in, the app notices by itself instead of making him restart it. */
    watchDevicePermissions(status => {
        if (status.microphone !== "granted" && status.camera !== "granted") return;
        stopWarmStream();
        showNotice(translate("Permission is allowed now. Your next call will just work."));
    });

    // The dialog can be showing either the call we are on hold for (pending) or
    // the live incoming one, so dismissal has to pick the right target.
    function dismissIncoming() {
        if (pendingIncoming && dialogIncoming === pendingIncoming) {
            clearPendingIncoming();
            return;
        }
        void declineCall();
    }

    acceptCallButton.addEventListener("click", () => void acceptCall());
    endAndAcceptButton.addEventListener("click", () => {
        const incoming = pendingIncoming;
        if (!incoming) return;
        pendingIncoming = null;
        window.clearTimeout(incoming.ringTimer);
        closeIncomingDialog();
        void (async () => {
            await endCall("Previous call ended", "ended");
            activeCall = incoming;
            dialogIncoming = incoming;
            updateButtons();
            await acceptCall();
        })();
    });
    document.getElementById("decline-call-button").addEventListener("click", dismissIncoming);
    document.getElementById("incoming-message-button").addEventListener("click", () => {
        const peer = dialogIncoming;
        dismissIncoming();
        if (peer) {
            window.dispatchEvent(new CustomEvent("campus-connect:open-chat", {
                detail: { peerId: peer.peerId, peerName: peer.peerName }
            }));
        }
    });
    document.getElementById("incoming-remind-button").addEventListener("click", () => {
        const peer = dialogIncoming;
        dismissIncoming();
        if (!peer) return;
        const at = Date.now() + 15 * 60 * 1000;
        addScheduledCall(user.id, {
            peerId: peer.peerId,
            peerName: peer.peerName,
            mode: peer.mode,
            at
        });
        showNotice(`Call reminder set for ${formatReminderTime(at)}.`);
    });
    document.getElementById("end-call-button").addEventListener("click", () => void endCall());
    microphoneButton.addEventListener("click", () => {
        const track = activeCall?.localStream?.getAudioTracks()[0];
        if (!track) return;
        track.enabled = !track.enabled;
        microphoneButton.textContent = track.enabled ? translate("Mute") : translate("Unmute");
    });
    speakerButton?.addEventListener("click", () => {
        speakerOn = !speakerOn;
        rememberSpeakerPreference(speakerOn);
        refreshSpeakerButton();
        void setCallSpeaker(speakerOn);
    });
    cameraButton.addEventListener("click", () => {
        const track = activeCall?.localStream?.getVideoTracks()[0];
        if (!track) return;
        track.enabled = !track.enabled;
        cameraButton.textContent = track.enabled ? translate("Camera") : translate("Cam off");
    });

    // The three pictures share one slot: choosing a new one hands the slot over.
    startVideoButton.addEventListener("click", () => void shareSource("camera"));
    shareScreenButton.addEventListener("click", () => void shareSource(
        activeCall?.sharing === "screen" ? "off" : "screen"
    ));
    shareNotesButton.addEventListener("click", () => void shareSource(
        activeCall?.sharing === "notes" ? "off" : "notes"
    ));

    /* Browsers refuse to play a voice nobody has touched yet. Rather than leave
       the student believing the call is dead, the screen asks for the one tap
       that is allowed to unlock it - and gets out of the way as soon as sound
       is actually flowing. */
    remoteSoundChip?.addEventListener("click", () => {
        remoteAudio.play().then(hideSoundChip).catch(() => {
            showNotice(translate("Still no sound. Turn the volume up and check the other phone."), true);
        });
    });
    remoteAudio.addEventListener("playing", hideSoundChip);

    function setBoardMode(mode) {
        whiteboard?.setMode(mode);
        notesPenButton?.classList.toggle("is-on", mode === "pen");
        notesEraserButton?.classList.toggle("is-on", mode === "eraser");
    }

    notesPenButton?.addEventListener("click", () => setBoardMode("pen"));
    notesEraserButton?.addEventListener("click", () => setBoardMode("eraser"));
    notesUndoButton?.addEventListener("click", () => whiteboard?.undo());
    notesClearButton?.addEventListener("click", () => whiteboard?.clear());
    notesStopButton?.addEventListener("click", () => void shareSource("off"));
    notesCloseButton?.addEventListener("click", () => notesDialog?.close());
    notesDialog?.addEventListener("cancel", event => {
        event.preventDefault();
        notesDialog.close();
    });
    window.addEventListener("resize", () => {
        if (notesDialog?.open) whiteboard?.resize();
    });

    function paintCallSwitches() {
        const plain = plainCallMicrophone();
        plainMicButton?.setAttribute("aria-pressed", plain ? "true" : "false");
        plainMicButton?.classList.toggle("is-on", plain);
        meterToggleButton?.setAttribute("aria-pressed", meterRequested() ? "true" : "false");
        meterToggleButton?.classList.toggle("is-on", meterRequested());
    }

    plainMicButton?.addEventListener("click", () => {
        const next = !plainCallMicrophone();
        setPlainCallMicrophone(next);
        paintCallSwitches();
        showNotice(next
            ? translate("The next call opens the microphone the plain way, with no echo cancelling.")
            : translate("The next call uses the phone's call audio path again."));
    });
    meterToggleButton?.addEventListener("click", () => {
        setMeterRequested(!meterRequested());
        paintCallSwitches();
        showNotice(translate("The sound bars appear in your next call."));
    });
    incomingDialog.addEventListener("cancel", event => {
        event.preventDefault();
        dismissIncoming();
    });
    callDialog.addEventListener("cancel", event => {
        event.preventDefault();
        void endCall();
    });

    listenForCalls();
    window.addEventListener("pagehide", lowerListeningOnPageHide);
    void cleanExpiredSignals();
    cleanupTimer = window.setInterval(cleanExpiredSignals, 24 * 60 * 60 * 1000);
    paintCallSwitches();
    updateButtons();

    return {
        setSelectedStudent,
        startCallWith: (student, mode) => {
            setSelectedStudent(student);
            return startCall(mode);
        },
        /* Is a live call sitting on this phone right now? The chat asks before
           announcing a dead one, so "Missed call" never contradicts a screen
           that is ringing. */
        hasLiveOffer: () => Boolean(activeCall && !activeCall.isCaller) || Boolean(pendingIncoming),
        /* Has this page actually reached the signalling table yet? Without it a
           slow load could announce "they called" seconds before its own ringing
           dialog appears for that very call. */
        heardFromSignaling: () => subscribed || pollingReady,
        dispose: () => {
            if (activeCall) finishCall("");
            window.clearInterval(cleanupTimer);
            window.clearInterval(signalPollTimer);
            window.clearTimeout(resubscribeTimer);
            resubscribeTimer = 0;
            document.removeEventListener("visibilitychange", onCallPageVisible);
            window.removeEventListener("pagehide", lowerListeningOnPageHide);
            /* This page stops hearing calls the moment it goes - the watch must
               take them again rather than trust a phantom listener. */
            void callWatchListening(false);
            stopWatchingNetworkChanges();
            if (callChannel) void supabase.removeChannel(callChannel);
            callChannel = null;
        }
    };
}
