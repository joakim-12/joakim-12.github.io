# Build Campus Connect for iPhone

This project is configured for iPhone and iPad (iOS 15 or later). The checked-in iOS project contains the current web app bundle at version 1.52, build 117.

## Build and install on an iPhone

1. Unzip the project on a Mac with Xcode installed.
2. Open Terminal in the unzipped project folder and run `npm ci` to install the Capacitor iOS plugin packages.
3. Open `ios/App/App.xcodeproj` in Xcode.
4. Select the **App** target, open **Signing & Capabilities**, and choose an Apple development team. Change the bundle identifier if your team does not own `com.campusconnect.app`.
5. Connect and unlock the iPhone, choose it as the run destination, then press **Run** in Xcode.

The app uses the existing Supabase backend. The built web bundle is already included in `ios/App/App/public`; a fresh web rebuild needs the project's private `.env` values and should not be generated from the example placeholders.

## Notifications and calls

The app can handle calls while it is open. Background incoming-call ringing on iPhone needs Apple's CallKit and VoIP PushKit setup plus server-side VoIP push delivery; this project currently has the background call-watch implementation for Android only. iPhone push notifications also need the app's Firebase/APNs configuration before they can be delivered to a device. That configuration is not included in this source archive.
