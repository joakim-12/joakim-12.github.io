// Curated directory of university online systems (student portal / ENT, LMS, registry, official site).
// Generated 2026-10-15 from a live web-research pass. A URL is listed only when it was actually seen in a
// search result or official page; entries whose platform is known but whose address is unpublished carry
// "platform" alone and render as a search shortcut instead of a link.
//
// Terminology: ENT (Espace Numérique de Travail) = student portal / virtual learning environment.
// LMS = learning management system (Moodle, Blackboard, Canvas, Brightspace, Teams).
// Registry / Records = the institution's own database of admission, enrolment, transcripts and fees.

export const UNIVERSITY_PORTALS = [
    {
        "name": "Kabarak University",
        "country": "Kenya",
        "city": "Kabarak / Bomet (Njoro)",
        "aliases": [
            "kabarak",
            "kabarak university",
            "ku",
            "kabarak univ"
        ],
        "website": {
            "url": "https://kabarak.ac.ke/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://students.kabarak.ac.ke/",
            "label": "Student Portal (ENT)",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": "https://moodle.kabarak.ac.ke/",
            "label": null,
            "platform": "Moodle",
            "verified": true
        },
        "registry": {
            "url": null,
            "label": "Registry / Results (inside Student Portal)",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "University of Nairobi",
        "country": "Kenya",
        "city": "Nairobi",
        "aliases": [
            "uon",
            "nairobi university",
            "university of nairobi",
            "uonbi"
        ],
        "website": {
            "url": "https://www.uonbi.ac.ke/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://smis.uonbi.ac.ke/",
            "label": "SMIS Student Portal",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": "https://eclass.uonbi.ac.ke/",
            "label": null,
            "platform": "Moodle",
            "verified": true
        },
        "registry": {
            "url": "https://smis.uonbi.ac.ke/",
            "label": "Student Records & Registration (SMIS)",
            "platform": null,
            "verified": true
        }
    },
    {
        "name": "Kenyatta University",
        "country": "Kenya",
        "city": "Nairobi (Thika)",
        "aliases": [
            "ku",
            "kenyatta university",
            "ku.ac.ke"
        ],
        "website": {
            "url": "https://www.ku.ac.ke/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://portal.ku.ac.ke/",
            "label": "Student Portal (Self-Service)",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": null,
            "label": null,
            "platform": null,
            "verified": false
        },
        "registry": {
            "url": null,
            "label": "Online Registration / Results",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "Moi University",
        "country": "Kenya",
        "city": "Eldoret",
        "aliases": [
            "moi",
            "moi university",
            "mu",
            "muse"
        ],
        "website": {
            "url": "https://mu.ac.ke/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://portal.mu.ac.ke/",
            "label": "Student Portal",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": "https://iodl.mu.ac.ke/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "registry": {
            "url": null,
            "label": "Registration / Results (Student Portal)",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "Jomo Kenyatta University of Agriculture and Technology",
        "country": "Kenya",
        "city": "Juja / Nairobi",
        "aliases": [
            "jkuat",
            "jkuate",
            "jomo kenyatta"
        ],
        "website": {
            "url": "https://www.jkuat.ac.ke/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://portal.jkuat.ac.ke/",
            "label": "Student Portal",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": "https://sodel3v2.jkuat.ac.ke/",
            "label": null,
            "platform": "Moodle",
            "verified": true
        },
        "registry": {
            "url": null,
            "label": "Registration / Results (Student Portal)",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "Strathmore University",
        "country": "Kenya",
        "city": "Nairobi",
        "aliases": [
            "strathmore",
            "su",
            "strath"
        ],
        "website": {
            "url": "https://strathmore.edu/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://siso.strathmore.edu/login",
            "label": "Account Access / SIS",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": "https://elearning.strathmore.edu/",
            "label": null,
            "platform": "LMS",
            "verified": true
        },
        "registry": {
            "url": null,
            "label": "Registry / Fees",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "Egerton University",
        "country": "Kenya",
        "city": "Njoro / Nakuru",
        "aliases": [
            "egerton",
            "eu"
        ],
        "website": {
            "url": "https://www.egerton.ac.ke/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://studentportal.egerton.ac.ke/",
            "label": "Student Portal (Uni-Plus)",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": null,
            "label": null,
            "platform": null,
            "verified": false
        },
        "registry": {
            "url": null,
            "label": "Registration / Results (Student Portal)",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "Maseno University",
        "country": "Kenya",
        "city": "Maseno / Siaya",
        "aliases": [
            "maseno",
            "msu"
        ],
        "website": {
            "url": "https://www.maseno.ac.ke/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://student.maseno.ac.ke/",
            "label": "Student Portal",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": "https://ecampus.maseno.ac.ke/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "registry": {
            "url": null,
            "label": "Registration / Results",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "Dedan Kimathi University of Technology",
        "country": "Kenya",
        "city": "Nyeri",
        "aliases": [
            "dkut",
            "dedan kimathi",
            "dedkim"
        ],
        "website": {
            "url": "https://www.dkut.ac.ke/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://portal.dkut.ac.ke/",
            "label": "Student Portal",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": "https://codel.dkut.ac.ke/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "registry": {
            "url": null,
            "label": "Registration / Results (Student Portal)",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "Masinde Muliro University of Science and Technology",
        "country": "Kenya",
        "city": "Kakamega",
        "aliases": [
            "mmust",
            "masinde muliro",
            "sife"
        ],
        "website": {
            "url": "https://mmust.ac.ke/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": null,
            "label": "Student Portal",
            "platform": null,
            "verified": false
        },
        "lms": {
            "url": "https://elearning.mmust.ac.ke/",
            "label": null,
            "platform": "Moodle",
            "verified": true
        },
        "registry": {
            "url": null,
            "label": "Registration / Results",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "Multimedia University of Kenya",
        "country": "Kenya",
        "city": "Nairobi (Embuni)",
        "aliases": [
            "mmu",
            "multimedia university kenya",
            "mmukenya"
        ],
        "website": {
            "url": "https://www.mmu.ac.ke/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://studentportal.mmu.ac.ke/",
            "label": "Student Portal",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": null,
            "label": null,
            "platform": null,
            "verified": false
        },
        "registry": {
            "url": null,
            "label": "Registration / Results",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "Technical University of Kenya",
        "country": "Kenya",
        "city": "Nairobi",
        "aliases": [
            "tuk",
            "technical university of kenya",
            "tukenya"
        ],
        "website": {
            "url": "https://tukenya.ac.ke/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://portal.tukenya.ac.ke/",
            "label": "Student Portal",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": "https://elearning.tukenya.ac.ke/",
            "label": null,
            "platform": "Moodle",
            "verified": true
        },
        "registry": {
            "url": null,
            "label": "Registration / Results",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "Daystar University",
        "country": "Kenya",
        "city": "Nairobi / Athi River",
        "aliases": [
            "daystar",
            "du"
        ],
        "website": {
            "url": "https://www.daystar.ac.ke/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://student.daystar.ac.ke/",
            "label": "Student Portal",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": "https://elearning.daystar.ac.ke/",
            "label": null,
            "platform": "Moodle",
            "verified": true
        },
        "registry": {
            "url": null,
            "label": "Registration / Results",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "Kenya Methodist University",
        "country": "Kenya",
        "city": "Meru",
        "aliases": [
            "kemu",
            "kenya methodist"
        ],
        "website": {
            "url": "https://kemu.ac.ke/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://students.kemu.ac.ke/",
            "label": "Student Portal",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": null,
            "label": null,
            "platform": null,
            "verified": false
        },
        "registry": {
            "url": null,
            "label": "Registration / Results",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "Makerere University",
        "country": "Uganda",
        "city": "Kampala",
        "aliases": [
            "makerere",
            "mak",
            "mu"
        ],
        "website": {
            "url": "https://www.mak.ac.ug/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://myportal.mak.ac.ug/",
            "label": "ACMIS Student Portal",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": "https://muele.mak.ac.ug/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "registry": {
            "url": "https://myportal.mak.ac.ug/",
            "label": "Enrolment, Registration & Results (ACMIS)",
            "platform": null,
            "verified": true
        }
    },
    {
        "name": "Kyambogo University",
        "country": "Uganda",
        "city": "Kyambogo",
        "aliases": [
            "kyambogo",
            "kyu"
        ],
        "website": {
            "url": null,
            "label": null,
            "platform": null,
            "verified": false
        },
        "portal": {
            "url": "https://myportal.kyu.ac.ug/",
            "label": "ACMIS Student Portal",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": null,
            "label": null,
            "platform": null,
            "verified": false
        },
        "registry": {
            "url": null,
            "label": "Registration & Results (ACMIS)",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "Mbarara University of Science and Technology",
        "country": "Uganda",
        "city": "Mbarara",
        "aliases": [
            "must",
            "mbarara university"
        ],
        "website": {
            "url": "https://www.must.ac.ug/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://student.must.ac.ug/",
            "label": "Student Portal",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": "https://vle.must.ac.ug/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "registry": {
            "url": null,
            "label": "Registration & Results",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "University of Dar es Salaam",
        "country": "Tanzania",
        "city": "Dar es Salaam",
        "aliases": [
            "udsm",
            "dar es salaam university"
        ],
        "website": {
            "url": "https://www.udsm.ac.tz/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": null,
            "label": "Student Registration Portal",
            "platform": null,
            "verified": false
        },
        "lms": {
            "url": "https://lms.udsm.ac.tz/",
            "label": null,
            "platform": "Moodle",
            "verified": true
        },
        "registry": {
            "url": null,
            "label": "Registry / Results",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "Open University of Tanzania",
        "country": "Tanzania",
        "city": "Dar es Salaam",
        "aliases": [
            "out",
            "open university tanzania"
        ],
        "website": {
            "url": "https://www.out.ac.tz/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": null,
            "label": "ARMIS Student Portal",
            "platform": null,
            "verified": false
        },
        "lms": {
            "url": "https://elms.out.ac.tz/",
            "label": null,
            "platform": "Moodle",
            "verified": true
        },
        "registry": {
            "url": "https://sis.out.ac.tz/",
            "label": "ARMIS Management Information System",
            "platform": null,
            "verified": true
        }
    },
    {
        "name": "Sokoine University of Agriculture",
        "country": "Tanzania",
        "city": "Morogoro",
        "aliases": [
            "sua",
            "sokoine"
        ],
        "website": {
            "url": "https://www.sua.ac.tz/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": null,
            "label": "SUAS / Student Portal",
            "platform": null,
            "verified": false
        },
        "lms": {
            "url": null,
            "label": null,
            "platform": "Moodle",
            "verified": false
        },
        "registry": {
            "url": null,
            "label": "Results & Registration (SUA-ESB)",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "University of Rwanda",
        "country": "Rwanda",
        "city": "Kigali",
        "aliases": [
            "ur",
            "university of rwanda"
        ],
        "website": {
            "url": "https://ur.ac.rw/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://ienabler.ur.ac.rw/pls/prodi41/w99pkg.mi_login",
            "label": "iEnabler Self-Help Student Portal",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": null,
            "label": null,
            "platform": null,
            "verified": false
        },
        "registry": {
            "url": "https://ienabler.ur.ac.rw/pls/prodi41/w99pkg.mi_login",
            "label": "Registration & Records (iEnabler)",
            "platform": null,
            "verified": true
        }
    },
    {
        "name": "Carnegie Mellon University Africa",
        "country": "Rwanda",
        "city": "Kigali",
        "aliases": [
            "cmu africa",
            "cmu-africa",
            "carnegie mellon africa"
        ],
        "website": {
            "url": "https://www.africa.engineering.cmu.edu/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": null,
            "label": "CMU Student Portal (ANDES)",
            "platform": null,
            "verified": false
        },
        "lms": {
            "url": null,
            "label": null,
            "platform": "Canvas",
            "verified": false
        },
        "registry": {
            "url": null,
            "label": "Registrar",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "African Leadership University",
        "country": "Rwanda",
        "city": "Kigali (also Zambia/South Africa)",
        "aliases": [
            "alu",
            "african leadership university",
            "alueducation"
        ],
        "website": {
            "url": "https://www.alueducation.com/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://student.alueducation.com/s/login/",
            "label": "ALU Student Portal",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": null,
            "label": null,
            "platform": null,
            "verified": false
        },
        "registry": {
            "url": null,
            "label": "Admissions Portal",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "University of Ibadan",
        "country": "Nigeria",
        "city": "Ibadan",
        "aliases": [
            "ui",
            "university of ibadan"
        ],
        "website": {
            "url": "https://ui.edu.ng/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://student-portal.ui.edu.ng/",
            "label": "Student Portal",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": null,
            "label": null,
            "platform": null,
            "verified": false
        },
        "registry": {
            "url": null,
            "label": "Postgraduate / Results Portal",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "University of Lagos",
        "country": "Nigeria",
        "city": "Lagos (Akoka)",
        "aliases": [
            "unilag",
            "university of lagos",
            "ulag"
        ],
        "website": {
            "url": null,
            "label": null,
            "platform": null,
            "verified": false
        },
        "portal": {
            "url": "https://studentportal.unilag.edu.ng/",
            "label": "Student Portal",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": "https://dlilearn.unilag.edu.ng/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "registry": {
            "url": null,
            "label": "Registration & Results",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "Obafemi Awolowo University",
        "country": "Nigeria",
        "city": "Ile-Ife",
        "aliases": [
            "oau",
            "obafemi awolowo",
            "ifedayo"
        ],
        "website": {
            "url": "https://oauife.edu.ng/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://eportal2.oauife.edu.ng/",
            "label": "ePortal 2 (Student Portal)",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": null,
            "label": null,
            "platform": null,
            "verified": false
        },
        "registry": {
            "url": "https://eportal.oauife.edu.ng/",
            "label": "Student Information Portal (Registration / Results)",
            "platform": null,
            "verified": true
        }
    },
    {
        "name": "Ahmadu Bello University",
        "country": "Nigeria",
        "city": "Zaria",
        "aliases": [
            "abu",
            "abu zaria",
            "ahmadu bello"
        ],
        "website": {
            "url": "https://abu.edu.ng/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://portal.abu.edu.ng/",
            "label": "ABU Students' Registration Portal",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": null,
            "label": null,
            "platform": null,
            "verified": false
        },
        "registry": {
            "url": null,
            "label": "Registration & Results",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "Covenant University",
        "country": "Nigeria",
        "city": "Ota / Sango-Ota",
        "aliases": [
            "covenant",
            "cu",
            "covenant university"
        ],
        "website": {
            "url": "https://www.covenantuniversity.edu.ng/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": null,
            "label": "CU Staff/Student Portal (legacy host)",
            "platform": null,
            "verified": false
        },
        "lms": {
            "url": null,
            "label": null,
            "platform": null,
            "verified": false
        },
        "registry": {
            "url": null,
            "label": "Admission Portal",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "University of Cape Town",
        "country": "South Africa",
        "city": "Cape Town",
        "aliases": [
            "uct",
            "cape town university"
        ],
        "website": {
            "url": "https://www.uct.ac.za/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": null,
            "label": "Student Self-Service (PeopleSoft)",
            "platform": null,
            "verified": false
        },
        "lms": {
            "url": "https://amathuba.uct.ac.za/",
            "label": null,
            "platform": "Brightspace",
            "verified": true
        },
        "registry": {
            "url": null,
            "label": "Registration & Academic Records",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "University of the Witwatersrand",
        "country": "South Africa",
        "city": "Johannesburg",
        "aliases": [
            "wits",
            "witwatersrand"
        ],
        "website": {
            "url": "https://www.wits.ac.za/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://my.wits.ac.za/",
            "label": "MyWits Student Portal",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": null,
            "label": null,
            "platform": "Canvas",
            "verified": false
        },
        "registry": {
            "url": null,
            "label": "Student Records & Fees (MyWits)",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "Stellenbosch University",
        "country": "South Africa",
        "city": "Stellenbosch",
        "aliases": [
            "stu",
            "stellenbosch",
            "maties"
        ],
        "website": {
            "url": "https://www.su.ac.za/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://student.sun.ac.za/",
            "label": "Sun Student Portal",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": null,
            "label": null,
            "platform": "Moodle",
            "verified": false
        },
        "registry": {
            "url": null,
            "label": "Student Administration",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "University of South Africa",
        "country": "South Africa",
        "city": "Pretoria (distance learning)",
        "aliases": [
            "unisa",
            "south africa university"
        ],
        "website": {
            "url": "https://www.unisa.ac.za/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://www.unisa.ac.za/sites/myunisa/default/",
            "label": "myUnisa",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": null,
            "label": null,
            "platform": null,
            "verified": false
        },
        "registry": {
            "url": null,
            "label": "myUnisa-admin / Registration",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "University of Johannesburg",
        "country": "South Africa",
        "city": "Johannesburg",
        "aliases": [
            "uj",
            "johannesburg university"
        ],
        "website": {
            "url": "https://www.uj.ac.za/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://ulink.uj.ac.za/",
            "label": "uLink Student Portal",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": null,
            "label": null,
            "platform": "Moodle",
            "verified": false
        },
        "registry": {
            "url": "https://registration.uj.ac.za/pls/prodi41/w99pkg.mi_login",
            "label": "iEnabler Registration / Self-Help",
            "platform": null,
            "verified": true
        }
    },
    {
        "name": "University of Pretoria",
        "country": "South Africa",
        "city": "Pretoria",
        "aliases": [
            "up",
            "pretoria university"
        ],
        "website": {
            "url": "https://www.up.ac.za/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://www.up.ac.za/registration/student-portal",
            "label": "UP Student Portal",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": null,
            "label": null,
            "platform": "Blackboard",
            "verified": false
        },
        "registry": {
            "url": null,
            "label": "Registration & Academic Records",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "University of Ghana",
        "country": "Ghana",
        "city": "Accra (Legon)",
        "aliases": [
            "ug",
            "legon",
            "university of ghana"
        ],
        "website": {
            "url": "https://www.ug.edu.gh/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": null,
            "label": "UG Student Portal (STS / MIS)",
            "platform": null,
            "verified": false
        },
        "lms": {
            "url": "https://sakai.ug.edu.gh/",
            "label": null,
            "platform": "Sakai",
            "verified": true
        },
        "registry": {
            "url": null,
            "label": "Academic Registration",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "Kwame Nkrumah University of Science and Technology",
        "country": "Ghana",
        "city": "Kumasi",
        "aliases": [
            "knust",
            "nkrumah"
        ],
        "website": {
            "url": null,
            "label": null,
            "platform": null,
            "verified": false
        },
        "portal": {
            "url": "https://studentportal.knust.edu.gh/",
            "label": "Student Portal (AIM)",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": "https://myclass.knust.edu.gh/",
            "label": null,
            "platform": "Google Classroom",
            "verified": true
        },
        "registry": {
            "url": null,
            "label": "Registration & Results",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "Massachusetts Institute of Technology",
        "country": "USA",
        "city": "Cambridge, MA",
        "aliases": [
            "mit",
            "mit edu"
        ],
        "website": {
            "url": "https://www.mit.edu/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": null,
            "label": "WebSIS Student Information System",
            "platform": null,
            "verified": false
        },
        "lms": {
            "url": "https://canvas.mit.edu/",
            "label": null,
            "platform": "Canvas",
            "verified": true
        },
        "registry": {
            "url": null,
            "label": "Registrar / Course 6 enrollment",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "Stanford University",
        "country": "USA",
        "city": "Stanford, CA",
        "aliases": [
            "stanford",
            "su"
        ],
        "website": {
            "url": "https://www.stanford.edu/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://axess.stanford.edu/",
            "label": "Axess Student Portal",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": "https://canvas.stanford.edu/",
            "label": null,
            "platform": "Canvas",
            "verified": true
        },
        "registry": {
            "url": "https://axess.stanford.edu/",
            "label": "Enrollment, Grades & Billing (Axess)",
            "platform": null,
            "verified": true
        }
    },
    {
        "name": "Harvard University",
        "country": "USA",
        "city": "Cambridge, MA",
        "aliases": [
            "harvard",
            "hu"
        ],
        "website": {
            "url": "https://www.harvard.edu/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://my.harvard.edu/",
            "label": "my.harvard (HarvardKey)",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": "https://canvas.harvard.edu/",
            "label": null,
            "platform": "Canvas",
            "verified": true
        },
        "registry": {
            "url": null,
            "label": "OneStop / Registrar",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "University of Michigan",
        "country": "USA",
        "city": "Ann Arbor, MI",
        "aliases": [
            "umich",
            "michigan",
            "u-m"
        ],
        "website": {
            "url": null,
            "label": null,
            "platform": null,
            "verified": false
        },
        "portal": {
            "url": "https://wolverineaccess.umich.edu/",
            "label": "Wolverine Access Gateway",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": "https://canvas.umich.edu/",
            "label": null,
            "platform": "Canvas",
            "verified": true
        },
        "registry": {
            "url": "https://wolverineaccess.umich.edu/",
            "label": "Student Records, Enrollment & Bills",
            "platform": null,
            "verified": true
        }
    },
    {
        "name": "University of California, Berkeley",
        "country": "USA",
        "city": "Berkeley, CA",
        "aliases": [
            "berkeley",
            "cal",
            "ucb"
        ],
        "website": {
            "url": null,
            "label": null,
            "platform": null,
            "verified": false
        },
        "portal": {
            "url": "https://calcentral.berkeley.edu/",
            "label": "CalCentral",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": null,
            "label": null,
            "platform": "Canvas",
            "verified": false
        },
        "registry": {
            "url": "https://studentcentral.berkeley.edu/",
            "label": "Cal Student Central (records, enrollment, fees)",
            "platform": null,
            "verified": true
        }
    },
    {
        "name": "University of Oxford",
        "country": "UK",
        "city": "Oxford",
        "aliases": [
            "oxford",
            "ox"
        ],
        "website": {
            "url": "https://www.ox.ac.uk/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": null,
            "label": "Oxford SSO / Student Self-Service (UniWeb)",
            "platform": null,
            "verified": false
        },
        "lms": {
            "url": "https://canvas.ox.ac.uk/",
            "label": null,
            "platform": "Canvas",
            "verified": true
        },
        "registry": {
            "url": null,
            "label": "Student Record System",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "University of Cambridge",
        "country": "UK",
        "city": "Cambridge",
        "aliases": [
            "cambridge",
            "cam"
        ],
        "website": {
            "url": "https://www.cam.ac.uk/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://www.camsis.cam.ac.uk/",
            "label": "CamSIS (Student Information System)",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": "https://www.vle.cam.ac.uk/",
            "label": null,
            "platform": "Moodle",
            "verified": true
        },
        "registry": {
            "url": "https://www.camsis.cam.ac.uk/",
            "label": "Student Records & Registration (CamSIS)",
            "platform": null,
            "verified": true
        }
    },
    {
        "name": "Imperial College London",
        "country": "UK",
        "city": "London",
        "aliases": [
            "imperial",
            "ic",
            "imperial college"
        ],
        "website": {
            "url": null,
            "label": null,
            "platform": null,
            "verified": false
        },
        "portal": {
            "url": "https://centsso.ad.ic.ac.uk/sso/pages/home.jsp",
            "label": "Imperial SSO (My Imperial gateway)",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": null,
            "label": null,
            "platform": "Blackboard",
            "verified": false
        },
        "registry": {
            "url": null,
            "label": "My Imperial (enrolment, records)",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "University College London",
        "country": "UK",
        "city": "London",
        "aliases": [
            "ucl",
            "university college london"
        ],
        "website": {
            "url": "https://www.ucl.ac.uk/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": null,
            "label": "Portico (student records & module selection)",
            "platform": null,
            "verified": false
        },
        "lms": {
            "url": "https://moodle.ucl.ac.uk/",
            "label": null,
            "platform": "Moodle",
            "verified": true
        },
        "registry": {
            "url": null,
            "label": "Portico / Module List",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "University of Edinburgh",
        "country": "UK",
        "city": "Edinburgh",
        "aliases": [
            "edinburgh",
            "uoe"
        ],
        "website": {
            "url": "https://www.ed.ac.uk/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://www.myed.ed.ac.uk/",
            "label": "MyEd Portal",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": "https://www.learn.ed.ac.uk/",
            "label": null,
            "platform": "Blackboard",
            "verified": true
        },
        "registry": {
            "url": null,
            "label": "Ask-sis / PGR system",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "University of Manchester",
        "country": "UK",
        "city": "Manchester",
        "aliases": [
            "manchester",
            "uom"
        ],
        "website": {
            "url": "https://www.manchester.ac.uk/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://my.manchester.ac.uk/",
            "label": "My Manchester Portal",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": "https://canvas.manchester.ac.uk/",
            "label": null,
            "platform": "Canvas",
            "verified": true
        },
        "registry": {
            "url": null,
            "label": "Ambisis / Student Records",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "University of Toronto",
        "country": "Canada",
        "city": "Toronto, ON",
        "aliases": [
            "uoft",
            "toronto",
            "ut"
        ],
        "website": {
            "url": null,
            "label": null,
            "platform": null,
            "verified": false
        },
        "portal": {
            "url": "https://acorn.utoronto.ca/",
            "label": "ACORN",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": "https://q.utoronto.ca/",
            "label": null,
            "platform": "Canvas",
            "verified": true
        },
        "registry": {
            "url": "https://acorn.utoronto.ca/",
            "label": "Enrolment, Fees & Grades (ACORN)",
            "platform": null,
            "verified": true
        }
    },
    {
        "name": "University of British Columbia",
        "country": "Canada",
        "city": "Vancouver, BC",
        "aliases": [
            "ubc",
            "british columbia"
        ],
        "website": {
            "url": null,
            "label": null,
            "platform": null,
            "verified": false
        },
        "portal": {
            "url": "https://account.you.ubc.ca/s/login",
            "label": "UBC Student / Admissions Account",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": "https://canvas.ubc.ca/",
            "label": null,
            "platform": "Canvas",
            "verified": true
        },
        "registry": {
            "url": null,
            "label": "SSR (Student Service Centre)",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "McGill University",
        "country": "Canada",
        "city": "Montreal, QC",
        "aliases": [
            "mcgill"
        ],
        "website": {
            "url": "https://www.mcgill.ca/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://www.mcgill.ca/minerva-students/login/",
            "label": "Minerva (via myMcGill)",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": null,
            "label": null,
            "platform": "Brightspace",
            "verified": false
        },
        "registry": {
            "url": null,
            "label": "Minerva registration & records",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "University of Waterloo",
        "country": "Canada",
        "city": "Waterloo, ON",
        "aliases": [
            "waterloo",
            "uw"
        ],
        "website": {
            "url": null,
            "label": null,
            "platform": null,
            "verified": false
        },
        "portal": {
            "url": "https://portal.uwaterloo.ca/",
            "label": "UWaterloo Portal",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": "https://learn.uwaterloo.ca/",
            "label": null,
            "platform": "Moodle",
            "verified": true
        },
        "registry": {
            "url": null,
            "label": "Quest (registration & records)",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "The University of Melbourne",
        "country": "Australia",
        "city": "Melbourne, VIC",
        "aliases": [
            "unimelb",
            "melbourne"
        ],
        "website": {
            "url": "https://www.unimelb.edu.au/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://students.unimelb.edu.au/",
            "label": "Student Portal",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": "https://lms.unimelb.edu.au/canvas",
            "label": null,
            "platform": "Canvas",
            "verified": true
        },
        "registry": {
            "url": null,
            "label": "Manage my course / Handbook",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "UNSW Sydney",
        "country": "Australia",
        "city": "Sydney, NSW",
        "aliases": [
            "unsw",
            "new south wales"
        ],
        "website": {
            "url": "https://www.unsw.edu.au/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://my.unsw.edu.au/",
            "label": "myUNSW",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": "https://moodle.telt.unsw.edu.au/",
            "label": null,
            "platform": "Moodle",
            "verified": true
        },
        "registry": {
            "url": null,
            "label": "Enrolment & MyTools (myUNSW)",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "The University of Sydney",
        "country": "Australia",
        "city": "Sydney, NSW",
        "aliases": [
            "usyd",
            "sydney uni"
        ],
        "website": {
            "url": "https://www.sydney.edu.au/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": null,
            "label": "Sydney Student (UniKey SSO)",
            "platform": null,
            "verified": false
        },
        "lms": {
            "url": "https://canvas.sydney.edu.au/",
            "label": null,
            "platform": "Canvas",
            "verified": true
        },
        "registry": {
            "url": null,
            "label": "Sydney Student: enrolment, results, fees",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "Monash University",
        "country": "Australia",
        "city": "Melbourne, VIC",
        "aliases": [
            "monash"
        ],
        "website": {
            "url": "https://www.monash.edu/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://home.student.monash/",
            "label": "Monash Student Portal",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": null,
            "label": null,
            "platform": "Moodle",
            "verified": false
        },
        "registry": {
            "url": "https://my.monash.edu.au/wes/",
            "label": "Web Enrolment System (WES)",
            "platform": null,
            "verified": true
        }
    },
    {
        "name": "Tsinghua University",
        "country": "China",
        "city": "Beijing",
        "aliases": [
            "tsinghua",
            "thu"
        ],
        "website": {
            "url": "https://www.tsinghua.edu.cn/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://portal.sc.tsinghua.edu.cn/",
            "label": "Unified Identity Portal",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": "https://learn.tsinghua.edu.cn/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "registry": {
            "url": null,
            "label": "教务处 Course Registration (JWGL)",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "Peking University",
        "country": "China",
        "city": "Beijing",
        "aliases": [
            "pku",
            "peking"
        ],
        "website": {
            "url": "https://www.pku.edu.cn/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://portal.pku.edu.cn/",
            "label": "Unified Authentication System",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": null,
            "label": null,
            "platform": null,
            "verified": false
        },
        "registry": {
            "url": null,
            "label": "教务部 / 学生网选课程",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "Zhejiang University",
        "country": "China",
        "city": "Hangzhou",
        "aliases": [
            "zju",
            "zhejiang"
        ],
        "website": {
            "url": null,
            "label": null,
            "platform": null,
            "verified": false
        },
        "portal": {
            "url": "https://intlstudent.zju.edu.cn/",
            "label": "International Student Management System",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": null,
            "label": null,
            "platform": null,
            "verified": false
        },
        "registry": {
            "url": "https://zjuam.zju.edu.cn/cas/login?locale=en",
            "label": "Unified Identity Authentication (ZJUAM)",
            "platform": null,
            "verified": true
        }
    },
    {
        "name": "The University of Tokyo",
        "country": "Japan",
        "city": "Tokyo",
        "aliases": [
            "utokyo",
            "tokyo university",
            "todai"
        ],
        "website": {
            "url": null,
            "label": null,
            "platform": null,
            "verified": false
        },
        "portal": {
            "url": null,
            "label": "UTAS (Academic Affairs System)",
            "platform": null,
            "verified": false
        },
        "lms": {
            "url": "https://utol.ecc.u-tokyo.ac.jp/",
            "label": null,
            "platform": "LMS",
            "verified": true
        },
        "registry": {
            "url": null,
            "label": "UTAS course registration & grades",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "Kyoto University",
        "country": "Japan",
        "city": "Kyoto",
        "aliases": [
            "kyoto uni",
            "kudai"
        ],
        "website": {
            "url": null,
            "label": null,
            "platform": null,
            "verified": false
        },
        "portal": {
            "url": "https://student.iimc.kyoto-u.ac.jp/",
            "label": "Common Portal for All Students",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": null,
            "label": null,
            "platform": null,
            "verified": false
        },
        "registry": {
            "url": null,
            "label": "KUBoS / Academic Affairs",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "Waseda University",
        "country": "Japan",
        "city": "Tokyo",
        "aliases": [
            "waseda"
        ],
        "website": {
            "url": "https://www.waseda.jp/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://my.waseda.jp/",
            "label": "MyWaseda Portal",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": null,
            "label": null,
            "platform": "Moodle",
            "verified": false
        },
        "registry": {
            "url": null,
            "label": "Grades & course registration (MyWaseda)",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "Indian Institute of Technology Bombay",
        "country": "India",
        "city": "Mumbai",
        "aliases": [
            "iitb",
            "iit bombay"
        ],
        "website": {
            "url": null,
            "label": null,
            "platform": null,
            "verified": false
        },
        "portal": {
            "url": "https://asc.iitb.ac.in/",
            "label": "ASC SSO / Academic Scheduling & Course Registration",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": "https://moodle.iitb.ac.in/",
            "label": null,
            "platform": "Moodle",
            "verified": true
        },
        "registry": {
            "url": null,
            "label": "Academic Section / ERP",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "Indian Institute of Technology Kharagpur",
        "country": "India",
        "city": "Kharagpur",
        "aliases": [
            "iitkgp",
            "iit kharagpur",
            "kgp"
        ],
        "website": {
            "url": "https://www.iitkgp.ac.in/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://erp.iitkgp.ac.in/",
            "label": "ERP Student Portal",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": null,
            "label": null,
            "platform": null,
            "verified": false
        },
        "registry": {
            "url": null,
            "label": "ERP Registration & Grades",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "Anna University",
        "country": "India",
        "city": "Chennai",
        "aliases": [
            "anna university",
            "au"
        ],
        "website": {
            "url": null,
            "label": null,
            "platform": null,
            "verified": false
        },
        "portal": {
            "url": "https://onlineservices.annauniv.edu/pages/login.php",
            "label": "SOS Student Online Services",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": null,
            "label": null,
            "platform": null,
            "verified": false
        },
        "registry": {
            "url": null,
            "label": "COE Results / Regulation & Counselling",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "University of Delhi",
        "country": "India",
        "city": "Delhi",
        "aliases": [
            "du",
            "delhi university"
        ],
        "website": {
            "url": "https://www.du.ac.in/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://slc.uod.ac.in/",
            "label": "DU Student Portal (Samarth)",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": null,
            "label": null,
            "platform": null,
            "verified": false
        },
        "registry": {
            "url": null,
            "label": "Exam Registration / Results",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "Technical University of Munich",
        "country": "Germany",
        "city": "Munich",
        "aliases": [
            "tum",
            "tu munchen",
            "munich tech"
        ],
        "website": {
            "url": "https://www.tum.de/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://portal.mytum.de/",
            "label": "MyTUM Portal",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": "https://www.moodle.tum.de/",
            "label": null,
            "platform": "Moodle",
            "verified": true
        },
        "registry": {
            "url": "https://campus.tum.de/tumonline",
            "label": "TUMonline (enrolment, grades)",
            "platform": null,
            "verified": true
        }
    },
    {
        "name": "RWTH Aachen University",
        "country": "Germany",
        "city": "Aachen",
        "aliases": [
            "rwth",
            "rwth aachen",
            "aachen"
        ],
        "website": {
            "url": "https://www.rwth-aachen.de/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://www.rwthonline.de/",
            "label": "RWTHonline",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": "https://moodle.rwth-aachen.de/",
            "label": null,
            "platform": "Moodle",
            "verified": true
        },
        "registry": {
            "url": "https://www.rwthonline.de/",
            "label": "RWTHonline (course registration, results)",
            "platform": null,
            "verified": true
        }
    },
    {
        "name": "Sorbonne University",
        "country": "France",
        "city": "Paris",
        "aliases": [
            "sorbonne",
            "su paris"
        ],
        "website": {
            "url": "https://www.sorbonne-universite.fr/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://www.sorbonne-universite.fr/su-bo/login",
            "label": "Espace étudiant (SU-BO)",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": null,
            "label": null,
            "platform": "Moodle",
            "verified": false
        },
        "registry": {
            "url": null,
            "label": "Scolarité / ARES inscription",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "Université PSL",
        "country": "France",
        "city": "Paris",
        "aliases": [
            "psl",
            "paris sciences et lettres"
        ],
        "website": {
            "url": "https://psl.eu/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": null,
            "label": "ENT étudiant",
            "platform": null,
            "verified": false
        },
        "lms": {
            "url": "https://moodle.psl.eu/",
            "label": null,
            "platform": "Moodle",
            "verified": true
        },
        "registry": {
            "url": null,
            "label": "Scolarité",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "Universidade de São Paulo",
        "country": "Brazil",
        "city": "São Paulo",
        "aliases": [
            "usp",
            "sao paulo university"
        ],
        "website": {
            "url": null,
            "label": null,
            "platform": null,
            "verified": false
        },
        "portal": {
            "url": "https://uspdigital.usp.br/janus",
            "label": "Janus (graduação)",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": "https://edisciplinas.usp.br/acessar/",
            "label": null,
            "platform": "Moodle",
            "verified": true
        },
        "registry": {
            "url": "https://uspdigital.usp.br/",
            "label": "Sistemas USP / JúpiterWeb",
            "platform": null,
            "verified": true
        }
    },
    {
        "name": "Universidade Federal do Rio de Janeiro",
        "country": "Brazil",
        "city": "Rio de Janeiro",
        "aliases": [
            "ufrj",
            "rio federal"
        ],
        "website": {
            "url": "https://ufrj.br/",
            "label": null,
            "platform": null,
            "verified": true
        },
        "portal": {
            "url": "https://portal.ufrj.br/",
            "label": "Portal UFRJ (central login)",
            "platform": null,
            "verified": true
        },
        "lms": {
            "url": null,
            "label": null,
            "platform": null,
            "verified": false
        },
        "registry": {
            "url": null,
            "label": "SIGA (academic records)",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "National University of Singapore",
        "country": "Singapore",
        "city": "Singapore",
        "aliases": [
            "nus"
        ],
        "website": {
            "url": null,
            "label": null,
            "platform": null,
            "verified": false
        },
        "portal": {
            "url": null,
            "label": "NUS Portal (NUSVLE / edUUm)",
            "platform": null,
            "verified": false
        },
        "lms": {
            "url": "https://canvas.nus.edu.sg/",
            "label": null,
            "platform": "Canvas",
            "verified": true
        },
        "registry": {
            "url": null,
            "label": "ACADUS (modreg, exams)",
            "platform": null,
            "verified": false
        }
    },
    {
        "name": "Delft University of Technology",
        "country": "Netherlands",
        "city": "Delft",
        "aliases": [
            "tudelft",
            "delft"
        ],
        "website": {
            "url": null,
            "label": null,
            "platform": null,
            "verified": false
        },
        "portal": {
            "url": null,
            "label": "myTU Delft",
            "platform": null,
            "verified": false
        },
        "lms": {
            "url": "https://brightspace.tudelft.nl/",
            "label": null,
            "platform": "Brightspace",
            "verified": true
        },
        "registry": {
            "url": null,
            "label": "TU10 (study programme & results)",
            "platform": null,
            "verified": false
        }
    }
];
