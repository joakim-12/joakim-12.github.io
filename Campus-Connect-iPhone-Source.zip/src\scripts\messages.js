import "../lib/compat.js";
import "../lib/native-feel.js";
import { warmMedia } from "../lib/media-warm.js";
import { resolveCampusMediaUrl } from "../lib/media.js";
import { playMessageTone } from "../lib/message-tone.js";
import { openInPhonePlayer } from "../lib/open-media.js";
import { createChatActivity, activityText } from "../lib/chat-activity.js";
import { createCallManager } from "./calls.js";
import { EMOJI_GROUPS } from "./emojis.js";
import { createMessageMarks } from "../lib/message-marks.js";
import { clearUserChatFlags, createChatOrganize } from "../lib/chat-organize.js";
import {
    PRESETS,
    applyChatTheme,
    buildThemeVars,
    clearChatTheme,
    clearUserChatTheme,
    readGlobalTheme,
    themeIdFor,
    writeGlobalTheme
} from "../lib/chat-theme.js";
import { createChatLock } from "../lib/chat-lock.js";
import { showSetupCard } from "../lib/db-setup.js";
import { ensureStaffAccess } from "../lib/staff-verification.js";
import {
    createVoicePlayer,
    isImageUrl,
    isVideoUrl,
    isVoiceUrl,
    onAudioOnlyVideo,
    onMediaFailure,
    onMediaStall,
    paintFirstFrame,
    replaceWithVoicePlayer,
    stopVoicePlayback
} from "../lib/voice-player.js";
import { installVitePreloadRecovery } from "../lib/vite-preload-recovery.js";
import { initializeLanguageSelector, translate } from "../lib/language.js";
import { initializeAppInstallation, initializeAppSharing, copyLink } from "../lib/pwa.js";
import { confirmContentWarning } from "../lib/content-warning.js";
import { sendMembersToBulletin } from "../lib/member-view.js";
import { initializeSettingsMenus } from "../lib/settings-menu.js";
import { initializeTheme, toggleThemeMode } from "../lib/theme.js";
import { initializeAppLock } from "../lib/app-lock.js";
import { mirrorClass } from "../lib/layout-fallback.js";
import { askNotificationPermission, clearMessageAlerts, dismissMessageAlert, notifyIncomingMessage, watchNotificationChatTap } from "../lib/notify.js";
import { announcePush, forgetPush, registerPush } from "../lib/push.js";
import {
    savePending,
    listPending,
    clearPending,
    bumpAttempts
} from "../lib/message-outbox.js";
import {
    applyCallWatchFix,
    callWatchClearMissed,
    callWatchLaunchTarget,
    callWatchMissedCalls,
    callWatchRow,
    markCallWatchPush,
    readCallWatchCrash,
    readCallWatchState,
    setMessageBadge,
    startCallWatch,
    stopCallWatch,
} from "../lib/call-watch.js";
import {
    appendRoleBadge,
    memberDisplayName,
    noteMissingRoleColumn,
    roleColumn,
    setMemberAvatar
} from "../lib/profile-identity.js";
import {
    buildInviteUrl,
    clearInviteParams,
    readInviteParams,
    renderInviteQr,
    shareMyInvite
} from "../lib/invite.js";
import {
    cacheChatDirectory,
    cacheConversationMessages,
    clearUserChatCache,
    getCachedChatDirectory,
    getCachedConversationMessages
} from "../lib/offline-chat.js";
import { grantRecordingAudio, stopWarmStream } from "../lib/media-grant.js";
import { permissionHint } from "../lib/media-hint.js";
import { canonicalPhone, samePhone } from "../lib/phone-account.js";
import {
    forgetOfflineUser,
    resolveBootUser
} from "../lib/offline-session.js";
import { clearUserSnapshots } from "../lib/offline-store.js";
import { setOfflineBanner } from "../lib/offline-banner.js";
import {
    MAX_GROUP_MEMBERS,
    addGroupMembers,
    createGroup,
    isMissingGroupObjects,
    loadGroupMembers,
    loadGroups,
    markGroupRead
} from "../lib/groups.js";
import {
    callEntriesForPeer,
    clearCallLog,
    dueScheduledCalls,
    groupCallEntries,
    loadCallEntries,
    loadScheduledCalls,
    mergeNativeMisses,
    addScheduledCall,
    removeScheduledCall
} from "../lib/call-log.js";

const clearPreloadRetry = installVitePreloadRecovery();
initializeLanguageSelector();
initializeAppInstallation();
initializeAppSharing();
initializeSettingsMenus();
/* A browser that cannot read :has() would otherwise leave the bottom navigation
   lying across an open chat, so the class that opens one is copied onto <body>
   for the plain selector to find. Nothing happens on a browser that can read it. */
mirrorClass(document.getElementById("messaging"), document.body, "chat-open");

const elements = {
    messaging: document.getElementById("messaging"),
    search: document.getElementById("conversation-search"),
    conversationList: document.getElementById("conversation-list"),
    communityPanel: document.getElementById("communities-panel"),
    communitiesList: document.getElementById("communities-list"),
    communityForm: document.getElementById("community-form"),
    communityNotice: document.getElementById("community-notice"),
    chatFilters: document.getElementById("chat-filters"),
    chatMessages: document.getElementById("chat-messages"),
    chatName: document.getElementById("chat-name"),
    chatAvatar: document.getElementById("chat-avatar"),
    chatStatus: document.getElementById("chat-status"),
    messageForm: document.getElementById("message-form"),
    messageInput: document.getElementById("message-input"),
    sendButton: document.getElementById("send-button"),
    mediaInput: document.getElementById("message-media"),
    callActions: document.getElementById("call-actions"),
    notice: document.getElementById("message-notice"),
    themeToggle: document.getElementById("theme-toggle")
};

const callsSearch = document.getElementById("calls-search");
const callsGenderSearch = document.getElementById("calls-gender-search");
const genderSearch = document.getElementById("gender-search");
const callDirectory = document.getElementById("call-directory");
const callsNotice = document.getElementById("calls-notice");
const callHistory = document.getElementById("call-history");
const callsPicker = document.getElementById("calls-picker");
const callsAddButton = document.getElementById("calls-add-button");
const callsMenuButton = document.getElementById("calls-menu-button");
const callsMenuDialog = document.getElementById("calls-menu-dialog");
const callWatchButton = document.getElementById("call-watch-button");
const callCrashLine = document.getElementById("call-crash-line");
const clearCallHistoryButton = document.getElementById("clear-call-history-button");
const keypadDialog = document.getElementById("keypad-dialog");
const dialDisplay = document.getElementById("dial-display");
const dialPad = document.getElementById("dial-pad");
const dialCallLink = document.getElementById("dial-call-button");
const dialFindButton = document.getElementById("dial-find-button");
const dialResult = document.getElementById("dial-result");
const scheduleCallDialog = document.getElementById("schedule-call-dialog");
const scheduleCallContact = document.getElementById("schedule-call-contact");
const scheduleCallTime = document.getElementById("schedule-call-time");
const scheduleCallSaveButton = document.getElementById("schedule-call-save");
const scheduleCallCancelButton = document.getElementById("schedule-call-cancel");
const newChatDialog = document.getElementById("new-chat-dialog");
const newChatSearch = document.getElementById("new-chat-search");
const newChatBody = document.getElementById("new-chat-body");
const newChatResult = document.getElementById("new-chat-result");
const newChatCloseButton = document.getElementById("new-chat-close");
const newChatGroupButton = document.getElementById("new-chat-group");
const newChatContactButton = document.getElementById("new-chat-contact");
const chatGroupButton = document.getElementById("chat-group-button");
const groupCreateDialog = document.getElementById("group-create-dialog");
const groupCreateDialogTitle = document.getElementById("group-create-title");
const groupCreateCloseButton = document.getElementById("group-create-close");
const groupCreateCancelButton = document.getElementById("group-create-cancel");
const groupCreateSaveButton = document.getElementById("group-create-save");
const groupNameField = document.getElementById("group-name-field");
const groupMemberSearch = document.getElementById("group-member-search");
const groupPickedLine = document.getElementById("group-picked");
const groupMemberBody = document.getElementById("group-member-body");
const groupInfoDialog = document.getElementById("group-info-dialog");
const groupInfoCloseButton = document.getElementById("group-info-close");
const groupInfoName = document.getElementById("group-info-name");
const groupInfoCount = document.getElementById("group-info-count");
const groupInfoAdmin = document.getElementById("group-info-admin");
const groupInfoNameField = document.getElementById("group-info-name-field");
const groupInfoRenameButton = document.getElementById("group-info-rename");
const groupInfoAddButton = document.getElementById("group-info-add");
const groupInfoMembers = document.getElementById("group-info-members");
const groupInfoLeaveButton = document.getElementById("group-info-leave");
const groupInfoDeleteButton = document.getElementById("group-info-delete");
const groupInfoNotice = document.getElementById("group-info-notice");
const memberProfileDialog = document.getElementById("member-profile-dialog");
const memberProfileAvatar = document.getElementById("member-profile-avatar");
const startRecordingButton = document.getElementById("start-voice-recording");
const sendVoiceButton = document.getElementById("send-voice-message");
const discardVoiceButton = document.getElementById("discard-voice-message");
const voiceRecorder = document.getElementById("voice-recorder");
const recTimer = document.getElementById("rec-timer");
const recWave = document.getElementById("rec-wave");
const recPlay = document.getElementById("rec-play");
const attachButton = document.getElementById("attach-button");
const attachMenu = document.getElementById("attach-menu");
const emojiToggle = document.getElementById("emoji-toggle");
const emojiPicker = document.getElementById("emoji-picker");
const cameraShortcut = document.getElementById("camera-shortcut");
const blockedMembersList = document.getElementById("blocked-members-list");
const blockChatMemberButton = document.getElementById("block-chat-member");
const messageMemberProfileButton = document.getElementById("message-member-profile");
const invitePanel = document.getElementById("invite-panel");
const inviteHandle = document.getElementById("invite-handle");
const inviteLinkOutput = document.getElementById("invite-link");
const inviteQrContainer = document.getElementById("invite-qr");
const copyInviteLinkButton = document.getElementById("copy-invite-link");
const shareInviteLinkButton = document.getElementById("share-invite-link");
const chatFilterButtons = [...document.querySelectorAll("[data-chat-filter]")];
const chatHeading = document.querySelector(".conversation-heading");
const chatOptionsButton = document.getElementById("chat-options-button");
const chatCameraButton = document.getElementById("chat-camera-button");
const chatNewButton = document.getElementById("chat-new-button");
const renameContactButton = document.getElementById("rename-contact-button");
const contactNameDialog = document.getElementById("contact-name-dialog");
const contactNameInput = document.getElementById("contact-name-input");
const saveContactNameButton = document.getElementById("save-contact-name-button");
const clearContactNameButton = document.getElementById("clear-contact-name-button");
const cancelContactNameButton = document.getElementById("cancel-contact-name-button");
const messageActionDialog = document.getElementById("message-action-dialog");
const editMessageButton = document.getElementById("edit-message-button");
const deleteMessageMeButton = document.getElementById("delete-message-me-button");
const deleteMessageAllButton = document.getElementById("delete-message-all-button");
const messageActionHint = document.getElementById("message-action-hint");
const closeMessageActionButton = document.getElementById("close-message-action-button");
const navChatsBadge = document.getElementById("nav-chats-badge");
let unreadAlertsPending = false;
const navProfilePhoto = document.getElementById("nav-profile-photo");
const REFRESH_INTERVAL_MS = 60000;
const MESSAGE_POLL_INTERVAL_MS = 20000;
const MESSAGES_PER_PAGE = 100;
const UNREAD_COUNT_LIMIT = 2000;
const MESSAGE_BASE_SELECT = "id, sender_id, receiver_id, content, media_url, created_at, is_read";
const MESSAGE_ACTION_SELECT = `${MESSAGE_BASE_SELECT}, edited_at, deleted_for_everyone, deleted_by`;
const MESSAGE_RICH_SELECT = `${MESSAGE_ACTION_SELECT}, reply_to, reply_preview`;
const MESSAGE_EDIT_WINDOW_MS = 20 * 60 * 1000;
const MESSAGE_RECALL_WINDOW_MS = 15 * 60 * 1000;
/* Supabase never gives up on a request stuck to a dead campus network, so the
   send button used to stay disabled for minutes. This is how long a send may go
   without reporting any progress at all before we call it undelivered. */
const SEND_IDLE_TIMEOUT_MS = 20000;
const PROFILE_REFRESH_INTERVAL_MS = 60000;
let supabase;
let currentUser;
let appLock;
let uploadCampusMedia;
const signedChatMediaUrls = new Map();
const pendingChatMediaUrls = new Map();
const CHAT_MEDIA_LINK_SECONDS = 15 * 60;
let validateCampusMedia;
let prepareImageForUpload;
let prepareVideoForUpload;
let students = [];
let allStudents = [];
let myStaffRole = false;
let followingStudentIds = new Set();
let followerStudentIds = new Set();
let blockedStudentIds = new Set();
const contactNames = new Map();
let lastSeenByStudent = new Map();
let socialAccessMigrationReady = false;
let presenceWarningShown = false;
let communities = [];
let communityMemberships = new Set();
let myGroups = [];
let groupsAvailable = true;
let groupMemberCache = [];
let groupPickerMode = "create";
let groupPickerTarget = null;
const groupPickedIds = new Set();
let latestByStudent = new Map();
let activeStudent = null;
let activeCommunity = null;
let chatActivity = null;
let peerActivity = "";
let memberProfileStudent = null;
let activeChatFilter = "all";
let favoriteStudentIds = new Set();
let favoriteStorageKey = "";
let pendingChatInviteIds = new Set();
let pendingChatInviteStorageKey = "";
let displayedMessages = [];
/* Messages this device tried and failed to hand to the server. They stay on
   screen as tappable "not delivered" bubbles instead of disappearing, and the
   entry keeps the draft plus any already-uploaded attachment alive. */
const failedSends = new Map();
let hasOlderMessages = false;let isLoadingOlderMessages = false;
let olderMessagesRequestId = 0;
let refreshTimer;
let messagesPollTimer;
let isRefreshing = false;
let lastProfilesRefreshAt = 0;
let messagesChannel;
let messagesRealtimeConnected = false;
let conversationLoadId = 0;
let chatActionsAvailable = true;
let replyColumnsAvailable = true;
let actionMessage = null;
let contextMessage = null;
let pendingReply = null;
let inlineEditMessage = null;
const forwardTargets = new Set();
let callManager;
let searchRequestId = 0;
let searchDebounceTimer;
let mediaRecorder;
let recordingStream;
let recordingChunks = [];
let recordedVoiceFile;
let recordingTimer;
let recordingStartedAt;
let recorderAnalyser;
let recorderContext;
let recorderRaf;
let voicePreviewAudio;
let voicePreviewUrl;
let voiceRecorderMode = "hidden";
const RECORDER_BAR_COUNT = 40;
const MAX_RECORDING_MS = 10 * 60 * 1000;

function applyAccessMode() {
    elements.mediaInput.disabled = elements.messageInput.disabled;
    attachButton.disabled = elements.messageInput.disabled;
    emojiToggle.disabled = elements.messageInput.disabled;
    cameraShortcut.disabled = elements.mediaInput.disabled;
    chatCameraButton.disabled = elements.messageInput.disabled;
    chatNewButton.disabled = !currentUser;
    chatOptionsButton.disabled = elements.messageInput.disabled;
    startRecordingButton.disabled = !currentUser ||
        (!activeStudent && (!activeCommunity ||
            (activeCommunity.kind === "channel" && activeCommunity.owner_id !== currentUser.id)));
    syncComposer();
    elements.callActions.classList.toggle("hidden", !activeStudent);
    elements.communityForm.querySelector('button[type="submit"]').disabled = !currentUser;
    blockChatMemberButton.hidden = !activeStudent;
    blockChatMemberButton.textContent = translate(
        activeStudent && blockedStudentIds.has(activeStudent.id) ? "Unblock" : "Block"
    );
}

const PROFILE_BASE_COLUMNS = "id, username, full_name, gender, course, bio, avatar_url, contact_email, contact_phone, share_email, share_phone, is_discoverable";

function profileColumns() {
    return PROFILE_BASE_COLUMNS + roleColumn();
}

// Lecturers are only findable through search by other lecturers and admins.
// Students, followers and existing chats stay visible to everyone.
function hiddenByRolePrivacy(profile) {
    if (myStaffRole || profile.role !== "lecturer") return false;
    return !latestByStudent.has(profile.id) &&
        !followerStudentIds.has(profile.id) &&
        !followingStudentIds.has(profile.id);
}

async function loadMyStaffRole() {
    if (!currentUser) return;
    const run = columns => supabase
        .from("profiles")
        .select(columns)
        .eq("id", currentUser.id)
        .maybeSingle();
    let { data, error } = await run(profileColumns());
    if (error && noteMissingRoleColumn(error)) {
        ({ data } = await run(PROFILE_BASE_COLUMNS));
    }
    const role = data?.role || "student";
    myStaffRole = role === "lecturer" || role === "admin";
}

function isMissingMigrationObject(error) {
    return error?.code === "42P01" ||
        error?.code === "42883" ||
        error?.code === "42703" ||
        error?.code === "PGRST202" ||
        error?.code === "PGRST204" ||
        error?.code === "PGRST205";
}

// Message reads go through here so a database that has not run the
// edit/delete/reply migrations yet keeps working on fewer columns.
function messageSelectColumns() {
    return replyColumnsAvailable ? MESSAGE_RICH_SELECT
        : chatActionsAvailable ? MESSAGE_ACTION_SELECT : MESSAGE_BASE_SELECT;
}

async function selectMessages(configure) {
    let columns = messageSelectColumns();
    let result = await configure(columns);
    while (result.error && isMissingMigrationObject(result.error) && columns !== MESSAGE_BASE_SELECT) {
        if (columns === MESSAGE_RICH_SELECT) {
            replyColumnsAvailable = false;
            columns = MESSAGE_ACTION_SELECT;
        } else {
            chatActionsAvailable = false;
            columns = MESSAGE_BASE_SELECT;
        }
        result = await configure(columns);
    }
    return result;
}

function visibleForMe(messages, peerId) {
    if (!currentUser) return messages;
    /* "Clear chat" never destroys the other person's copy: the moment the chat
       was cleared is remembered and everything older simply stops showing. */
    const clearedAt = peerId ? Date.parse(chatOrganize.flagsFor(peerId).clearedAt) : NaN;
    return messages.filter(message =>
        !(message.deleted_by || []).includes(currentUser.id) &&
        (!Number.isFinite(clearedAt) || new Date(message.created_at).getTime() > clearedAt));
}

function reportPartialLoadFailure(label, error) {
    if (!error) return;
    console.error(`Could not load ${label}:`, error);
    if (isMissingMigrationObject(error)) {
        showMigrationWarning();
        return;
    }
    showNotice(`Could not load ${label}: ${error.message}`, true);
}

// A broken panel must never take the whole Chats page down with it.
async function runUiStep(label, step) {
    try {
        await step();
    } catch (error) {
        console.error(`Could not render ${label}:`, error);
        showNotice(`Could not render ${label}: ${error.message || error}`, true);
    }
}

function showMigrationWarning() {
    if (presenceWarningShown) return;
    presenceWarningShown = true;
    showSetupCard({
        target: "#conversation-list",
        position: "before",
        reason: translate("Chats work, but online status, blocking and saved contact names still need one database update.")
    });
}

async function updateLastSeen() {
    if (!currentUser || document.visibilityState !== "visible") return;
    const { error } = await supabase.rpc("update_last_seen");
    if (!error) return;
    console.error("Could not update online status:", error);
    if (isMissingMigrationObject(error)) {
        showMigrationWarning();
        return;
    }
    showNotice(`Could not update online status: ${error.message}`, true);
}

function showNotice(message, isError = false) {
    elements.notice.textContent = message;
    elements.notice.classList.toggle("error", isError);
    callsNotice.textContent = message;
    callsNotice.classList.toggle("error", isError);
}

function persistPendingChatInvites() {
    if (!pendingChatInviteStorageKey) return;
    try {
        localStorage.setItem(
            pendingChatInviteStorageKey,
            JSON.stringify([...pendingChatInviteIds])
        );
    } catch (error) {
        console.error("Could not save pending chat invitations:", error);
        showNotice(`Could not save pending chat invitations: ${error.message}`, true);
    }
}

function setAvatarContent(container, profile) {
    setMemberAvatar(container, profile);
}

function studentName(student) {
    return contactNames.get(student?.id) || memberDisplayName(student);
}

function openMemberProfile(student) {
    memberProfileStudent = student;
    setAvatarContent(memberProfileAvatar, student);
    const profileName = document.getElementById("member-profile-name");
    profileName.textContent = studentName(student);
    appendRoleBadge(profileName, student);
    document.getElementById("member-profile-username").textContent = "";
    document.getElementById("member-profile-course").textContent = student.course || "";
    document.getElementById("member-profile-bio").textContent = student.bio || "";
    const sharedContacts = [
        student.share_email && student.contact_email ? student.contact_email : "",
        student.share_phone && student.contact_phone ? student.contact_phone : ""
    ].filter(Boolean);
    document.getElementById("member-profile-contact").textContent = sharedContacts.join(" · ");
    const isBlocked = blockedStudentIds.has(student.id);
    messageMemberProfileButton.disabled = isBlocked;
    messageMemberProfileButton.textContent = translate(
        isBlocked ? "Unblock this member first" : "Message"
    );
    memberProfileDialog.showModal();
}

function genderLabel(gender) {
    if (gender === "male") return translate("Male");
    if (gender === "female") return translate("Female");
    if (gender === "other") return translate("Other genders");
    return "";
}

function formatTime(value) {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "";

    return new Intl.DateTimeFormat(undefined, {
        hour: "numeric",
        minute: "2-digit"
    }).format(date);
}

function renderEmptyMessage(text, withLoginLink = false) {
    const empty = document.createElement("div");
    empty.className = "empty-state";
    empty.textContent = text;

    if (withLoginLink) {
        empty.append(" ");
        const link = document.createElement("a");
        link.href = "/";
        link.textContent = "Log in from the home page.";
        empty.appendChild(link);
    }

    elements.chatMessages.replaceChildren(empty);
}

/* v1.28: polls in chats, view-once media, and a double-tap heart on
   pictures. A poll is a normal message whose question is the content, with a
   companion row carrying the options; a view-once message carries a marker in
   its content so it still previews and notifies honestly. If the migrations
   have not been run yet, polls read as plain questions and view-once media
   stays visible — nothing breaks, the extras simply are not there. */
const VIEW_ONCE_MARK = "👻 View once\n";
const pollByMessage = new Map();   // message id -> { id, options, votes }
const viewOnceOpens = new Map();   // message id -> Set(viewer ids)
const pollCheckedDone = new Set(); // ids whose poll row was found or ruled out
const pollRetryAt = new Map();     // id -> when to look again (the companion row may still be flying)
let opensLastFetchAt = 0;
let votesLastFetchAt = 0;
let pendingViewOnce = false;

function isViewOnceMessage(message) {
    return Boolean(message && String(message.content || "").startsWith(VIEW_ONCE_MARK));
}

function viewOnceCaption(message) {
    return String(message.content || "").slice(VIEW_ONCE_MARK.length).trim();
}

function viewOnceOpenedFor(message) {
    const opens = viewOnceOpens.get(message.id);
    if (!opens || !opens.size || !currentUser) return false;
    if (message.sender_id === currentUser.id) return true;
    return opens.has(currentUser.id);
}

async function hydrateInteractive(messages) {
    if (!supabase || !currentUser) return;
    const now = Date.now();
    let changed = false;
    const wanted = messages.filter(message => {
        if (!message.id || String(message.id).startsWith("pending")) return false;
        if (pollByMessage.has(message.id) || pollCheckedDone.has(message.id)) return false;
        const retry = pollRetryAt.get(message.id);
        return retry === undefined || now >= retry;
    }).slice(-160);
    if (wanted.length) {
        const ids = wanted.map(message => message.id);
        const birth = new Map(wanted.map(message => [message.id, new Date(message.created_at || 0).getTime()]));
        try {
            const { data, error } = await supabase.from("polls")
                .select("id, message_id, options, poll_votes(user_id, option_index)")
                .in("message_id", ids);
            if (error) throw error;
            const found = new Set();
            for (const row of data || []) {
                found.add(row.message_id);
                pollByMessage.set(row.message_id, {
                    id: row.id,
                    options: Array.isArray(row.options) ? row.options : [],
                    votes: (row.poll_votes || []).map(vote => ({
                        userId: vote.user_id,
                        index: Number(vote.option_index)
                    }))
                });
                pollCheckedDone.add(row.message_id);
                changed = true;
            }
            for (const id of ids) {
                if (found.has(id) || pollCheckedDone.has(id)) continue;
                /* A poll message lands a heartbeat before its options row does,
                   so a very recent message is looked at again shortly. An older
                   one is simply not a poll. */
                if (now - (birth.get(id) || 0) < 5 * 60 * 1000) pollRetryAt.set(id, now + 10000);
                else pollCheckedDone.add(id);
            }
        } catch (error) {
            if (isMissingMigrationObject(error)) {
                // No polls table yet: questions stay plain text, quietly.
                for (const id of ids) pollCheckedDone.add(id);
            } else {
                for (const id of ids) pollRetryAt.set(id, now + 60000);
            }
            console.warn("Polls are not available on this database yet:", error.message);
        }
    }
    const ghosts = messages.filter(message =>
        message.id && !String(message.id).startsWith("pending") &&
        isViewOnceMessage(message) && message.media_url && !viewOnceOpenedFor(message));
    if (ghosts.length && now - opensLastFetchAt >= 20000) {
        opensLastFetchAt = now;
        try {
            const { data, error } = await supabase.from("view_once_opens")
                .select("message_id, viewer_id")
                .in("message_id", ghosts.slice(0, 160).map(message => message.id));
            if (error) throw error;
            for (const row of data || []) {
                const opens = viewOnceOpens.get(row.message_id) || new Set();
                if (!opens.has(row.viewer_id)) {
                    opens.add(row.viewer_id);
                    viewOnceOpens.set(row.message_id, opens);
                    changed = true;
                }
            }
        } catch (error) {
            console.warn("View-once records are not available yet:", error.message);
        }
    }
    const threadIds = new Set(messages.map(message => message.id));
    const livePolls = [];
    for (const [messageId, poll] of pollByMessage.entries()) {
        if (poll.id && threadIds.has(messageId) && !poll.pendingCreate) livePolls.push(poll);
    }
    if (livePolls.length && now - votesLastFetchAt >= 20000) {
        votesLastFetchAt = now;
        try {
            const { data, error } = await supabase.from("poll_votes")
                .select("poll_id, user_id, option_index")
                .in("poll_id", livePolls.slice(0, 40).map(poll => poll.id));
            if (error) throw error;
            const byPoll = new Map(livePolls.map(poll => [poll.id, []]));
            for (const row of data || []) {
                const list = byPoll.get(row.poll_id);
                if (list) list.push({ userId: row.user_id, index: Number(row.option_index) });
            }
            for (const poll of livePolls) {
                const votes = byPoll.get(poll.id) || [];
                if (JSON.stringify(votes) !== JSON.stringify(poll.votes)) {
                    poll.votes = votes;
                    changed = true;
                }
            }
        } catch (error) {
            console.warn("Could not refresh the votes:", error.message);
        }
    }
    if (changed) renderMessages(displayedMessages, false);
}

function buildPollCard(message) {
    const poll = pollByMessage.get(message.id);
    if (!poll || !poll.id || !poll.options.length) return null;
    const card = document.createElement("div");
    card.className = "poll-card";
    const counts = poll.options.map(() => 0);
    for (const vote of poll.votes) if (counts[vote.index] !== undefined) counts[vote.index] += 1;
    const total = poll.votes.length;
    const myVote = currentUser ? poll.votes.find(vote => vote.userId === currentUser.id) : null;
    poll.options.forEach((option, index) => {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "poll-option";
        if (myVote && myVote.index === index) button.classList.add("my-vote");
        const share = total ? Math.round((counts[index] / total) * 100) : 0;
        const bar = document.createElement("span");
        bar.className = "poll-bar";
        bar.style.width = `${share}%`;
        const label = document.createElement("span");
        label.className = "poll-label";
        label.textContent = `${option}  ·  ${counts[index]}`;
        button.append(bar, label);
        button.addEventListener("click", () => { void castVote(poll, index); });
        card.appendChild(button);
    });
    const tally = document.createElement("div");
    tally.className = "poll-total";
    tally.textContent = total ? `${total} ${translate("votes")}` : translate("No votes yet");
    card.appendChild(tally);
    return card;
}

async function castVote(poll, index) {
    if (!currentUser || !poll.id) return;
    const previous = poll.votes.find(vote => vote.userId === currentUser.id);
    const local = poll.votes.filter(vote => vote.userId !== currentUser.id);
    if (previous && previous.index === index) {
        // A second tap on the same choice retracts the vote, WhatsApp-style.
        try {
            const { error } = await supabase.from("poll_votes").delete()
                .eq("poll_id", poll.id)
                .eq("user_id", currentUser.id);
            if (error) throw error;
            poll.votes = local;
        } catch (error) {
            console.error("Could not retract the vote:", error.message);
            showNotice(translate("Your vote could not be saved."), true);
            return;
        }
    } else {
        try {
            const { error } = await supabase.from("poll_votes").upsert(
                { poll_id: poll.id, user_id: currentUser.id, option_index: index },
                { onConflict: "poll_id,user_id" }
            );
            if (error) throw error;
            poll.votes = [...local, { userId: currentUser.id, index }];
        } catch (error) {
            console.error("Could not save the vote:", error.message);
            showNotice(translate("Your vote could not be saved."), true);
            return;
        }
    }
    renderMessages(displayedMessages, false);
}

function likeReaction(message) {
    if (!message || message.pending || !message.id) return;
    if (messageMarks.myReaction(message.id)) return; // always bless, never unbless
    void messageMarks.toggleReaction(message.id, "❤️");
}

function buildViewOnceBubble(message) {
    const opened = viewOnceOpenedFor(message);
    const veil = document.createElement("button");
    veil.type = "button";
    veil.className = "view-once-veil";
    veil.textContent = opened ? `✓ ${translate("Opened")}` : `👻 ${translate("Tap to view")}`;
    if (opened) veil.disabled = true;
    else veil.addEventListener("click", () => openViewOnceMessage(message));
    return veil;
}

async function openViewOnceMessage(message) {
    const viewer = document.getElementById("viewOnceViewer");
    const stage = document.getElementById("viewOnceStage");
    if (!viewer || !stage) return;
    let mediaUrl = message.media_url;
    if (mediaUrl?.startsWith("private-media:")) {
        try {
            mediaUrl = await signedChatMediaUrl(mediaUrl);
        } catch (error) {
            console.warn("Could not open a private chat attachment:", error);
            showNotice(translate("This attachment could not be opened."), true);
            return;
        }
    }
    stage.replaceChildren(createMediaElement(mediaUrl) ||
        document.createTextNode(viewOnceCaption(message) || translate("This message has no picture or video")));
    viewer.addEventListener("close", () => {
        stage.replaceChildren();
        renderMessages(displayedMessages, false);
    }, { once: true });
    viewer.showModal();
    recordViewOnceOpen(message);
}

function recordViewOnceOpen(message) {
    if (!supabase || !currentUser || message.pending || !message.media_url) return;
    if (message.receiver_id !== currentUser.id) return; // only the recipient opens
    const opens = viewOnceOpens.get(message.id) || new Set();
    if (opens.has(currentUser.id)) return;
    opens.add(currentUser.id);
    viewOnceOpens.set(message.id, opens);
    supabase.from("view_once_opens")
        .insert({ message_id: message.id, viewer_id: currentUser.id })
        .then(() => undefined, error => {
            console.warn("Could not record the view-once open:", error.message);
        });
}

function openViewOncePicker() {
    closeAttachMenu();
    if (activeCommunity || !activeStudent) {
        showNotice(translate("View-once media works in one-to-one chats for now."), true);
        return;
    }
    openFilePicker("photo", { viewOnce: true });
}

function openPollDialog() {
    closeAttachMenu();
    if (activeCommunity || !activeStudent) {
        showNotice(translate("Polls work in one-to-one chats for now."), true);
        return;
    }
    const dialog = document.getElementById("pollDialog");
    if (!dialog) return;
    const question = document.getElementById("pollQuestion");
    if (question) question.value = "";
    const rows = document.getElementById("pollOptions");
    if (rows) {
        rows.replaceChildren();
        for (let index = 0; index < 2; index += 1) addPollOptionRow(rows, "");
    }
    dialog.showModal();
}

function addPollOptionRow(rows, value) {
    if (rows.childElementCount >= 8) return;
    const row = document.createElement("div");
    row.className = "poll-option-row";
    const input = document.createElement("input");
    input.type = "text";
    input.maxLength = 80;
    input.value = value;
    input.placeholder = `${rows.childElementCount + 1}. ${translate("Option")}`;
    const remove = document.createElement("button");
    remove.type = "button";
    remove.className = "poll-option-remove";
    remove.setAttribute("aria-label", translate("Remove option"));
    remove.textContent = "✕";
    remove.addEventListener("click", () => {
        if (rows.childElementCount > 2) row.remove();
    });
    row.append(input, remove);
    rows.appendChild(row);
    input.focus();
}

async function createPollFromDialog() {
    const dialog = document.getElementById("pollDialog");
    const question = String(document.getElementById("pollQuestion")?.value || "").trim();
    const options = Array.from(
        document.querySelectorAll("#pollOptions input"),
        input => String(input.value || "").trim()
    ).filter(Boolean);
    if (!question || options.length < 2) {
        showNotice(translate("Ask a question and give at least two options."), true);
        return;
    }
    if (!currentUser || !activeStudent) return;
    const recipient = activeStudent;
    if (dialog) dialog.close();
    try {
        const { data, error } = await supabase.from("messages")
            .insert({
                sender_id: currentUser.id,
                receiver_id: recipient.id,
                content: question
            })
            .select(messageSelectColumns())
            .single();
        if (error) throw error;
        const { data: pollRow, error: pollError } = await supabase.from("polls")
            .insert({ message_id: data.id, creator_id: currentUser.id, options })
            .select("id")
            .single();
        if (pollError) {
            console.warn("Could not attach the poll options:", pollError.message);
            showNotice(translate("The poll table is not in this database yet — run the polls migration."), true);
        } else {
            pollByMessage.set(data.id, { id: pollRow.id, options, votes: [] });
        }
        renderMessages([...displayedMessages, data], true);
        const previous = latestByStudent.get(recipient.id);
        latestByStudent.set(recipient.id, { latest: data, unread: previous?.unread || 0 });
        void loadStudentsAndConversations({ refreshProfiles: false }).catch(() => {});
    } catch (error) {
        console.error("Could not send the poll:", error.message || error);
        showNotice(translate("Could not send the poll."), true);
    }
}

function createMediaElement(url) {
    if (!url) return null;
    if (url.startsWith("private-media:")) {
        const storageUrl = url;
        const cached = signedChatMediaUrls.get(storageUrl);
        if (!cached || cached.expiresAt <= Date.now()) {
            void signedChatMediaUrl(storageUrl).then(() => {
                if (displayedMessages.some(message => message.media_url === storageUrl)) {
                    renderMessages(displayedMessages, false);
                }
            }).catch(error => {
                console.warn("Could not load a private chat attachment:", error);
            });
            const loading = document.createElement("span");
            loading.className = "message-file";
            loading.textContent = translate("Loading attachment...");
            return loading;
        }
        url = cached.url;
    }
    const isVideo = isVideoUrl(url);
    const isAudio = isVoiceUrl(url);
    if (isAudio) return createVoicePlayer(url, {
        translate,
        onError: (message) => showNotice(message, true)
    });
    const isImage = isImageUrl(url);
    if (!isVideo && !isImage) {
        const attachment = document.createElement("a");
        attachment.className = "message-file";
        attachment.href = url;
        attachment.target = "_blank";
        attachment.rel = "noopener noreferrer";
        attachment.textContent = `📎 ${url.split("?")[0].split("/").pop() || "Download attachment"}`;
        return attachment;
    }

    const media = document.createElement(isVideo ? "video" : "img");
    media.className = "message-media";
    media.src = url;
    if (isVideo) {
        media.controls = true;
        media.playsInline = true;
        media.preload = "metadata";
        /* The clip is fetched into the phone's own media cache right now,
           so the student who taps play later finds it already in the
           pocket - and finds it at all on a day without signal. */
        warmMedia(url);
        const voiceOptions = { translate, onError: (message) => showNotice(message, true) };
        const fallback = (element) => {
            const play = document.createElement("button");
            play.type = "button";
            play.className = "message-file message-video-open";
            play.textContent = translate("▶ Play video");
            play.addEventListener("click", async () => {
                const opened = await openInPhonePlayer(url);
                if (!opened.ok) window.open(url, "_blank");
            });
            element.replaceWith(play);
        };
        onMediaFailure(media, fallback);
        onMediaStall(media, fallback);
        /* The audio-only verdict needs a decoded frame behind it, so the first
           frame is nudged into view before the probe is even attached. */
        paintFirstFrame(media);
        onAudioOnlyVideo(media, (element) => replaceWithVoicePlayer(element, {
            ...voiceOptions,
            note: translate("No picture in this file, so it plays as audio.")
        }));
    } else {
        media.alt = "Shared image";
        media.loading = "lazy";
        media.decoding = "async";
    }
    return media;
}

function signedChatMediaUrl(mediaUrl) {
    const cached = signedChatMediaUrls.get(mediaUrl);
    if (cached && cached.expiresAt > Date.now()) return Promise.resolve(cached.url);
    if (pendingChatMediaUrls.has(mediaUrl)) return pendingChatMediaUrls.get(mediaUrl);

    const request = resolveCampusMediaUrl(supabase, mediaUrl, CHAT_MEDIA_LINK_SECONDS)
        .then(url => {
            signedChatMediaUrls.set(mediaUrl, {
                url,
                expiresAt: Date.now() + (CHAT_MEDIA_LINK_SECONDS - 30) * 1000
            });
            return url;
        })
        .finally(() => pendingChatMediaUrls.delete(mediaUrl));
    pendingChatMediaUrls.set(mediaUrl, request);
    return request;
}

async function loadCommunities() {
    const [{ data: communityRows, error: communityError },
        { data: memberships, error: membershipError }] = await Promise.all([
        supabase.from("communities")
            .select("id, owner_id, name, description, kind, created_at")
            .order("created_at", { ascending: false })
            .limit(500),
        supabase.from("community_members")
            .select("community_id")
            .eq("user_id", currentUser.id)
    ]);
    if (communityError) throw communityError;
    if (membershipError) throw membershipError;
    communities = communityRows || [];
    communityMemberships = new Set((memberships || []).map(item => item.community_id));
    renderCommunities();
}

async function loadCommunitiesSafely() {
    try {
        await loadCommunities();
    } catch (error) {
        console.warn("Groups and channels are unavailable:", error);
        communities = [];
        communityMemberships = new Set();
        elements.communitiesList.replaceChildren();
        const notice = document.createElement("p");
        notice.className = "empty-state";
        notice.textContent = error.code && isMissingMigrationObject(error)
            ? "Groups are not available yet. Ask the app owner to run database/RUN_ALL.sql once."
            : `Groups could not load: ${error.message}`;
        elements.communitiesList.appendChild(notice);
    }
}

function renderCommunities() {
    const query = elements.search.value.trim().toLowerCase();
    const matches = communities.filter(community =>
        `${community.name} ${community.description} ${community.kind}`.toLowerCase().includes(query)
    );
    elements.communitiesList.replaceChildren();

    if (!matches.length) {
        const empty = document.createElement("p");
        empty.className = "empty-state";
        empty.textContent = translate(communities.length
            ? "No groups or channels match your search."
            : "No groups or channels yet. Create one or invite friends to start.");
        elements.communitiesList.appendChild(empty);
        return;
    }

    for (const community of matches) {
        const isMember = communityMemberships.has(community.id);
        const card = document.createElement("article");
        card.className = "community-card";
        const name = document.createElement("h3");
        name.textContent = community.name;
        const kind = document.createElement("span");
        kind.className = "community-meta";
        kind.textContent = translate(community.kind === "channel" ? "Channel" : "Group");
        const description = document.createElement("p");
        description.textContent = community.description || translate("No description yet.");
        const actions = document.createElement("div");
        actions.className = "community-actions";

        const primary = document.createElement("button");
        primary.type = "button";
        primary.dataset.action = isMember ? "open" : "join";
        primary.dataset.id = community.id;
        primary.textContent = translate(isMember ? "Open" : "Join");
        actions.appendChild(primary);

        if (isMember && community.owner_id !== currentUser.id) {
            const leave = document.createElement("button");
            leave.type = "button";
            leave.className = "community-leave";
            leave.dataset.action = "leave";
            leave.dataset.id = community.id;
            leave.textContent = translate("Leave");
            actions.appendChild(leave);
        } else if (community.owner_id === currentUser.id) {
            const owner = document.createElement("span");
            owner.className = "community-meta";
            owner.textContent = translate("You own this");
            actions.appendChild(owner);
        }

        card.append(name, kind, description, actions);
        elements.communitiesList.appendChild(card);
    }
}

// Without a connection the Chats page still has to open, so the last
// snapshot of conversations and profiles is served from local storage.
function restoreOfflineChats() {
    const directory = getCachedChatDirectory(currentUser.id);
    if (!directory?.conversations?.length) return false;

    latestByStudent = new Map(directory.conversations
        .filter(item => item.latest && /^[0-9a-f-]{36}$/i.test(item.peerId))
        .map(item => [item.peerId, { latest: item.latest, unread: item.unread || 0 }]));
    for (const profile of directory.profiles || []) {
        if (latestByStudent.has(profile.id) &&
            !allStudents.some(item => item.id === profile.id)) {
            allStudents.push(profile);
        }
    }
    students = allStudents;
    void renderStudents();
    renderNavUnread();
    return true;
}

/* Unread badges cannot be counted out of the recent message window: a busy term
   pushes a quiet friend's unread message out of the window, and the badge goes
   missing exactly when the student most needs it. Ask the database instead. */
async function loadUnreadCounts() {
    let columns = "sender_id, deleted_by";
    let rows = null;
    for (let attempt = 0; attempt < 2; attempt += 1) {
        const { data, error } = await supabase
            .from("messages")
            .select(columns)
            .eq("receiver_id", currentUser.id)
            .eq("is_read", false)
            .limit(UNREAD_COUNT_LIMIT);
        if (!error) {
            rows = data || [];
            break;
        }
        // A database without the delete columns (PART 13) still knows what is unread.
        if (columns === "sender_id" || !isMissingMigrationObject(error)) {
            reportPartialLoadFailure("your unread counts", error);
            break;
        }
        columns = "sender_id";
    }
    const counts = new Map();
    for (const row of rows || []) {
        if ((row.deleted_by || []).includes(currentUser.id)) continue;
        counts.set(row.sender_id, (counts.get(row.sender_id) || 0) + 1);
    }
    return counts;
}

async function loadStudentsAndConversations({ refreshProfiles = true, organizeReady = null, staffReady = null } = {}) {
    /* The saved snapshot goes up first even when the signal is perfect, then the
       server's answer replaces it. Drawing nothing until the network replies is
       exactly what makes a chat app feel slow. */
    if (organizeReady) {
        /* A hidden chat still may not flash by: painting waits for the organize
           settings. But that reading started back at boot beside this page's own
           round trips, so usually nothing is left to wait for here. */
        try {
            await organizeReady;
        } catch {
            // The boot already reported it; the list still deserves to paint.
        }
    }
    const paintedFromCache = restoreOfflineChats();
    if (!navigator.onLine && paintedFromCache) {
        showNotice(translate("You appear to be offline. Showing your saved chats."));
        return;
    }
    const shouldRefreshProfiles = refreshProfiles ||
        Date.now() - lastProfilesRefreshAt >= PROFILE_REFRESH_INTERVAL_MS;
    const buildProfilesRequest = () => supabase
        .from("profiles")
        .select(profileColumns())
        .neq("id", currentUser.id)
        .eq("is_discoverable", true)
        .order("username", { ascending: true })
        .limit(500);
    const profilesRequest = shouldRefreshProfiles
        ? buildProfilesRequest()
        : Promise.resolve({ data: allStudents, error: null });
    const messagesRequest = supabase
        .from("messages")
        .select(messageSelectColumns())
        .or(`sender_id.eq.${currentUser.id},receiver_id.eq.${currentUser.id}`)
        .order("created_at", { ascending: false })
        .limit(1000);
    const relationshipsRequest = supabase.from("follows")
        .select("follower_id, following_id")
        .or(`follower_id.eq.${currentUser.id},following_id.eq.${currentUser.id}`)
        /* The Sets built from this are the door keepers now, so the list is
           asked for more than the default page and never left short. */
        .limit(2000);
    const groupsRequest = loadGroups(supabase)
        .then(rows => ({ data: rows, error: null }))
        .catch(error => ({ data: null, error }));
    const unreadRequest = loadUnreadCounts();
    /* Blocked members and saved contact names used to be paid for one round
       trip after the whole batch landed, though nothing about them depends on
       the batch. They fly with it now and the list paints a trip sooner. */
    const blocksRequest = supabase
        .from("user_blocks")
        .select("blocked_id");
    const contactNamesRequest = supabase
        .from("contact_names")
        .select("peer_id,name");
    let [
        { data: profiles, error: profilesError },
        { data: messages, error: messagesError },
        { data: relationships, error: relationshipsError },
        { data: groupRows, error: groupsError },
        unreadCounts,
        savedConversations,
        blocksResult,
        contactNamesResult
    ] = await Promise.all([
        profilesRequest,
        messagesRequest,
        relationshipsRequest,
        groupsRequest,
        unreadRequest,
        Promise.resolve(getCachedChatDirectory(currentUser.id)?.conversations || []),
        blocksRequest,
        contactNamesRequest
    ]);

    if (profilesError && noteMissingRoleColumn(profilesError)) {
        const retry = await buildProfilesRequest();
        profiles = retry.data;
        profilesError = retry.error;
    }

    if (messagesError && chatActionsAvailable && isMissingMigrationObject(messagesError)) {
        chatActionsAvailable = false;
        const retry = await supabase
            .from("messages")
            .select(MESSAGE_BASE_SELECT)
            .or(`sender_id.eq.${currentUser.id},receiver_id.eq.${currentUser.id}`)
            .order("created_at", { ascending: false })
            .limit(1000);
        messages = retry.data;
        messagesError = retry.error;
    }

    if (profilesError) reportPartialLoadFailure("the student list", profilesError);
    if (messagesError) reportPartialLoadFailure("your conversations", messagesError);
    if (relationshipsError) reportPartialLoadFailure("your connections", relationshipsError);
    if (groupsError) {
        // A database that has not been given PART 17 simply has no groups, and
        // asking for them on every refresh would keep printing the same warning.
        if (isMissingGroupObjects(groupsError)) {
            groupsAvailable = false;
            myGroups = [];
        } else {
            reportPartialLoadFailure("your groups", groupsError);
        }
    } else {
        groupsAvailable = true;
        myGroups = groupRows || [];
    }
    const { data: blocks, error: blocksError } = blocksResult;
    if (blocksError && !isMissingMigrationObject(blocksError)) {
        reportPartialLoadFailure("your blocked members", blocksError);
    }
    socialAccessMigrationReady = !blocksError;
    const { data: contactNameRows, error: contactNamesError } = contactNamesResult;
    if (contactNamesError && !isMissingMigrationObject(contactNamesError)) {
        reportPartialLoadFailure("your saved contact names", contactNamesError);
    }
    if (contactNameRows) {
        contactNames.clear();
        for (const row of contactNameRows) contactNames.set(row.peer_id, row.name);
    }
    if (activeStudent && !activeCommunity) {
        elements.chatName.textContent = studentName(activeStudent);
    }
    followingStudentIds = new Set((relationships || [])
        .filter(row => row.follower_id === currentUser.id)
        .map(row => row.following_id));
    followerStudentIds = new Set((relationships || [])
        .filter(row => row.following_id === currentUser.id)
        .map(row => row.follower_id));
    blockedStudentIds = new Set((blocks || []).map(row => row.blocked_id));

    if (staffReady) {
        /* The directory hides profiles the staff role says must stay unseen,
           so filtering waits for that one row to land. It has been flying
           since the boot began - usually nothing is left to wait for here. */
        try {
            await staffReady;
        } catch {
            // The role promise reports for itself; the list still paints.
        }
    }
    if (shouldRefreshProfiles) {
        const visibleProfiles = (profiles || []).filter(profile => !hiddenByRolePrivacy(profile));
        const visibleIds = new Set(visibleProfiles.map(profile => profile.id));
        const conversationIds = [...new Set([
            ...(messages || []).flatMap(message => [
                message.sender_id === currentUser.id ? message.receiver_id : message.sender_id
            ]),
            ...savedConversations.map(item => item.peerId),
            ...pendingChatInviteIds,
            ...followerStudentIds
        ])].filter(id => id !== currentUser.id && !visibleIds.has(id));
        let conversationProfiles = [];
        if (conversationIds.length) {
            const byIds = (columns) => supabase
                .from("profiles")
                .select(columns)
                .in("id", conversationIds);
            let { data, error } = await byIds(profileColumns());
            if (error && noteMissingRoleColumn(error)) {
                ({ data, error } = await byIds(PROFILE_BASE_COLUMNS));
            }
            if (error) {
                reportPartialLoadFailure("the profiles in your chats", error);
            } else {
                conversationProfiles = data || [];
            }
        }
        allStudents = [...visibleProfiles, ...conversationProfiles];
        lastProfilesRefreshAt = Date.now();
    }
    students = allStudents;
    latestByStudent = new Map();
    await runUiStep("the blocked members panel", renderBlockedMembers);
    const mutualIds = allStudents
        .filter(profile => followingStudentIds.has(profile.id) && followerStudentIds.has(profile.id))
        .map(profile => profile.id);
    if (mutualIds.length) {
        const { data: presence, error: presenceError } = await supabase.from("user_presence")
            .select("user_id, last_seen_at")
            .in("user_id", mutualIds);
        if (presenceError) {
            reportPartialLoadFailure("online status", presenceError);
            socialAccessMigrationReady = false;
        }
        lastSeenByStudent = new Map((presence || [])
            .map(item => [item.user_id, item.last_seen_at]));
    } else {
        lastSeenByStudent.clear();
    }

    const acceptedInvite = [...pendingChatInviteIds]
        .map(id => allStudents.find(profile => profile.id === id))
        .find(profile => profile &&
            followingStudentIds.has(profile.id) &&
            followerStudentIds.has(profile.id));
    if (acceptedInvite && document.visibilityState === "visible") {
        pendingChatInviteIds.delete(acceptedInvite.id);
        persistPendingChatInvites();
    }

    for (const message of messages || []) {
        const otherId = message.sender_id === currentUser.id
            ? message.receiver_id
            : message.sender_id;
        /* The window arrives newest first, so the first row seen for a peer is
           their latest message. */
        if (!latestByStudent.has(otherId)) {
            latestByStudent.set(otherId, {
                latest: message,
                unread: unreadCounts.get(otherId) || 0
            });
        }
    }

    /* A chat whose newest message is older than this window is still the
       student's chat, so the last preview this phone saw keeps the row on the
       list instead of letting it vanish. */
    for (const saved of savedConversations) {
        if (!saved?.latest || latestByStudent.has(saved.peerId)) continue;
        if (!/^[0-9a-f-]{36}$/i.test(saved.peerId)) continue;
        latestByStudent.set(saved.peerId, {
            latest: saved.latest,
            unread: unreadCounts.get(saved.peerId) || 0
        });
    }

    // Unread from a peer this phone has never opened still has to be counted.
    for (const [peerId, count] of unreadCounts) {
        if (!latestByStudent.has(peerId)) latestByStudent.set(peerId, { latest: null, unread: count });
    }

    if (navigator.onLine) {
        cacheChatDirectory(currentUser.id, {
            profiles: allStudents.filter(profile => latestByStudent.has(profile.id)),
            conversations: [...latestByStudent.entries()].map(([peerId, conversation]) => ({
                peerId,
                latest: conversation.latest,
                unread: conversation.unread
            }))
        });
    }

    await runUiStep("the conversation list", renderStudents);
    if (acceptedInvite && document.visibilityState === "visible") {
        void openConversation(acceptedInvite);
    }
}

function scheduleMemberSearch(query, destination) {
    searchRequestId += 1;
    const requestId = searchRequestId;
    window.clearTimeout(searchDebounceTimer);
    searchDebounceTimer = window.setTimeout(() => {
        void searchMembers(query, destination, requestId);
    }, 250);
}

async function searchMembers(query, destination, requestId) {
    if (!currentUser) return;

    const safeQuery = normalizeMemberSearch(query)
        .replace(/[,%()'"\\*]/g, " ")
        .replace(/\s+/g, " ")
        .trim();
    const terms = safeQuery.split(" ").filter(Boolean).slice(0, 8);
    const selectedGender = destination === "calls"
        ? callsGenderSearch.value
        : genderSearch.value;
    if (!terms.length && !selectedGender) {
        students = allStudents;
        renderStudents();
        return;
    }

    const buildSearch = (columns) => {
        let profilesRequest = supabase
            .from("profiles")
            .select(columns)
            .neq("id", currentUser.id)
            .order("username", { ascending: true });
        if (destination === "calls") {
            profilesRequest = profilesRequest.eq("is_discoverable", true);
        } else if (followerStudentIds.size) {
            const followerIds = [...followerStudentIds].filter(id =>
                /^[0-9a-f-]{36}$/i.test(id)
            );
            profilesRequest = profilesRequest.or(
                `is_discoverable.eq.true,id.in.(${followerIds.join(",")})`
            );
        } else {
            profilesRequest = profilesRequest.eq("is_discoverable", true);
        }
        if (terms.length) {
            const termGroups = terms.map(term =>
                `or(username.ilike.%${term}%,full_name.ilike.%${term}%,gender.eq.${term},course.ilike.%${term}%,and(share_email.eq.true,contact_email.ilike.%${term}%),and(share_phone.eq.true,contact_phone.ilike.%${term}%))`
            );
            profilesRequest = profilesRequest.or(`and(${termGroups.join(",")})`);
        }
        if (selectedGender) profilesRequest = profilesRequest.eq("gender", selectedGender);
        return profilesRequest.limit(100);
    };

    let { data, error } = await buildSearch(profileColumns());
    if (error && noteMissingRoleColumn(error)) {
        ({ data, error } = await buildSearch(PROFILE_BASE_COLUMNS));
    }

    if (error) {
        console.error("Could not search members and universities:", error);
        showNotice(`Could not search members: ${error.message}`, true);
        return;
    }
    if (requestId !== searchRequestId) return;

    const visible = (data || []).filter(profile => !hiddenByRolePrivacy(profile));
    if (destination === "calls") {
        renderCallDirectory(visible);
    } else {
        students = visible;
        renderStudents();
    }
}

function studentSearchText(student) {
    return [
        studentName(student),
        student.username,
        genderLabel(student.gender),
        student.course,
        student.share_email ? student.contact_email : "",
        student.share_phone ? student.contact_phone : ""
    ].filter(Boolean).join(" ").toLowerCase();
}

function normalizeMemberSearch(value) {
    return value.normalize("NFKC").replace(/\s+/g, " ").trim();
}

function memberMatchesSearch(student, query) {
    const terms = normalizeMemberSearch(query).toLowerCase().split(" ").filter(Boolean);
    if (!terms.length) return true;
    const searchableText = studentSearchText(student);
    return terms.every(term => searchableText.includes(term));
}

function totalUnread() {
    let total = 0;
    for (const conversation of latestByStudent.values()) {
        total += conversation?.unread || 0;
    }
    for (const group of myGroups) total += group.unread_count || 0;
    return total;
}

function renderNavUnread() {
    const total = totalUnread();
    /* The digit on the icon is the same number this row of the tab bar paints,
       and it is handed over here because this page has counted both chats and
       groups. Zero takes the digit off; nothing else can. */
    void setMessageBadge(total);
    if (navChatsBadge) {
        navChatsBadge.textContent = total > 99 ? "99+" : String(total);
        navChatsBadge.classList.toggle("hidden", total <= 0);
    }
    /* iOS keeps the number on the icon until the tray is emptied, so reading
       everything is what takes the badge away. */
    if (total > 0) {
        unreadAlertsPending = true;
    } else if (unreadAlertsPending) {
        unreadAlertsPending = false;
        void clearMessageAlerts();
    }
}

async function loadNavProfilePhoto() {
    const { data, error } = await supabase
        .from("profiles")
        .select("avatar_url")
        .eq("id", currentUser.id)
        .maybeSingle();
    if (error || !data) return;
    setMemberAvatar(navProfilePhoto, data);
}

/* A chat row is someone the user actually talks to: a mutual friend, a
   conversation that already exists, or a request waiting to be accepted.
   Everyone else who registered belongs in the People list. */
function isIncomingChatRequest(student) {
    return followerStudentIds.has(student.id) && !followingStudentIds.has(student.id);
}

function isChatContact(student) {
    const conversation = latestByStudent.get(student.id);
    return !!conversation?.latest ||
        !!conversation?.unread ||
        isIncomingChatRequest(student) ||
        (followingStudentIds.has(student.id) && followerStudentIds.has(student.id));
}

/* The one place that decides friendship for the chat door: both sides must
   follow each other. The database now refuses a message to anyone short of
   this, so the app asks the same question before it opens a chat. */
function isMutualFriend(id) {
    return followingStudentIds.has(id) && followerStudentIds.has(id);
}

/* A pending invitation from the other side is not a stranger, so the door
   names the one step that actually opens it. */
function chatDoorNotice(student) {
    return isIncomingChatRequest(student)
        ? translate("They are waiting to chat. Accept their invitation first.")
        : translate(
            "You can only chat with a friend. Invite them first, and the chat opens once they accept."
        );
}

/* ------------------------------------------------------------
 * Found documents, read where a student actually looks for news
 * about himself: the chat list. This row is drawn from
 * my_found_items(), which the database already strips of the
 * finder, and it writes nothing into `messages` - so a picked-up
 * ID card can never turn into a conversation, a post, or a name.
 * ------------------------------------------------------------ */
let foundItems = [];

async function refreshFoundChats() {
    if (!supabase || !currentUser) return;
    let module;
    try {
        module = await import("../lib/found-items.js");
    } catch (error) {
        console.warn("The found documents module could not be loaded:", error);
        return;
    }
    const rows = await module.loadMyFoundItems(supabase);
    if (!rows) return;
    const changed = JSON.stringify(rows) !== JSON.stringify(foundItems);
    foundItems = rows;
    if (changed) renderStudents();
}

function foundWhenLabel(value) {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "";
    return `${date.toLocaleDateString(undefined, { day: "numeric", month: "short" })} · ` +
        `${date.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" })}`;
}

function foundPreview(rows) {
    const open = rows.filter(row => row.status !== "returned");
    if (!open.length) return translate("Things of yours that were found");
    const first = open[0];
    return `${translate("Found at")}: ${first.place}`;
}

function foundChatItem() {
    const unseen = foundItems.filter(row => !row.owner_seen_at && row.status !== "returned");
    const item = document.createElement("div");
    item.className = "student-directory-item";
    const button = document.createElement("button");
    button.type = "button";
    button.className = "conversation";
    button.setAttribute("aria-label", translate("Something of yours was found"));

    const avatar = document.createElement("span");
    avatar.className = "avatar avatar-fallback";
    avatar.textContent = "🔎";

    const info = document.createElement("span");
    info.className = "conversation-info";
    const rowTop = document.createElement("span");
    rowTop.className = "conversation-top";
    const displayName = document.createElement("span");
    displayName.className = "conversation-name";
    displayName.textContent = unseen.length
        ? translate(unseen.length > 1 ? "Some things of yours were found" : "Something of yours was found")
        : translate("Things of yours that were found");
    const side = document.createElement("span");
    side.className = "conversation-side";
    const stamp = document.createElement("time");
    stamp.className = "conversation-time";
    const newest = foundItems
        .map(row => row.found_at || "")
        .sort()
        .pop();
    stamp.dateTime = newest;
    stamp.textContent = formatListTime(newest);
    if (unseen.length) stamp.classList.add("has-unread");
    side.appendChild(stamp);
    if (unseen.length) {
        const unread = document.createElement("span");
        unread.className = "unread";
        unread.textContent = String(unseen.length);
        unread.setAttribute("aria-label", `${unseen.length} unread messages`);
        side.appendChild(unread);
    }
    rowTop.append(displayName, side);
    info.appendChild(rowTop);
    const preview = document.createElement("span");
    preview.className = "conversation-preview";
    preview.textContent = foundPreview(foundItems);
    info.appendChild(preview);
    button.append(avatar, info);
    button.addEventListener("click", () => openFoundChatDialog());
    item.appendChild(button);
    return item;
}

function foundItemCard(module, row) {
    const card = document.createElement("div");
    card.className = "found-item";
    const title = document.createElement("h4");
    title.textContent = `${translate(module.foundKindLabel(row.kind))}${row.number_key ? ` · ${row.number_key}` : ""}`;
    const state = document.createElement("p");
    state.textContent = translate(row.status === "returned"
        ? "Was found and given back"
        : "Something of yours was found");
    const place = document.createElement("p");
    place.textContent = `${translate("Found at")}: ${row.place}`;
    const when = document.createElement("p");
    when.textContent = `${translate("When")}: ${foundWhenLabel(row.found_at)}`;
    const kept = document.createElement("p");
    kept.textContent = `${translate("It is with")}: ${translate(module.keptPlaceLabel(row.held_at))}`;
    card.append(title, state, place, when, kept);

    if (row.status !== "returned") {
        const row1 = document.createElement("div");
        row1.className = "dial-row";
        const collect = document.createElement("button");
        collect.type = "button";
        collect.className = "secondary-action";
        collect.textContent = translate("I have picked it up");
        collect.addEventListener("click", () => runFoundAction(module, collect, row.item_id, "returned"));
        row1.appendChild(collect);
        card.appendChild(row1);
    }
    if (!row.owner_seen_at) {
        const row2 = document.createElement("div");
        row2.className = "dial-row";
        const dismiss = document.createElement("button");
        dismiss.type = "button";
        dismiss.className = "secondary-action";
        dismiss.textContent = translate("This is not mine");
        dismiss.addEventListener("click", () => runFoundAction(module, dismiss, row.item_id, "seen"));
        row2.appendChild(dismiss);
        card.appendChild(row2);
    }
    return card;
}

async function runFoundAction(module, button, itemId, action) {
    const status = document.getElementById("found-chat-status");
    button.disabled = true;
    const done = action === "returned"
        ? await module.setFoundItemResult(supabase, { itemId, status: "returned" })
        : await module.markFoundItemSeen(supabase, itemId);
    status.textContent = translate(done.message || "That could not be done.");
    if (done.ok) await refreshFoundChats();
    else button.disabled = false;
    renderFoundChatDialog(module);
}

function renderFoundChatDialog(module) {
    const list = document.getElementById("found-chat-list");
    const status = document.getElementById("found-chat-status");
    document.getElementById("found-chat-title").textContent = translate(
        foundItems.some(row => !row.owner_seen_at && row.status !== "returned")
            ? "Something of yours was found"
            : "Things of yours that were found"
    );
    list.replaceChildren(...foundItems.map(row => foundItemCard(module, row)));
    if (!foundItems.length) {
        const empty = document.createElement("p");
        empty.className = "dial-result";
        empty.textContent = translate("Nothing of yours has been handed in.");
        list.appendChild(empty);
    }
    status.textContent = translate(
        "You are told a place and a time, never the hands it passed through."
    );
}

async function openFoundChatDialog() {
    let module;
    try {
        module = await import("../lib/found-items.js");
    } catch (error) {
        console.warn("The found documents module could not be loaded:", error);
        showNotice(translate("Found documents are unavailable."), true);
        return;
    }
    renderFoundChatDialog(module);
    document.getElementById("found-chat-dialog").showModal();
    /* Opening the row is the reading of it: the badge clears on the server,
       so a second phone stops nagging about the same document too. */
    const unseen = foundItems.filter(row => !row.owner_seen_at);
    for (const row of unseen) {
        await module.markFoundItemSeen(supabase, row.item_id).catch(() => {});
    }
    if (unseen.length) {
        await refreshFoundChats();
        renderFoundChatDialog(module);
    }
}

document.getElementById("found-chat-close")
    .addEventListener("click", () => document.getElementById("found-chat-dialog").close());

function renderStudents() {
    renderNavUnread();
    renderArchivedCount();
    const query = normalizeMemberSearch(elements.search.value).toLowerCase();
    const listingChatsOnly = !query && !genderSearch.value;
    renderCallDirectory();
    const filteredStudents = students
        .filter(student => !blockedStudentIds.has(student.id))
        .filter(student => !hiddenByRolePrivacy(student))
        .filter(student => !chatRowIsHidden(
            student.id,
            latestByStudent.get(student.id)?.latest?.created_at
        ))
        .filter(student => activeChatFilter === "archived"
            ? chatOrganize.isArchived(student.id)
            : !chatOrganize.isArchived(student.id))
        .filter(student => !query || student.is_discoverable || followerStudentIds.has(student.id))
        .filter(student => memberMatchesSearch(student, query))
        .filter(student => !genderSearch.value || student.gender === genderSearch.value)
        .filter(student => {
            const conversation = latestByStudent.get(student.id);
            if (activeChatFilter === "unread") return (conversation?.unread || 0) > 0;
            if (activeChatFilter === "favorites") return favoriteStudentIds.has(student.id);
            if (activeChatFilter === "followers") return followerStudentIds.has(student.id);
            if (activeChatFilter === "people") return !isChatContact(student);
            return listingChatsOnly || isChatContact(student);
        })
        .sort((a, b) => {
            const aInvitation = isIncomingChatRequest(a);
            const bInvitation = isIncomingChatRequest(b);
            if (aInvitation !== bInvitation) return aInvitation ? -1 : 1;
            const aLatest = latestByStudent.get(a.id)?.latest?.created_at || "";
            const bLatest = latestByStudent.get(b.id)?.latest?.created_at || "";
            return bLatest.localeCompare(aLatest) || studentName(a).localeCompare(studentName(b));
        });

    const groupEntries = visibleGroups(query)
        .map(group => ({ kind: "group", group, at: group.last_message_at || "" }));
    const chatEntries = filteredStudents
        .filter(student => !isIncomingChatRequest(student))
        .map(student => ({
            kind: "student",
            student,
            at: latestByStudent.get(student.id)?.latest?.created_at || ""
        }));
    /* A group belongs in the same list as a private chat, in the same order:
       newest message on top. A request to connect stays pinned above the lot,
       because the thing a phone user checks twice is whether they were answered. */
    const ordered = [
        ...activeChatFilter === "all" && listingChatsOnly && foundItems.length
            ? [{ kind: "found" }]
            : [],
        ...filteredStudents
            .filter(isIncomingChatRequest)
            .map(student => ({ kind: "student", student })),
        ...[...chatEntries, ...groupEntries].sort((a, b) =>
            (b.at || "").localeCompare(a.at || "") || entryName(a).localeCompare(entryName(b)))
    ];

    elements.conversationList.replaceChildren();

    if (!ordered.length) {
        const empty = document.createElement("p");
        empty.className = "empty-state";
        const emptyMessage = activeChatFilter === "groups"
            ? "No groups yet. Tap the 👥 button above to make one with your friends."
            : activeChatFilter === "archived"
                ? "No archived chats. Long-press a chat and choose Archive."
                : activeChatFilter === "unread"
                ? "No unread chats."
                : activeChatFilter === "favorites"
                    ? "No favorite chats yet."
                    : activeChatFilter === "followers"
                        ? "No followers to show yet."
                        : activeChatFilter === "people"
                            ? "No new students to show. Everyone registered is already in your chats."
                            : listingChatsOnly
                                ? students.length
                                    ? "No chats yet. Open People to find classmates and invite them."
                                    : "No other accounts yet. Invite someone to join Campus Connect."
                                : "No members match that search.";
        empty.textContent = translate(emptyMessage);
        elements.conversationList.appendChild(empty);
        return;
    }

    for (const entry of ordered) {
        elements.conversationList.appendChild(
            entry.kind === "group"
                ? groupChatItem(entry.group)
                : entry.kind === "found"
                    ? foundChatItem()
                    : studentChatItem(entry.student)
        );
    }
}

function studentChatItem(student) {
    const conversation = latestByStudent.get(student.id);
    const isFollowing = followingStudentIds.has(student.id);
    const followsStudent = followerStudentIds.has(student.id);
    const isMutual = isFollowing && followsStudent;
    const item = document.createElement("div");
    item.className = "student-directory-item";
    const button = document.createElement("button");
    button.type = "button";
    button.className = "conversation";
    button.classList.toggle("selected", student.id === activeStudent?.id);
    button.setAttribute("aria-pressed", String(student.id === activeStudent?.id));

    const avatar = document.createElement("span");
    avatar.className = "avatar";
    setAvatarContent(avatar, student);

    button.setAttribute("aria-label", translate("Open private chat"));
    button.append(avatar);

    const info = document.createElement("span");
    info.className = "conversation-info";
    const rowTop = document.createElement("span");
    rowTop.className = "conversation-top";
    const displayName = document.createElement("span");
    displayName.className = "conversation-name";
    displayName.textContent = studentName(student);
    appendRoleBadge(displayName, student);
    chatRowFlags(student.id, displayName);
    const side = document.createElement("span");
    side.className = "conversation-side";
    const stamp = document.createElement("time");
    stamp.className = "conversation-time";
    stamp.dateTime = conversation?.latest?.created_at || "";
    stamp.textContent = formatListTime(conversation?.latest?.created_at);
    if (conversation?.unread) stamp.classList.add("has-unread");
    side.appendChild(stamp);
    if (conversation?.unread) {
        const unread = document.createElement("span");
        unread.className = "unread";
        unread.textContent = String(conversation.unread);
        unread.setAttribute("aria-label", `${conversation.unread} unread messages`);
        side.appendChild(unread);
    }
    rowTop.append(displayName, side);
    info.appendChild(rowTop);
    const preview = document.createElement("span");
    preview.className = "conversation-preview";
    preview.textContent = conversationPreview(conversation);
    info.appendChild(preview);
    button.appendChild(info);
    const peer = chatPeerOf(student);
    button.addEventListener("click", () => {
        /* A row held open for its menu must not also open the chat when the
           finger comes up. */
        if (Date.now() - chatMenuOpenedAt < 600) return;
        void openConversation(student);
    });
    item.appendChild(button);
    const presence = document.createElement("span");
    presence.className = "member-presence";
    const connectionStatus = !isFollowing && followsStudent
        ? translate("Wants to connect")
        : isMutual
            ? presenceText(lastSeenByStudent.get(student.id))
            : "";
    const visibleGender = genderLabel(student.gender);
    presence.textContent = [connectionStatus, visibleGender]
        .filter(Boolean)
        .join(" · ");
    const isFavorite = favoriteStudentIds.has(student.id);
    const favoriteButton = document.createElement("button");
    favoriteButton.type = "button";
    favoriteButton.className = "favorite-chat-button";
    favoriteButton.textContent = isFavorite ? "★" : "☆";
    favoriteButton.setAttribute("aria-pressed", String(isFavorite));
    favoriteButton.setAttribute("aria-label", translate(
        isFavorite ? "Remove from favorites" : "Add to favorites"
    ));
    favoriteButton.title = favoriteButton.getAttribute("aria-label");
    favoriteButton.addEventListener("click", () => toggleFavorite(student.id));
    item.appendChild(favoriteButton);
    const controls = document.createElement("div");
    controls.className = "student-controls";
    const profileButton = document.createElement("button");
    profileButton.type = "button";
    profileButton.textContent = translate("View profile");
    profileButton.addEventListener("click", () => openMemberProfile(student));
    controls.appendChild(profileButton);
    if (isMutualFriend(student.id)) {
        const messageButton = document.createElement("button");
        messageButton.type = "button";
        messageButton.className = "message-member-button";
        messageButton.textContent = translate("Message");
        messageButton.disabled = blockedStudentIds.has(student.id);
        messageButton.addEventListener("click", () => void openConversation(student));
        controls.appendChild(messageButton);
    }
    const followButton = document.createElement("button");
    followButton.type = "button";
    followButton.textContent = translate(
        isMutual
            ? "Open chat"
            : isFollowing
                ? "Cancel invitation"
                : followsStudent
                    ? "Accept & chat"
                    : "Invite to chat"
    );
    followButton.addEventListener("click", () => {
        if (isMutual) {
            void openConversation(student);
        } else if (!isFollowing && followsStudent) {
            followButton.disabled = true;
            void respondToInvitation(student, true);
        } else {
            followButton.disabled = true;
            void toggleFollow(student);
        }
    });
    controls.appendChild(followButton);
    if (!isFollowing && followsStudent) {
        const declineButton = document.createElement("button");
        declineButton.type = "button";
        declineButton.textContent = translate("Decline");
        declineButton.addEventListener("click", () => {
            declineButton.disabled = true;
            void respondToInvitation(student, false);
        });
        controls.appendChild(declineButton);
    }
    const blockButton = document.createElement("button");
    blockButton.type = "button";
    blockButton.textContent = translate("Block");
    blockButton.addEventListener("click", () => void toggleBlock(student));
    controls.appendChild(blockButton);
    if (!isMutual) {
        if (presence.textContent) item.appendChild(presence);
        item.appendChild(controls);
        const contactLinks = createStudentContactLinks(student, "student-contact-links");
        if (contactLinks) item.appendChild(contactLinks);
    }
    attachChatRowMenu(item, peer);
    return item;
}

// A group row is built by hand rather than reused from a contact row because
// there is no person to show: the group itself is the thing, and how many
// people are inside it is the only detail that matters before you open it.
function groupChatItem(group) {
    const item = document.createElement("div");
    item.className = "student-directory-item";
    const button = document.createElement("button");
    button.type = "button";
    button.className = "conversation group-chat";
    button.classList.toggle("selected", group.id === activeCommunity?.id);
    button.setAttribute("aria-pressed", String(group.id === activeCommunity?.id));
    button.setAttribute("aria-label", translate("Open group chat"));

    const avatar = document.createElement("span");
    avatar.className = "avatar";
    avatar.textContent = "\u{1F465}";
    button.appendChild(avatar);

    const info = document.createElement("span");
    info.className = "conversation-info";
    const rowTop = document.createElement("span");
    rowTop.className = "conversation-top";
    const displayName = document.createElement("span");
    displayName.className = "conversation-name";
    displayName.textContent = group.name;
    chatRowFlags(group.id, displayName);
    const side = document.createElement("span");
    side.className = "conversation-side";
    const stamp = document.createElement("time");
    stamp.className = "conversation-time";
    stamp.dateTime = group.last_message_at || "";
    stamp.textContent = formatListTime(group.last_message_at);
    if (group.unread_count) stamp.classList.add("has-unread");
    side.appendChild(stamp);
    if (group.unread_count) {
        const unread = document.createElement("span");
        unread.className = "unread";
        unread.textContent = String(group.unread_count);
        side.appendChild(unread);
    }
    rowTop.append(displayName, side);
    info.appendChild(rowTop);
    const preview = document.createElement("span");
    preview.className = "conversation-preview";
    preview.textContent = groupPreviewText(group);
    info.appendChild(preview);
    button.appendChild(info);
    const groupPeer = chatPeerOfGroup(group);
    button.addEventListener("click", () => {
        if (Date.now() - chatMenuOpenedAt < 600) return;
        void openGroupChat(group);
    });
    item.appendChild(button);
    attachChatRowMenu(item, groupPeer);
    return item;
}

function groupPreviewText(group) {
    if (!group.last_message_at) return translate("Group created. Say hello.");
    const mine = group.last_sender_id === currentUser?.id;
    const body = group.last_content ||
        (isVoiceUrl(group.last_media_url)
            ? translate("Voice message")
            : translate("Attachment"));
    if (mine) return `${translate("You")}: ${body}`;
    const sender = allStudents.find(student => student.id === group.last_sender_id);
    if (sender) return `${studentName(sender)}: ${body}`;
    return body;
}

function visibleGroups(query) {
    if (!groupsAvailable) return [];
    if (activeChatFilter === "favorites" || activeChatFilter === "followers" ||
        activeChatFilter === "people") return [];
    const term = String(query || "");
    return myGroups
        .filter(group => !term || group.name.toLowerCase().includes(term))
        .filter(group => !chatRowIsHidden(group.id, group.last_message_at))
        .filter(group => activeChatFilter === "archived"
            ? chatOrganize.isArchived(group.id)
            : !chatOrganize.isArchived(group.id))
        .filter(group => activeChatFilter !== "unread" || group.unread_count > 0);
}

function entryName(entry) {
    return entry.kind === "group" ? entry.group.name : studentName(entry.student);
}

/* ---- Group chats ---------------------------------------------------------
   A group is a community nobody outside can find: the row lives in the chat
   list next to the private ones, and everything about it — name, members,
   messages — only reaches people inside through the database policies. */

function groupById(id) {
    return myGroups.find(group => group.id === id) || null;
}

function groupMemberLine(group) {
    const count = Number(group.member_count || 1);
    return count === 1
        ? translate("1 member")
        : `${count} ${translate("members")}`;
}

async function refreshGroups() {
    if (!currentUser || !groupsAvailable) return;
    try {
        myGroups = await loadGroups(supabase);
    } catch (error) {
        if (isMissingGroupObjects(error)) groupsAvailable = false;
        else console.error("Could not reload groups:", error);
    }
}

function applyGroupMessage(message) {
    dropLandedSend(message);
    const group = groupById(message.community_id);
    if (!group) return;
    group.last_message_at = message.created_at;
    group.last_sender_id = message.sender_id;
    group.last_content = message.content || "";
    group.last_media_url = message.media_url || null;
    const readingIt = activeCommunity?.id === group.id &&
        document.visibilityState === "visible";
    group.unread_count = readingIt || message.sender_id === currentUser?.id
        ? 0
        : group.unread_count + 1;
    renderStudents();
}

async function openGroupChat(group) {
    if (chatOrganize.isLocked(group.id)) {
        try {
            await chatLock.require(group.id, group.name);
        } catch (error) {
            showNotice(error?.message ||
                translate("This chat stays locked until you verify your identity."), true);
            return;
        }
    }
    const loadId = ++conversationLoadId;
    clearPendingReply();
    closeInlineEdit();
    olderMessagesRequestId += 1;
    isLoadingOlderMessages = false;
    hasOlderMessages = false;
    displayedMessages = [];
    activeStudent = null;
    activeCommunity = group;
    resetVoiceMessage();
    elements.messaging.classList.remove("show-calls");
    elements.chatName.textContent = group.name;
    elements.chatAvatar.replaceChildren();
    elements.chatAvatar.textContent = "👥";
    closeChatActivity();
    elements.chatStatus.textContent = groupMemberLine(group);
    markGroupHeaders();
    elements.callActions.classList.add("hidden");
    renameContactButton.classList.add("hidden");
    renderEmptyMessage(translate("Loading messages…"));
    /* Every member of a group can talk; only a channel keeps its keyboard shut
       for people who did not make it. */
    elements.messageInput.disabled = false;
    elements.mediaInput.disabled = false;
    elements.sendButton.disabled = false;
    startRecordingButton.disabled = false;
    elements.messaging.classList.add("chat-open");
    applyAccessMode();
    refreshChatTheme();
    setActiveDestination("chats");

    try {
        const { messages, hasMore } = await loadCommunityMessages(group);
        if (loadId !== conversationLoadId) return;
        hasOlderMessages = hasMore;
        renderMessages(messages, true);
        showNotice("");
    } catch (error) {
        console.error("Could not open the group:", error);
        showNotice(translate("Could not load this group:") + ` ${error.message}`, true);
        return;
    }
    group.unread_count = 0;
    renderStudents();
    void markGroupRead(supabase, group.id);
}

function markGroupHeaders() {
    const isGroup = Boolean(activeCommunity);
    elements.chatName.classList.toggle("is-group", isGroup);
    elements.chatStatus.classList.toggle("is-group", isGroup);
}

function openGroupPicker(mode, group) {
    if (!currentUser) {
        window.location.assign("/");
        return;
    }
    groupPickerMode = mode;
    groupPickerTarget = mode === "add" ? group : null;
    groupPickedIds.clear();
    groupMemberSearch.value = "";
    const adding = mode === "add";
    groupNameField.closest(".sheet-field").classList.toggle("hidden", adding);
    groupCreateDialogTitle.textContent = translate(adding ? "Add people" : "New group");
    groupCreateSaveButton.textContent = translate(adding ? "Add people" : "Create group");
    groupCreateSaveButton.disabled = true;
    renderGroupPicked();
    renderGroupMemberPicker("");
    groupCreateDialog.showModal();
    if (adding) groupMemberSearch.focus();
    else groupNameField.focus();
}

function renderGroupPicked() {
    const count = groupPickedIds.size;
    groupPickedLine.textContent = count
        ? `${count} ${translate("people selected")}`
        : translate("Pick the people to put in the group.");
    const named = groupNameField.value.trim().length >= 3;
    groupCreateSaveButton.disabled = groupPickerMode === "add" ? !count : !(named && count);
}

function groupPickerPool(query) {
    const term = normalizeMemberSearch(query).toLowerCase();
    const pool = allStudents.filter(student =>
        !blockedStudentIds.has(student.id) &&
        (student.is_discoverable || followerStudentIds.has(student.id)) &&
        memberMatchesSearch(student, term));
    if (groupPickerMode === "add" && groupPickerTarget) {
        const inside = new Set(groupMemberCache.map(member => member.user_id));
        inside.add(currentUser.id);
        return pool.filter(student => !inside.has(student.id));
    }
    return pool;
}

function groupPickerRow(student) {
    const row = document.createElement("button");
    row.type = "button";
    row.className = "new-chat-row";
    row.setAttribute("aria-pressed", String(groupPickedIds.has(student.id)));
    const avatar = document.createElement("span");
    avatar.className = "avatar";
    setAvatarContent(avatar, student);
    const text = document.createElement("span");
    const name = document.createElement("strong");
    name.textContent = studentName(student);
    appendRoleBadge(name, student);
    const detail = document.createElement("small");
    detail.textContent = [student.course, student.username ? `@${student.username}` : ""]
        .filter(Boolean).join(" · ") || translate("Tap to add");
    text.append(name, detail);
    const check = document.createElement("span");
    check.className = "member-check";
    check.textContent = groupPickedIds.has(student.id) ? "✓" : "";
    row.append(avatar, text, check);
    row.addEventListener("click", () => {
        if (groupPickedIds.has(student.id)) groupPickedIds.delete(student.id);
        else if (groupPickedIds.size < MAX_GROUP_MEMBERS) groupPickedIds.add(student.id);
        row.setAttribute("aria-pressed", String(groupPickedIds.has(student.id)));
        check.textContent = groupPickedIds.has(student.id) ? "✓" : "";
        renderGroupPicked();
    });
    return row;
}

function renderGroupMemberPicker(query) {
    groupMemberBody.replaceChildren();
    const pool = groupPickerPool(query)
        .sort((a, b) => studentName(a).localeCompare(studentName(b)));
    if (!pool.length) {
        const empty = document.createElement("p");
        empty.className = "empty-state";
        empty.textContent = translate(
            "Nobody matches that name. Group members are people you can already find.");
        groupMemberBody.appendChild(empty);
        return;
    }
    /* The people you actually chat with come first: a group is usually made of
       faces you text every day, not the whole register. */
    const frequent = pool.filter(student => isChatContact(student));
    const rest = pool.filter(student => !isChatContact(student));
    const sections = [];
    if (frequent.length) sections.push([translate("Frequently contacted"), frequent]);
    if (rest.length) sections.push([translate("All contacts"), rest]);
    for (const [title, list] of sections) {
        const heading = document.createElement("p");
        heading.className = "calls-section-title";
        heading.textContent = title;
        groupMemberBody.appendChild(heading);
        for (const student of list) groupMemberBody.appendChild(groupPickerRow(student));
    }
}

async function submitGroupPicker() {
    groupCreateSaveButton.disabled = true;
    try {
        if (groupPickerMode === "add") {
            const total = await addGroupMembers(supabase, groupPickerTarget.id, [...groupPickedIds]);
            groupCreateDialog.close();
            if (total) groupPickerTarget.member_count = Number(total);
            groupInfoCount.textContent = groupMemberLine(groupPickerTarget);
            void reloadGroupMembers(groupPickerTarget);
            showNotice(translate("People added to the group."));
        } else {
            const name = groupNameField.value.trim();
            if (name.length < 3 || name.length > 80) {
                showNotice(translate("Group names must be between 3 and 80 characters."), true);
                return;
            }
            const id = await createGroup(supabase, name, [...groupPickedIds]);
            groupCreateDialog.close();
            groupNameField.value = "";
            await refreshGroups();
            const group = groupById(id);
            renderStudents();
            if (group) void openGroupChat(group);
        }
    } catch (error) {
        console.error("Could not build the group:", error);
        showNotice(isMissingGroupObjects(error)
            ? `${translate("Groups need the newest database update.")} ${translate("Paste database/RUN_ALL.sql in Supabase.")}`
            : `${translate("Could not create the group:")} ${error.message}`, true);
    } finally {
        groupCreateSaveButton.disabled = false;
    }
}

async function openGroupInfo() {
    const group = activeCommunity;
    if (!group) return;
    groupInfoNotice.textContent = "";
    groupInfoName.textContent = group.name;
    groupInfoNameField.value = group.name;
    groupInfoCount.textContent = groupMemberLine(group);
    const canManage = group.my_role === "owner" || group.my_role === "admin";
    groupInfoAdmin.classList.toggle("hidden", !canManage);
    groupInfoDeleteButton.classList.toggle("hidden", group.my_role !== "owner");
    groupInfoLeaveButton.classList.toggle("hidden", group.my_role === "owner");
    groupInfoMembers.replaceChildren();
    const loading = document.createElement("p");
    loading.className = "empty-state";
    loading.textContent = translate("Loading members…");
    groupInfoMembers.appendChild(loading);
    groupInfoDialog.showModal();
    await reloadGroupMembers(group);
}

async function reloadGroupMembers(group) {
    try {
        groupMemberCache = await loadGroupMembers(supabase, group.id);
        group.member_count = groupMemberCache.length || group.member_count;
        groupInfoCount.textContent = groupMemberLine(group);
        renderGroupInfoMembers(group);
    } catch (error) {
        console.error("Could not load group members:", error);
        groupInfoNotice.textContent = `${translate("Could not load the members:")}${error.message}`;
    }
}

function renderGroupInfoMembers(group) {
    groupInfoMembers.replaceChildren();
    const canManage = group.my_role === "owner" || group.my_role === "admin";
    for (const member of groupMemberCache) {
        const row = document.createElement("div");
        row.className = "new-chat-row";
        const avatar = document.createElement("span");
        avatar.className = "avatar";
        setAvatarContent(avatar, member.profile || {});
        const text = document.createElement("span");
        const name = document.createElement("strong");
        name.textContent = member.user_id === currentUser.id
            ? translate("You")
            : member.profile
                ? (member.profile.full_name || member.profile.username || translate("Member"))
                : translate("Member");
        const tag = document.createElement("small");
        tag.className = "group-role-tag";
        tag.textContent = member.role === "owner"
            ? translate("Owner")
            : member.role === "admin" ? translate("Admin") : "";
        text.append(name, tag);
        row.append(avatar, text);
        if (canManage && member.role !== "owner" && member.user_id !== currentUser.id) {
            const remove = document.createElement("button");
            remove.type = "button";
            remove.className = "remove-member-button";
            remove.textContent = translate("Remove");
            remove.addEventListener("click", () => void removeGroupMember(group, member));
            row.appendChild(remove);
        }
        groupInfoMembers.appendChild(row);
    }
    if (!groupMemberCache.length) {
        const empty = document.createElement("p");
        empty.className = "empty-state";
        empty.textContent = translate("No members to show.");
        groupInfoMembers.appendChild(empty);
    }
}

async function removeGroupMember(group, member) {
    const { error } = await supabase
        .from("community_members")
        .delete()
        .eq("community_id", group.id)
        .eq("user_id", member.user_id);
    if (error) {
        groupInfoNotice.textContent = `${translate("Could not remove that member:")}${error.message}`;
        return;
    }
    groupMemberCache = groupMemberCache.filter(item => item.user_id !== member.user_id);
    group.member_count = groupMemberCache.length;
    groupInfoCount.textContent = groupMemberLine(group);
    renderGroupInfoMembers(group);
    renderStudents();
}

async function renameGroup(group) {
    const name = groupInfoNameField.value.trim();
    if (name.length < 3 || name.length > 80) {
        groupInfoNotice.textContent = translate("Group names must be between 3 and 80 characters.");
        return;
    }
    const { error } = await supabase.from("communities")
        .update({ name })
        .eq("id", group.id);
    if (error) {
        groupInfoNotice.textContent = `${translate("Could not rename the group:")}${error.message}`;
        return;
    }
    group.name = name;
    groupInfoName.textContent = name;
    elements.chatName.textContent = name;
    groupInfoNotice.textContent = translate("Group renamed.");
    renderStudents();
}

async function leaveGroup(group) {
    const { error } = await supabase
        .from("community_members")
        .delete()
        .eq("community_id", group.id)
        .eq("user_id", currentUser.id);
    if (error) {
        groupInfoNotice.textContent = `${translate("Could not leave the group:")}${error.message}`;
        return;
    }
    groupInfoDialog.close();
    myGroups = myGroups.filter(item => item.id !== group.id);
    if (activeCommunity?.id === group.id) {
        activeCommunity = null;
        markGroupHeaders();
        elements.messaging.classList.remove("chat-open");
        renderEmptyMessage(translate("Choose a student"));
    }
    renderStudents();
    showNotice(translate("You left the group."));
}

async function deleteGroup(group) {
    const { error } = await supabase.from("communities")
        .delete()
        .eq("id", group.id);
    if (error) {
        groupInfoNotice.textContent = `${translate("Could not delete the group:")}${error.message}`;
        return;
    }
    groupInfoDialog.close();
    myGroups = myGroups.filter(item => item.id !== group.id);
    if (activeCommunity?.id === group.id) {
        activeCommunity = null;
        markGroupHeaders();
        elements.messaging.classList.remove("chat-open");
        renderEmptyMessage(translate("Choose a student"));
    }
    renderStudents();
    showNotice(translate("Group deleted."));
}


function conversationPreview(conversation) {
    const message = conversation?.latest;
    if (!message) return "";
    const prefix = message.sender_id === currentUser?.id ? "You: " : "";
    const media = message.media_url || "";
    if (/voice-message-/i.test(media)) return `${prefix}🎤 Voice message`;
    if (/\.(avif|bmp|gif|jpe?g|png|svg|webp)(\?.*)?$/i.test(media)) return `${prefix}📷 Photo`;
    if (/\.(mp4|webm|ogg|mov)(\?.*)?$/i.test(media)) return `${prefix}🎥 Video`;
    if (media) return `${prefix}📎 ${decodeURIComponent(media.split("?")[0].split("/").pop() || "Attachment")}`;
    return `${prefix}${(message.content || "").replace(/\s+/g, " ").trim()}`;
}

function formatListTime(value) {
    const timestamp = new Date(value);
    if (!Number.isFinite(timestamp.getTime())) return "";
    const startOfToday = new Date();
    startOfToday.setHours(0, 0, 0, 0);
    const startOfDay = new Date(timestamp);
    startOfDay.setHours(0, 0, 0, 0);
    const days = Math.round((startOfToday.getTime() - startOfDay.getTime()) / 86_400_000);
    if (days === 0) return formatTime(timestamp);
    if (days === 1) return translate("Yesterday");
    if (days < 7) return new Intl.DateTimeFormat(undefined, { weekday: "short" }).format(timestamp);
    return new Intl.DateTimeFormat(undefined, { day: "2-digit", month: "2-digit", year: "numeric" }).format(timestamp);
}

function presenceText(lastSeenAt) {
    if (!lastSeenAt) return "";
    const timestamp = new Date(lastSeenAt);
    if (!Number.isFinite(timestamp.getTime())) return "";
    return Date.now() - timestamp.getTime() < 2 * 60 * 1000
        ? translate("Online")
        : `${translate("Last seen")}: ${timestamp.toLocaleString()}`;
}

function refreshChatStatus() {
    if (!activeStudent) return;
    if (peerActivity) {
        elements.chatStatus.textContent = activityText(peerActivity);
        return;
    }
    elements.chatStatus.textContent =
        presenceText(lastSeenByStudent.get(activeStudent.id)) ||
        translate("Only profile pictures are shown in chats.");
}

function closeChatActivity() {
    if (chatActivity) chatActivity.dispose();
    chatActivity = null;
    peerActivity = "";
}

function openChatActivity(peerId) {
    closeChatActivity();
    if (!supabase || !currentUser) return;
    chatActivity = createChatActivity({
        supabase,
        user: currentUser,
        peerId,
        onActivity: state => {
            peerActivity = state;
            refreshChatStatus();
        }
    });
}

async function toggleFollow(student) {
    const isFollowing = followingStudentIds.has(student.id);
    const followsCurrentUser = followerStudentIds.has(student.id);
    try {
        const result = isFollowing
            ? await supabase.from("follows").delete()
                .eq("follower_id", currentUser.id)
                .eq("following_id", student.id)
            : await supabase.from("follows").insert({
                follower_id: currentUser.id,
                following_id: student.id
            });
        if (result.error) throw result.error;
        if (isFollowing) {
            followingStudentIds.delete(student.id);
            pendingChatInviteIds.delete(student.id);
            persistPendingChatInvites();
        } else {
            followingStudentIds.add(student.id);
            if (followsCurrentUser) {
                pendingChatInviteIds.delete(student.id);
                persistPendingChatInvites();
            } else {
                pendingChatInviteIds.add(student.id);
                persistPendingChatInvites();
            }
        }
        renderStudents();
        if (!isFollowing && followsCurrentUser) {
            void openConversation(student);
        } else if (!isFollowing) {
            showNotice(translate(
                "Chat invitation sent. The conversation will open when they follow you back."
            ));
        }
    } catch (error) {
        console.error("Could not update connection:", error);
        showNotice(`Could not update connection: ${error.message}`, true);
        renderStudents();
    }
}

async function respondToInvitation(student, accept) {
    try {
        const { error } = await supabase.rpc("respond_to_chat_invitation", {
            p_inviter_id: student.id,
            p_accept: accept
        });
        if (error && accept && isMissingMigrationObject(error)) {
            // Keep accepting invitations compatible with deployments that
            // have not yet installed the optional decline RPC migration.
            const fallback = await supabase.from("follows").insert({
                follower_id: currentUser.id,
                following_id: student.id
            });
            if (fallback.error) throw fallback.error;
        } else if (error) {
            if (!accept && isMissingMigrationObject(error)) {
                throw new Error(
                    "Declining invitations requires database/migrations/20261012_respond_to_chat_invitations.sql to be applied in Supabase."
                );
            }
            throw error;
        }

        if (accept) {
            followingStudentIds.add(student.id);
            pendingChatInviteIds.delete(student.id);
            persistPendingChatInvites();
            renderStudents();
            await openConversation(student);
        } else {
            followerStudentIds.delete(student.id);
            renderStudents();
            showNotice(translate("Invitation declined."));
        }
    } catch (error) {
        console.error("Could not respond to chat invitation:", error);
        showNotice(`Could not respond to invitation: ${error.message}`, true);
        renderStudents();
    }
}

async function toggleBlock(student) {
    if (!socialAccessMigrationReady) {
        showMigrationWarning();
        return;
    }
    const isBlocked = blockedStudentIds.has(student.id);
    /* A phone cannot show window.confirm, so the question is asked with the
       same in-app sheet the chat menu uses. */
    if (!isBlocked) {
        const confirmed = await askChatConfirm({
            title: "Block this member?",
            body: `${studentName(student)} will not be able to message, call, or view your private posts and statuses.`,
            confirmLabel: "Block",
            danger: true
        });
        if (!confirmed) return;
    }

    try {
        const result = isBlocked
            ? await supabase.from("user_blocks").delete()
                .eq("blocker_id", currentUser.id)
                .eq("blocked_id", student.id)
            : await supabase.from("user_blocks").insert({
                blocker_id: currentUser.id,
                blocked_id: student.id
            });
        if (result.error) throw result.error;

        if (isBlocked) {
            blockedStudentIds.delete(student.id);
            if (!allStudents.some(profile => profile.id === student.id)) {
                allStudents.push(student);
            }
        } else {
            blockedStudentIds.add(student.id);
            if (activeStudent?.id === student.id) {
                activeStudent = null;
                resetVoiceMessage();
                elements.messaging.classList.remove("chat-open");
                elements.callActions.classList.add("hidden");
                renameContactButton.classList.add("hidden");
                renderEmptyMessage("This member is blocked.");
            }
        }
        await renderBlockedMembers();
        renderStudents();
        applyAccessMode();
        showNotice("");
    } catch (error) {
        console.error("Could not update blocked members:", error);
        showNotice(`Could not update blocked members: ${error.message}`, true);
    }
}

async function renderBlockedMembers() {
    const { data: profiles, error } = await supabase.rpc("get_blocked_profiles");
    if (error && isMissingMigrationObject(error)) {
        blockedMembersList.textContent = translate("Apply the social access controls database update first.");
        return;
    }
    if (error) {
        reportPartialLoadFailure("the blocked member list", error);
        blockedMembersList.textContent = translate("Blocked members are unavailable.");
        return;
    }
    blockedStudentIds = new Set((profiles || []).map(profile => profile.id));
    blockedMembersList.replaceChildren();
    if (!profiles?.length) {
        const empty = document.createElement("p");
        empty.className = "muted";
        empty.textContent = translate("No blocked members.");
        blockedMembersList.appendChild(empty);
        return;
    }

    for (const profile of profiles) {
        const row = document.createElement("div");
        row.className = "blocked-member";
        const name = document.createElement("span");
        name.textContent = studentName(profile);
        const button = document.createElement("button");
        button.type = "button";
        button.textContent = translate("Unblock");
        button.addEventListener("click", () => void toggleBlock(profile));
        row.append(name, button);
        blockedMembersList.appendChild(row);
    }
}

function toggleFavorite(studentId) {
    if (favoriteStudentIds.has(studentId)) {
        favoriteStudentIds.delete(studentId);
    } else {
        favoriteStudentIds.add(studentId);
    }

    try {
        localStorage.setItem(favoriteStorageKey, JSON.stringify([...favoriteStudentIds]));
    } catch (error) {
        console.error("Could not save favorite chats:", error);
        showNotice(`Could not save favorite chats: ${error.message}`, true);
    }
    renderStudents();
}

function createStudentContactLinks(student, className) {
    const links = document.createElement("div");
    links.className = className;
    let hasLinks = false;
    const email = student.share_email &&
        /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(student.contact_email?.trim() || "")
        ? student.contact_email.trim()
        : "";
    const phone = student.share_phone
        ? (student.contact_phone?.trim() || "").replace(/[\s().-]/g, "")
        : "";

    if (email) {
        const link = document.createElement("a");
        link.href = `mailto:${encodeURIComponent(email).replace(/%40/gi, "@")}`;
        link.textContent = `✉ ${translate("Email")}`;
        link.setAttribute("aria-label", translate("Email"));
        links.appendChild(link);
        hasLinks = true;
    }

    if (phone) {
        if (/^\+?\d{7,15}$/.test(phone)) {
            const link = document.createElement("a");
            link.href = `tel:${phone}`;
            link.textContent = `☎ ${translate("Phone")}`;
            link.setAttribute("aria-label", translate("Phone"));
            links.appendChild(link);
            hasLinks = true;
        }
    }

    return hasLinks ? links : null;
}

function renderCallDirectory(studentList = students) {
    if (!callDirectory || !elements.messaging.classList.contains("show-calls")) return;
    const query = normalizeMemberSearch(callsSearch.value).toLowerCase();
    const filteredStudents = studentList.filter(student =>
        student.is_discoverable &&
        !blockedStudentIds.has(student.id) &&
        (memberMatchesSearch(student, query) || findByPhone([student], query).length > 0) &&
        (!callsGenderSearch.value || student.gender === callsGenderSearch.value)
    );
    callDirectory.replaceChildren();

    if (!filteredStudents.length) {
        const empty = document.createElement("p");
        empty.className = "empty-state";
        empty.textContent = translate(callsPickerMode === "favorites"
            ? "No favorite contacts to call yet."
            : studentList.length
                ? "No members match that search."
                : "No other accounts yet. Invite someone to join Campus Connect.");
        callDirectory.appendChild(empty);
        return;
    }

    for (const student of filteredStudents) {
        const row = document.createElement("article");
        row.className = "call-contact";

        const avatar = document.createElement("span");
        avatar.className = "avatar";
        avatar.setAttribute("aria-hidden", "true");
        setAvatarContent(avatar, student);

        const info = document.createElement("div");
        info.className = "call-contact-info";
        const name = document.createElement("div");
        name.className = "call-contact-name";
        name.textContent = studentName(student);
        const username = document.createElement("div");
        username.className = "call-contact-username";
        username.textContent = genderLabel(student.gender);
        info.append(name, username);

        const actions = document.createElement("div");
        actions.className = "call-contact-actions";
        for (const [mode, text, label] of [
            ["voice", "☎ Voice", "Start voice call"],
            ["video", "▣ Video", "Start video call"]
        ]) {
            const button = document.createElement("button");
            button.type = "button";
            button.textContent = translate(text);
            button.setAttribute("aria-label", translate(label));
            button.addEventListener("click", () => {
                if (!callManager) {
                    showNotice("Calls are not ready yet.", true);
                    return;
                }
                void callManager.startCallWith(student, mode);
            });
            actions.appendChild(button);
        }
        const contactLinks = createStudentContactLinks(student, "call-contact-actions");
        if (contactLinks) actions.append(...contactLinks.childNodes);

        row.append(avatar, info, actions);
        callDirectory.appendChild(row);
    }
}

const CALL_ICONS = {
    out: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 18 18 6M18 6h-7M18 6v7"/></svg>',
    in: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M18 6 6 18M6 18v-7M6 18h7"/></svg>'
};

const DIAL_KEYS = [
    ["1", ""], ["2", "ABC"], ["3", "DEF"],
    ["4", "GHI"], ["5", "JKL"], ["6", "MNO"],
    ["7", "PQRS"], ["8", "TUV"], ["9", "WXYZ"],
    ["+", ""], ["0", ""], ["#", ""]
];

let callsPickerMode = "all";
let dialMatch = null;

function digitsOnly(value) {
    return String(value || "").replace(/\D/g, "");
}

function normalizePhoneNumber(value) {
    const trimmed = String(value || "").trim();
    return (trimmed.startsWith("+") ? "+" : "") + digitsOnly(trimmed);
}

/* Numbers are kept in many shapes (+2547…, 07…, 2547…), so both sides are
   folded to digits first. An exact match wins; otherwise the last nine digits
   decide, which is stable across those formats. A saved number is matched even
   when its owner hides it from the profile card, because having someone's
   number in your phone is what opens a chat with them. */
function findByPhone(list, query) {
    if (canonicalPhone(query).length < 7) return [];
    const exact = list.filter(student => samePhone(student.contact_phone, query));
    if (exact.length) return exact;
    const tail = digitsOnly(query).slice(-9);
    return list.filter(student => {
        const candidate = canonicalPhone(student.contact_phone);
        return candidate.length >= 9 && candidate.slice(-9) === tail;
    });
}

/* The loaded roster is only a page of profiles, so a number that is not in it
   still has to be answerable. The database looks the exact number up and hands
   back the profile card of the account that owns it; a database that has not
   been given that lookup simply returns nothing and the phone keeps matching
   against the loaded list alone. */
let phoneLookupAvailable = true;

async function findMemberByPhone(query) {
    const local = findByPhone(allStudents, query);
    if (local.length || !phoneLookupAvailable || !currentUser) return local;
    const phone = canonicalPhone(query);
    if (phone.length < 7) return local;
    const { data, error } = await supabase.rpc("find_member_by_phone", { p_phone: phone });
    if (error) {
        if (isMissingMigrationObject(error)) phoneLookupAvailable = false;
        else reportPartialLoadFailure("the phone number search", error);
        return local;
    }
    const found = data || [];
    for (const profile of found) {
        if (!allStudents.some(student => student.id === profile.id)) {
            allStudents.push(profile);
        }
    }
    return found;
}

function formatCallDuration(ms) {
    const total = Math.max(0, Math.round(Number(ms) / 1000));
    const minutes = Math.floor(total / 60);
    const seconds = total % 60;
    return `${minutes}:${String(seconds).padStart(2, "0")}`;
}

function formatWhen(at) {
    const date = new Date(Number(at));
    const time = date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    if (date.toDateString() === new Date().toDateString()) return time;
    return `${date.toLocaleDateString([], { weekday: "short", day: "numeric", month: "short" })} · ${time}`;
}

function callOutcomeLabel(entry) {
    const kind = entry.mode === "video" ? "video call" : "voice call";
    if (entry.outcome === "missed") return translate(`Missed ${kind}`);
    if (entry.direction === "out" && ["unanswered", "declined", "busy"].includes(entry.outcome)) {
        return translate(`Outgoing ${kind}`);
    }
    if (entry.outcome === "declined") return translate(`Declined ${kind}`);
    if (entry.outcome === "failed") return translate(`Failed ${kind}`);
    if (entry.durationMs) return `${translate(kind)} · ${formatCallDuration(entry.durationMs)}`;
    return translate(kind);
}

function callRowAvatar(container, peerId, peerName) {
    const student = allStudents.find(item => item.id === peerId);
    if (student) {
        setAvatarContent(container, student);
        return student;
    }
    container.classList.add("avatar-fallback");
    container.textContent = (peerName || "?").trim().charAt(0).toUpperCase() || "?";
    return null;
}

function callActionButtons(peerId, mode) {
    const actions = document.createElement("span");
    actions.className = "call-row-actions";
    for (const [kind, label, path] of [
        ["video", "Start video call", "M3 6.5h11v11H3zM14 10.5l7-3.5v10l-7-3.5z"],
        ["voice", "Start voice call", "M7.2 3.5 10 7.2 8.4 9.5a15 15 0 0 0 6.1 6.1l2.3-1.6 3.7 2.8-.8 3.3a2 2 0 0 1-2.1 1.5A17.5 17.5 0 0 1 2.4 6.1a2 2 0 0 1 1.5-2.1l3.3-.5Z"]
    ]) {
        if (mode && kind !== mode) continue;
        const button = document.createElement("button");
        button.type = "button";
        button.setAttribute("aria-label", translate(label));
        button.setAttribute("title", translate(label));
        button.innerHTML = `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="${path}"/></svg>`;
        button.addEventListener("click", () => {
            const student = allStudents.find(item => item.id === peerId);
            if (!student) {
                showNotice("That contact is no longer available in Campus Connect.", true);
                return;
            }
            if (!callManager) {
                showNotice("Calls are not ready yet.", true);
                return;
            }
            void callManager.startCallWith(student, kind);
        });
        actions.appendChild(button);
    }
    return actions;
}

function callHistoryRow(entry) {
    const row = document.createElement("div");
    row.className = "call-row";

    const main = document.createElement("button");
    main.type = "button";
    main.className = "call-row-main";

    const avatar = document.createElement("span");
    avatar.className = "avatar";
    const student = callRowAvatar(avatar, entry.peerId, entry.peerName);

    const text = document.createElement("span");
    text.className = "call-row-text";
    const name = document.createElement("span");
    name.className = "call-row-name";
    name.textContent = student ? studentName(student) : (entry.peerName || translate("Unknown caller"));
    if (entry.count > 1) {
        const count = document.createElement("span");
        count.className = "call-count";
        count.textContent = ` (${entry.count})`;
        name.appendChild(count);
    }
    const meta = document.createElement("span");
    meta.className = "call-row-meta";
    if (entry.outcome === "missed") meta.classList.add("missed");
    const icon = document.createElement("span");
    icon.className = "call-dir";
    icon.innerHTML = CALL_ICONS[entry.direction] || CALL_ICONS.out;
    const label = document.createElement("span");
    label.textContent = callOutcomeLabel(entry);
    const stamp = document.createElement("span");
    stamp.textContent = `· ${formatListTime(entry.at)}`;
    meta.append(icon, label, stamp);
    text.append(name, meta);
    main.append(avatar, text);
    main.addEventListener("click", () => {
        if (!student) {
            showNotice("That contact is no longer available in Campus Connect.", true);
            return;
        }
        void openConversation(student);
    });

    row.append(main, callActionButtons(entry.peerId, null));
    return row;
}

function scheduledCallRow(item) {
    const row = document.createElement("div");
    row.className = "call-row";

    const main = document.createElement("div");
    main.className = "call-row-main";
    const avatar = document.createElement("span");
    avatar.className = "avatar";
    callRowAvatar(avatar, item.peerId, item.peerName);
    const text = document.createElement("span");
    text.className = "call-row-text";
    const name = document.createElement("span");
    name.className = "call-row-name";
    name.textContent = item.peerName || translate("Unknown caller");
    const meta = document.createElement("span");
    meta.className = "call-row-meta";
    meta.textContent = `${translate("Scheduled")} · ${formatWhen(item.at)}`;
    text.append(name, meta);
    main.append(avatar, text);

    const cancel = document.createElement("button");
    cancel.type = "button";
    cancel.setAttribute("aria-label", translate("Cancel scheduled call"));
    cancel.setAttribute("title", translate("Cancel scheduled call"));
    cancel.textContent = "×";
    cancel.addEventListener("click", () => {
        removeScheduledCall(currentUser.id, item.id);
        showNotice(translate("Call reminder removed."));
    });

    row.append(main, cancel);
    return row;
}

function renderCallHistory() {
    if (!callHistory) return;
    callHistory.replaceChildren();
    if (!currentUser) return;

    const upcoming = loadScheduledCalls(currentUser.id).filter(item => item.at > Date.now());
    for (const item of upcoming.slice(0, 5)) callHistory.appendChild(scheduledCallRow(item));

    const groups = groupCallEntries(loadCallEntries(currentUser.id)).slice(0, 40);
    if (!groups.length && !upcoming.length) {
        const empty = document.createElement("p");
        empty.className = "empty-state";
        empty.textContent = translate("No calls yet. Tap Call to start one.");
        callHistory.appendChild(empty);
        return;
    }
    for (const group of groups) callHistory.appendChild(callHistoryRow(group));
}

/* The misses the native watch kept while this page was asleep, folded into the
   log the Calls list already reads. Asked for once, after the page is up: on the
   website and the iPhone there is no watch and the answer is null, so nothing
   arrives and nothing changes. */
async function refreshNativeMisses() {
    if (!currentUser) return;
    const misses = await callWatchMissedCalls();
    if (!misses?.length) return;
    mergeNativeMisses(currentUser.id, misses);
}

function toggleCallsPicker(open, favoritesOnly = false) {
    callsPickerMode = favoritesOnly ? "favorites" : "all";
    callsPicker.classList.toggle("open", open);
    callsAddButton.setAttribute("aria-expanded", String(open));
    if (open) {
        renderCallDirectory(visibleCallContacts());
        callsSearch.focus();
    }
}

function visibleCallContacts() {
    const base = allStudents.filter(student =>
        student.is_discoverable && !blockedStudentIds.has(student.id) &&
        !hiddenByRolePrivacy(student));
    return callsPickerMode === "favorites"
        ? base.filter(student => favoriteStudentIds.has(student.id))
        : base;
}

function startScheduledCallTimer() {
    window.setInterval(() => {
        if (!currentUser || document.visibilityState !== "visible") return;
        const due = dueScheduledCalls(currentUser.id);
        if (!due.length) return;
        for (const item of due) {
            removeScheduledCall(currentUser.id, item.id);
            showNotice(`${translate("Call reminder")}: ${item.peerName || translate("Unknown caller")}.`);
        }
        if (elements.messaging.classList.contains("show-calls")) renderCallHistory();
    }, 30000);
}

function buildDialKeys() {
    dialPad.replaceChildren();
    for (const [digit, letters] of DIAL_KEYS) {
        const button = document.createElement("button");
        button.type = "button";
        button.dataset.digit = digit;
        button.textContent = digit;
        if (letters) {
            const small = document.createElement("small");
            small.textContent = letters;
            button.appendChild(small);
        }
        dialPad.appendChild(button);
    }
}

/* Typing on the pad fires one lookup per key, so only the last answer is
   allowed to touch the screen. A number that belongs to a member turns the Call
   button into a Campus Connect call; a number that belongs to nobody still
   dials the phone, because that is the only honest answer left. */
let dialSeq = 0;

function showDialMatch(student) {
    dialMatch = student;
    dialCallLink.href = "#";
    dialCallLink.dataset.i18n = "Call in Campus Connect";
    dialCallLink.textContent = translate("Call in Campus Connect");
    dialResult.textContent = `${studentName(student)} · ${translate("is on Campus Connect")}`;
}

function showNoDialAccount(digits) {
    dialCallLink.href = `tel:${normalizePhoneNumber(digits)}`;
    dialCallLink.dataset.i18n = "Call by phone";
    dialCallLink.textContent = translate("Call by phone");
    dialResult.textContent = currentUser?.username
        ? translate("No account yet. Use Find to send an invite by WhatsApp or SMS.")
        : translate("No Campus Connect account found for that number.");
}

async function syncDial() {
    const raw = normalizePhoneNumber(dialDisplay.value);
    const digits = digitsOnly(raw);
    const seq = ++dialSeq;
    dialMatch = null;
    dialCallLink.href = digits ? `tel:${raw}` : "#";
    dialCallLink.dataset.i18n = "Call by phone";
    dialCallLink.textContent = translate("Call by phone");

    if (!digits) {
        dialResult.textContent = translate("Enter a phone number.");
        return;
    }
    if (digits.length < 7) {
        dialResult.textContent = translate("Keep typing the number.");
        return;
    }

    const local = findByPhone(allStudents, digits);
    if (local.length) {
        showDialMatch(local[0]);
        return;
    }
    const matches = await findMemberByPhone(digits);
    if (seq !== dialSeq) return;
    if (matches.length) showDialMatch(matches[0]);
    else showNoDialAccount(digits);
}

function startDialCall() {
    if (!dialMatch) return;
    if (!callManager) {
        showNotice(translate("Calls are not ready yet."), true);
        return;
    }
    keypadDialog.close();
    void callManager.startCallWith(dialMatch, "voice");
}

async function inviteByPhone() {
    const raw = normalizePhoneNumber(dialDisplay.value);
    const digits = digitsOnly(raw);
    if (digits.length < 7) {
        showNotice(translate("Enter a full phone number first."), true);
        return;
    }
    const matches = dialMatch ? [dialMatch] : await findMemberByPhone(digits);
    if (matches.length) {
        keypadDialog.close();
        void openConversation(matches[0]);
        return;
    }
    const link = buildInviteUrl(currentUser?.username || "");
    const message = `${translate("Chat with me on Campus Connect:")} ${link}`;
    const target = `https://wa.me/${digits}?text=${encodeURIComponent(message)}`;
    const opened = window.open(target, "_blank", "noopener");
    if (!opened) {
        void copyLink(link);
        showNotice(translate("Could not open WhatsApp. Your invite link was copied instead."));
        return;
    }
    showNotice(`${translate("Invite opened for")} ${raw}.`);
}

function openScheduleDialog(preselectedId = "") {
    if (!currentUser) return;
    const contacts = allStudents
        .filter(student => student.is_discoverable && !blockedStudentIds.has(student.id))
        .sort((a, b) => studentName(a).localeCompare(studentName(b)));

    scheduleCallContact.replaceChildren();
    for (const student of contacts) {
        const option = document.createElement("option");
        option.value = student.id;
        option.textContent = studentName(student);
        scheduleCallContact.appendChild(option);
    }
    if (preselectedId) scheduleCallContact.value = preselectedId;

    const soon = new Date(Date.now() + 30 * 60 * 1000);
    soon.setSeconds(0, 0);
    soon.setMinutes(Math.round(soon.getMinutes() / 5) * 5);
    const pad = value => String(value).padStart(2, "0");
    scheduleCallTime.value = `${soon.getFullYear()}-${pad(soon.getMonth() + 1)}-${pad(soon.getDate())}` +
        `T${pad(soon.getHours())}:${pad(soon.getMinutes())}`;
    scheduleCallDialog.showModal();
}

async function openNewChatSheet() {
    if (!currentUser) {
        window.location.assign("/");
        return;
    }
    newChatSearch.value = "";
    renderNewChatSheet("");
    newChatDialog.showModal();
    newChatSearch.focus();
}

function newChatRow(student) {
    const row = document.createElement("button");
    row.type = "button";
    row.className = "new-chat-row";
    const avatar = document.createElement("span");
    avatar.className = "avatar";
    setAvatarContent(avatar, student);
    const text = document.createElement("span");
    const name = document.createElement("strong");
    name.textContent = studentName(student);
    appendRoleBadge(name, student);
    const detail = document.createElement("small");
    detail.textContent = [student.course, student.username ? `@${student.username}` : ""]
        .filter(Boolean).join(" · ") || translate("Tap to chat");
    text.append(name, detail);
    row.append(avatar, text);
    row.addEventListener("click", () => {
        newChatDialog.close();
        void openConversation(student);
    });
    return row;
}

/* A number typed into the New chat search may belong to someone outside the
   loaded page of profiles, so the sheet asks the database too and only the last
   question it asked is allowed to redraw the list. */
let newChatSeq = 0;

function renderPhoneSection(term, matches, searching) {
    newChatBody.replaceChildren();
    newChatResult.textContent = "";

    const heading = document.createElement("p");
    heading.className = "calls-section-title";
    heading.textContent = translate("Phone number");
    newChatBody.appendChild(heading);

    if (searching) {
        const wait = document.createElement("p");
        wait.className = "empty-state";
        wait.textContent = translate("Looking for that number…");
        newChatBody.appendChild(wait);
        return;
    }
    if (matches.length) {
        for (const student of matches) newChatBody.appendChild(newChatRow(student));
        return;
    }
    const invite = document.createElement("button");
    invite.type = "button";
    invite.className = "new-chat-row";
    invite.textContent = `${translate("Invite")} ${normalizePhoneNumber(term)} ` +
        translate("to join Campus Connect");
    invite.addEventListener("click", () => {
        dialDisplay.value = term;
        newChatDialog.close();
        keypadDialog.showModal();
        syncDial();
    });
    newChatBody.appendChild(invite);
    newChatResult.textContent = translate(
        "The person needs a Campus Connect account before you can chat. Send them the invite link.");
}

function renderNewChatSheet(query) {
    const seq = ++newChatSeq;
    newChatBody.replaceChildren();
    newChatResult.textContent = "";

    const term = String(query || "").trim();
    const digits = digitsOnly(term);

    if (digits.length >= 7) {
        const local = findByPhone(allStudents, digits);
        if (local.length) {
            renderPhoneSection(term, local, false);
            return;
        }
        renderPhoneSection(term, [], true);
        void findMemberByPhone(digits).then(matches => {
            if (seq === newChatSeq) renderPhoneSection(term, matches, false);
        });
        return;
    }

    const pool = allStudents.filter(student =>
        student.is_discoverable &&
        !blockedStudentIds.has(student.id) &&
        memberMatchesSearch(student, term.toLowerCase()));

    if (!term) {
        const frequent = [...latestByStudent.entries()]
            .sort((a, b) => (b[1]?.latest?.created_at || "").localeCompare(a[1]?.latest?.created_at || ""))
            .map(([id]) => allStudents.find(student => student.id === id))
            .filter(Boolean)
            .slice(0, 6);
        if (frequent.length) {
            const heading = document.createElement("p");
            heading.className = "calls-section-title";
            heading.textContent = translate("Frequently contacted");
            newChatBody.appendChild(heading);
            for (const student of frequent) newChatBody.appendChild(newChatRow(student));
        }
    }

    const sorted = [...pool].sort((a, b) => studentName(a).localeCompare(studentName(b)));
    const heading = document.createElement("p");
    heading.className = "calls-section-title";
    heading.textContent = term ? translate("Matches") : translate("All contacts");
    newChatBody.appendChild(heading);

    if (!sorted.length) {
        const empty = document.createElement("p");
        empty.className = "empty-state";
        empty.textContent = translate("No contact matches that search.");
        newChatBody.appendChild(empty);
        return;
    }

    const letters = new Set();
    let currentLetter = "";
    for (const student of sorted) {
        const letter = (studentName(student).trim().charAt(0).toUpperCase() || "#");
        if (letter !== currentLetter) {
            currentLetter = letter;
            letters.add(letter);
            const groupHeading = document.createElement("p");
            groupHeading.className = "calls-section-title az-heading";
            groupHeading.id = `az-${letter}`;
            groupHeading.textContent = letter;
            newChatBody.appendChild(groupHeading);
        }
        newChatBody.appendChild(newChatRow(student));
    }

    const index = document.createElement("div");
    index.className = "az-index";
    for (const letter of "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("")) {
        const button = document.createElement("button");
        button.type = "button";
        button.textContent = letter;
        button.disabled = !letters.has(letter);
        button.addEventListener("click", () => {
            document.getElementById(`az-${letter}`)?.scrollIntoView({ block: "start" });
        });
        index.appendChild(button);
    }
    newChatBody.appendChild(index);
}

async function loadMessages(student) {
    const { data, error } = await selectMessages(columns => supabase
        .from("messages")
        .select(columns)
        .or(
            `and(sender_id.eq.${currentUser.id},receiver_id.eq.${student.id}),and(sender_id.eq.${student.id},receiver_id.eq.${currentUser.id})`
        )
        .order("created_at", { ascending: false })
        .order("id", { ascending: false })
        .limit(MESSAGES_PER_PAGE + 1));

    if (error) throw error;

    const recent = data || [];
    const hasMore = recent.length > MESSAGES_PER_PAGE;
    const messages = visibleForMe(recent.slice(0, MESSAGES_PER_PAGE).reverse(), student.id);
    /* A read receipt is tidy, not urgent. Awaiting it here would put a second
       round trip in front of the conversation the student is waiting to see. */
    if (latestByStudent.get(student.id)?.unread ||
        messages.some(message => message.receiver_id === currentUser.id && !message.is_read)) {
        void supabase
            .from("messages")
            .update({ is_read: true })
            .eq("receiver_id", currentUser.id)
            .eq("sender_id", student.id)
            .eq("is_read", false)
            .then(({ error: updateError }) => {
                if (updateError) console.warn("Messages could not be marked as read:", updateError);
            });
    }

    cacheConversationMessages(currentUser.id, student.id, messages);
    return { messages, hasMore };
}

async function loadOlderMessages() {
    if (isLoadingOlderMessages || !hasOlderMessages || !displayedMessages.length) return;
    if (activeCommunity) return loadOlderCommunityMessages();
    if (!activeStudent) return;
    const student = activeStudent;
    const loadId = conversationLoadId;
    const requestId = ++olderMessagesRequestId;
    const oldestMessage = displayedMessages.find(message => !message.id.startsWith("pending-"));
    if (!oldestMessage) return;

    isLoadingOlderMessages = true;
    try {
        const cursor = `created_at.lt.${oldestMessage.created_at},and(created_at.eq.${oldestMessage.created_at},id.lt.${oldestMessage.id})`;
        const { data, error } = await selectMessages(columns => supabase
            .from("messages")
            .select(columns)
            .or(
                `and(sender_id.eq.${currentUser.id},receiver_id.eq.${student.id},or(${cursor})),and(sender_id.eq.${student.id},receiver_id.eq.${currentUser.id},or(${cursor}))`
            )
            .order("created_at", { ascending: false })
            .order("id", { ascending: false })
            .limit(MESSAGES_PER_PAGE + 1));
        if (error) throw error;
        if (loadId !== conversationLoadId || activeStudent?.id !== student.id) return;

        const older = data || [];
        hasOlderMessages = older.length > MESSAGES_PER_PAGE;
        const olderPage = older.slice(0, MESSAGES_PER_PAGE);
        if (loadId !== conversationLoadId || activeStudent?.id !== student.id) return;
        const currentIds = new Set(displayedMessages.map(message => message.id));
        const newOlderMessages = visibleForMe(olderPage.reverse(), student.id)
            .filter(message => !currentIds.has(message.id));
        const currentHeight = elements.chatMessages.scrollHeight;
        const currentTop = elements.chatMessages.scrollTop;
        renderMessages([...newOlderMessages, ...displayedMessages]);
        elements.chatMessages.scrollTop =
            currentTop + elements.chatMessages.scrollHeight - currentHeight;
    } finally {
        if (requestId === olderMessagesRequestId) isLoadingOlderMessages = false;
    }
}

async function loadCommunityMessages(community, cursor) {
    /* The newest page first, then "load earlier" walks backwards. Ordering by
       created_at ascending used to hand back the OLDEST 500 messages of the
       group, so an active class group opened on last term's chatter with
       today's messages and the unread badge nowhere to be seen. */
    let query = supabase
        .from("community_messages")
        .select("id, sender_id, content, media_url, created_at")
        .eq("community_id", community.id)
        .order("created_at", { ascending: false })
        .order("id", { ascending: false })
        .limit(MESSAGES_PER_PAGE + 1);
    if (cursor) {
        query = query.or(
            `created_at.lt.${cursor.created_at},and(created_at.eq.${cursor.created_at},id.lt.${cursor.id})`
        );
    }
    const { data, error } = await query;
    if (error) throw error;

    const recent = data || [];
    const hasMore = recent.length > MESSAGES_PER_PAGE;
    const messages = recent.slice(0, MESSAGES_PER_PAGE);
    const senderIds = [...new Set(messages.map(message => message.sender_id))];
    const { data: profiles, error: profilesError } = senderIds.length
        ? await supabase.from("profiles").select("id, avatar_url").in("id", senderIds)
        : { data: [], error: null };
    if (profilesError) throw profilesError;
    const avatars = new Map((profiles || []).map(profile => [profile.id, profile.avatar_url]));
    return {
        hasMore,
        messages: messages.map(message => ({
            ...message,
            senderAvatar: avatars.get(message.sender_id)
        })).reverse()
    };
}

async function loadOlderCommunityMessages() {
    const group = activeCommunity;
    const loadId = conversationLoadId;
    const requestId = ++olderMessagesRequestId;
    const oldestMessage = displayedMessages.find(message => !message.id.startsWith("pending-"));
    if (!oldestMessage) return;

    isLoadingOlderMessages = true;
    try {
        const older = await loadCommunityMessages(group, oldestMessage);
        if (loadId !== conversationLoadId || activeCommunity?.id !== group.id) return;
        hasOlderMessages = older.hasMore;
        const currentIds = new Set(displayedMessages.map(message => message.id));
        const newOlderMessages = older.messages.filter(message => !currentIds.has(message.id));
        const currentHeight = elements.chatMessages.scrollHeight;
        const currentTop = elements.chatMessages.scrollTop;
        renderMessages([...newOlderMessages, ...displayedMessages]);
        elements.chatMessages.scrollTop =
            currentTop + elements.chatMessages.scrollHeight - currentHeight;
    } finally {
        if (requestId === olderMessagesRequestId) isLoadingOlderMessages = false;
    }
}

function appendCallLogRow(entry) {
    const row = document.createElement("article");
    row.className = `message ${entry.direction === "out" ? "sent" : "received"} call-log-row`;

    const bubble = document.createElement("div");
    bubble.className = "bubble";

    const line = document.createElement("div");
    line.className = "call-log-line";
    if (entry.outcome === "missed") line.classList.add("missed");

    const icon = document.createElement("span");
    icon.className = "call-dir";
    icon.innerHTML = CALL_ICONS[entry.direction] || CALL_ICONS.out;

    const kindIcon = document.createElement("span");
    kindIcon.className = "call-log-kind";
    kindIcon.setAttribute("aria-hidden", "true");
    kindIcon.textContent = entry.mode === "video" ? "📹" : "📞";

    const label = document.createElement("span");
    label.textContent = callOutcomeLabel(entry);

    line.append(icon, kindIcon, label);

    const time = document.createElement("time");
    time.className = "message-time";
    time.dateTime = new Date(Number(entry.at)).toISOString();
    time.textContent = formatTime(entry.at);

    bubble.append(line, time);
    row.appendChild(bubble);
    elements.chatMessages.appendChild(row);
}

function renderMessages(messages, forceScrollToBottom = false) {
    displayedMessages = visibleForMe(messages, activeStudent?.id || activeCommunity?.id);
    void hydrateInteractive(displayedMessages);
    const wasAtBottom =
        elements.chatMessages.scrollHeight -
        elements.chatMessages.scrollTop -
        elements.chatMessages.clientHeight < 80;
    stopVoicePlayback();
    elements.chatMessages.replaceChildren();

    // Calls are logged on this device, so they are woven into the thread by
    // timestamp instead of living in the messages table.
    const callEntries = activeStudent && !activeCommunity && currentUser
        ? callEntriesForPeer(currentUser.id, activeStudent.id)
        : [];
    let callPointer = 0;

    if (hasOlderMessages && (activeStudent || activeCommunity)) {
        const olderButton = document.createElement("button");
        olderButton.type = "button";
        olderButton.className = "load-older-messages";
        olderButton.textContent = translate("Load earlier messages");
        olderButton.addEventListener("click", async () => {
            olderButton.disabled = true;
            try {
                await loadOlderMessages();
            } catch (error) {
                console.error("Could not load earlier messages:", error);
                showNotice(`Could not load earlier messages: ${error.message}`, true);
                olderButton.disabled = false;
            }
        });
        elements.chatMessages.appendChild(olderButton);
    }

    if (!messages.length) {
        renderEmptyMessage(activeCommunity
            ? translate("Say hello to the group!")
            : translate("Say hello to your classmate!"));
        while (callPointer < callEntries.length) {
            appendCallLogRow(callEntries[callPointer]);
            callPointer += 1;
        }
        return;
    }

    let priorSenderId = null;
    for (const message of messages) {
        while (callPointer < callEntries.length &&
            Number(callEntries[callPointer].at) < Date.parse(message.created_at)) {
            appendCallLogRow(callEntries[callPointer]);
            callPointer += 1;
        }
        const row = document.createElement("article");
        const sent = message.sender_id === currentUser.id;
        row.className = `message ${sent ? "sent" : "received"}`;
        row.dataset.messageId = message.id;
        /* In a group the name over the bubble is the only thing that tells you
           who said it, and repeating it on every message of the same run would
           bury the conversation. */
        const showSender = !!activeCommunity && !sent && !message.deleted_for_everyone &&
            message.sender_id !== priorSenderId;

        const isVoice = !message.deleted_for_everyone && isVoiceUrl(message.media_url);

        const bubble = document.createElement("div");
        bubble.className = "bubble";
        if (messageMarks.isStarred(message.id)) bubble.classList.add("starred-message");
        if (message.deleted_for_everyone) {
            const gone = document.createElement("div");
            gone.className = "message-deleted";
            gone.textContent = translate("This message was deleted.");
            bubble.appendChild(gone);
        } else {
            if (message.reply_preview) bubble.appendChild(buildReplyQuote(message.reply_preview, sent));
            const shownContent = isViewOnceMessage(message) ? viewOnceCaption(message) : message.content;
            if (shownContent) {
                const content = document.createElement("div");
                content.textContent = shownContent;
                bubble.appendChild(content);
            }
            const media = isViewOnceMessage(message) && message.media_url
                ? buildViewOnceBubble(message)
                : createMediaElement(message.media_url);
            if (media) {
                if (media.classList.contains("message-media")) {
                    // Instagram's habit, borrowed: double-tap a picture to bless it.
                    media.addEventListener("dblclick", () => likeReaction(message));
                }
                bubble.appendChild(media);
            }
        }
        const time = document.createElement("time");
        time.className = "message-time";
        if (message.failed) {
            time.classList.add("failed");
            time.textContent = translate("Not delivered");
        } else if (message.pending) {
            time.textContent = translate("Sending…");
        } else {
            time.dateTime = message.created_at;
            time.textContent = formatTime(message.created_at);
            if (message.edited_at) {
                const edited = document.createElement("span");
                edited.className = "message-edited";
                edited.textContent = `· ${translate("edited")}`;
                time.appendChild(edited);
            }
            if (sent) {
                const ticks = document.createElement("span");
                ticks.className = message.is_read ? "message-ticks read" : "message-ticks";
                ticks.textContent = message.is_read ? "✓✓" : "✓";
                ticks.setAttribute("aria-label",
                    message.is_read ? translate("Read") : translate("Sent"));
                time.appendChild(ticks);
            }
        }
        bubble.appendChild(time);
        /* Only offer the tap when this device still holds the draft to resend;
           a stale marked bubble from the cache would otherwise do nothing. */
        if (message.failed && failedSends.has(message.id)) {
            bubble.classList.add("failed-message");
            bubble.title = translate("Tap to send again");
            bubble.addEventListener("click", () => void retryFailedSend(message.id));
        }
        const stack = document.createElement("div");
        stack.className = "message-stack";
        if (showSender) {
            const senderLine = document.createElement("div");
            senderLine.className = "message-sender";
            senderLine.textContent = senderLabel(message);
            senderLine.addEventListener("click", () => {
                const sender = allStudents.find(student => student.id === message.sender_id);
                if (sender) openMemberProfile(sender);
            });
            stack.appendChild(senderLine);
        }
        stack.appendChild(bubble);
        const reactionRow = buildReactionRow(message.id);
        if (reactionRow) stack.appendChild(reactionRow);
        const pollCard = message.deleted_for_everyone ? null : buildPollCard(message);
        if (pollCard) stack.appendChild(pollCard);
        row.appendChild(stack);

        if (!sent) {
            const showAvatar = isVoice || activeCommunity;
            if (showAvatar) {
                const messageAvatar = document.createElement("span");
                messageAvatar.className = isVoice ? "avatar voice-avatar" : "avatar message-avatar";
                setAvatarContent(messageAvatar, {
                    avatar_url: activeCommunity ? message.senderAvatar : activeStudent?.avatar_url
                });
                row.appendChild(messageAvatar);
            }
        }

        if (!message.pending && !message.deleted_for_everyone && activeStudent &&
            chatActionsAvailable) {
            const actions = document.createElement("button");
            actions.type = "button";
            actions.className = "message-actions-button";
            actions.setAttribute("aria-label", translate("Message options"));
            actions.textContent = "⋯";
            actions.addEventListener("click", () => openMessageMenu(message, bubble));
            row.appendChild(actions);
        }

        elements.chatMessages.appendChild(row);
        priorSenderId = message.sender_id;
    }

    while (callPointer < callEntries.length) {
        appendCallLogRow(callEntries[callPointer]);
        callPointer += 1;
    }

    void messageMarks.load(displayedMessages.map(message => message.id));

    if (forceScrollToBottom || wasAtBottom) {
        elements.chatMessages.scrollTop = elements.chatMessages.scrollHeight;
    }
}

function mergeCurrentMessages(recentMessages) {
    const messagesById = new Map(
        displayedMessages.map(message => [message.id, message])
    );
    for (const message of recentMessages) messagesById.set(message.id, message);
    return [...messagesById.values()].sort((left, right) =>
        left.created_at.localeCompare(right.created_at) || left.id.localeCompare(right.id)
    );
}

function patchDisplayedMessage(id, patch) {
    const next = displayedMessages.map(message =>
        message.id === id ? { ...message, ...patch } : message
    );
    if (activeStudent) {
        const conversation = latestByStudent.get(activeStudent.id);
        if (conversation?.latest?.id === id) {
            latestByStudent.set(activeStudent.id, {
                ...conversation,
                latest: { ...conversation.latest, ...patch }
            });
        }
        cacheConversationMessages(currentUser.id, activeStudent.id, visibleForMe(next, activeStudent.id));
    }
    renderMessages(next);
    renderStudents();
}

function openMessageActions(message, isSent) {
    actionMessage = message;
    const ageMs = Date.now() - new Date(message.created_at).getTime();
    const canEdit = isSent && !!message.content && !message.media_url &&
        ageMs < MESSAGE_EDIT_WINDOW_MS;
    const canRecall = isSent && ageMs < MESSAGE_RECALL_WINDOW_MS;
    editMessageButton.hidden = !canEdit;
    deleteMessageAllButton.hidden = !canRecall;
    messageActionHint.textContent =
        isSent && !canEdit && !canRecall
            ? translate("The time to edit or recall this message has passed.")
            : "";
    messageActionDialog.showModal();
}

async function applyMessageAction(message, patch) {
    const { error } = await supabase
        .from("messages")
        .update(patch)
        .eq("id", message.id);
    if (error) {
        console.error("Could not update message:", error);
        showNotice(`Could not update the message: ${error.message}`, true);
        return false;
    }
    patchDisplayedMessage(message.id, patch);
    return true;
}

editMessageButton.addEventListener("click", () => {
    const message = actionMessage;
    messageActionDialog.close();
    if (!message) return;
    openInlineEdit(message);
});

renameContactButton.addEventListener("click", () => {
    if (!activeStudent) return;
    contactNameInput.value = contactNames.get(activeStudent.id) || "";
    contactNameInput.placeholder = studentName(activeStudent);
    contactNameDialog.showModal();
    contactNameInput.focus();
    contactNameInput.select();
});

function refreshNameViews(peer) {
    renderStudents();
    if (activeStudent?.id === peer.id && !activeCommunity) {
        elements.chatName.textContent = studentName(activeStudent);
        appendRoleBadge(elements.chatName, activeStudent);
    }
}

saveContactNameButton.addEventListener("click", async () => {
    const peer = activeStudent;
    if (!peer) return;
    const name = contactNameInput.value.trim();
    if (!name) return;
    contactNameDialog.close();
    const { error } = await supabase.from("contact_names").upsert({
        author_id: currentUser.id,
        peer_id: peer.id,
        name,
        updated_at: new Date().toISOString()
    }, { onConflict: "author_id,peer_id" });
    if (error) {
        showNotice(isMissingMigrationObject(error)
            ? translate("Saved contact names need one database update. Use Finish setup to do it in two taps.")
            : `Could not save the name: ${error.message}`, true);
        if (isMissingMigrationObject(error)) {
            showSetupCard({
                target: "#conversation-list",
                position: "before",
                reason: translate("Saved contact names need one database update.")
            });
        }
        return;
    }
    contactNames.set(peer.id, name);
    refreshNameViews(peer);
    showNotice(`Saved “${name}”. Only you see this name.`);
});

clearContactNameButton.addEventListener("click", async () => {
    const peer = activeStudent;
    if (!peer) return;
    contactNameDialog.close();
    const { error } = await supabase.from("contact_names")
        .delete()
        .eq("author_id", currentUser.id)
        .eq("peer_id", peer.id);
    if (error && !isMissingMigrationObject(error)) {
        showNotice(`Could not remove the name: ${error.message}`, true);
        return;
    }
    contactNames.delete(peer.id);
    refreshNameViews(peer);
});

cancelContactNameButton.addEventListener("click", () => contactNameDialog.close());

deleteMessageMeButton.addEventListener("click", () => {
    const message = actionMessage;
    messageActionDialog.close();
    if (!message || (message.deleted_by || []).includes(currentUser.id)) return;
    void applyMessageAction(message, {
        deleted_by: [...(message.deleted_by || []), currentUser.id]
    });
});

deleteMessageAllButton.addEventListener("click", () => {
    const message = actionMessage;
    messageActionDialog.close();
    if (!message || message.deleted_for_everyone) return;
    void (async () => {
        const confirmed = await askChatConfirm({
            title: "Delete this message for everyone?",
            body: "It disappears from both phones.",
            confirmLabel: "Delete for everyone",
            danger: true
        });
        if (!confirmed) return;
        await applyMessageAction(message, {
            deleted_for_everyone: true,
            content: null,
            media_url: null
        });
    })();
});

closeMessageActionButton?.addEventListener("click", () => messageActionDialog.close());

/* ------------------------------------------------------------------
 * Long-press menu, quick reactions, reply, forward, star, info and the
 * inline edit bar. Reactions and stars sync to the other person once
 * database/RUN_ALL.sql has been pasted; before that they stay
 * on this device so the menu never depends on a migration.
 * ------------------------------------------------------------------ */

const QUICK_REACTIONS = ["👍", "❤️", "😂", "😮", "🙏", "🥰"];
const MORE_REACTIONS = ["👎", "🔥", "🎉", "😍", "😢", "😡", "🤔", "🤗", "👏", "💪", "✅", "❌", "💯", "🙌"];

const menuLayer = document.getElementById("messageMenuLayer");
const quickRow = document.getElementById("quickReactions");
const quickExtra = document.getElementById("quickExtra");
const menuList = document.getElementById("messageContextMenu");
const chatCompose = document.querySelector(".chat-compose");
const replyStrip = document.getElementById("reply-strip");
const replyStripName = document.getElementById("reply-strip-name");
const replyStripText = document.getElementById("reply-strip-text");
const editBar = document.getElementById("edit-bar");
const editBarInput = document.getElementById("edit-bar-input");
const forwardDialog = document.getElementById("forward-dialog");
const forwardSearch = document.getElementById("forward-search");
const forwardBody = document.getElementById("forward-body");
const forwardChips = document.getElementById("forward-chips");
const forwardResult = document.getElementById("forward-result");
const forwardSendButton = document.getElementById("forward-send");
const infoDialog = document.getElementById("message-info-dialog");
const infoList = document.getElementById("message-info-list");
const contextButtons = {
    reply: document.getElementById("ctx-reply"),
    forward: document.getElementById("ctx-forward"),
    copy: document.getElementById("ctx-copy"),
    edit: document.getElementById("ctx-edit"),
    note: document.getElementById("ctx-note"),
    info: document.getElementById("ctx-info"),
    star: document.getElementById("ctx-star"),
    delete: document.getElementById("ctx-delete"),
    more: document.getElementById("ctx-more")
};

let forwardSource = null;

const messageMarks = createMessageMarks({
    getSupabase: () => supabase,
    getUserId: () => currentUser?.id,
    onWarning: error => console.warn("Message marks stayed on this device:", error?.message || error)
});

messageMarks.onUpdated(() => {
    if (activeStudent || activeCommunity) renderMessages(displayedMessages);
});

function senderLabel(message) {
    if (message.sender_id === currentUser?.id) return translate("You");
    const student = allStudents.find(item => item.id === message.sender_id);
    if (student) return studentName(student);
    return message.sender_name || memberDisplayName(message) || translate("Student");
}

function messageSnippet(message) {
    if (message.content) return message.content;
    if (isVoiceUrl(message.media_url)) return translate("Voice message");
    if (message.media_url) return translate("Attachment");
    return translate("Message");
}

function replyPreviewFrom(reply) {
    if (!reply) return null;
    return {
        message_id: reply.id || null,
        author: reply.name || "",
        text: String(reply.text || "").slice(0, 300),
        forwarded: Boolean(reply.forwarded)
    };
}

function buildReplyQuote(preview, sent) {
    const quote = document.createElement("div");
    quote.className = "reply-quote";
    const name = document.createElement("strong");
    if (preview.story_id) {
        /* A status is not a message, so the line above the reply names it as
           one - and whose status it was depends on who is reading it. */
        name.textContent = translate(sent ? "Status" : "Your status");
    } else {
        name.textContent = preview.forwarded
            ? translate("Forwarded")
            : preview.author || translate("Message");
    }
    const text = document.createElement("em");
    text.textContent = preview.text || "";
    quote.append(name, text);
    if (!preview.text) text.remove();
    if (preview.story_id) decorateStatusQuote(quote, preview);
    return quote;
}

/* A reply to a status names the status it answers, and the quote is the link:
   tap it and that status opens again full screen. On this page the viewer lives
   on the app root, so the link simply travels there. */
function decorateStatusQuote(quote, preview) {
    quote.classList.add("reply-quote--status");
    quote.title = translate("Open status");
    const hint = document.createElement("span");
    hint.className = "reply-quote-link";
    hint.textContent = translate("Open status");
    quote.appendChild(hint);
    quote.addEventListener("click", () => {
        const hash = `#story-${preview.story_id}`;
        if (document.getElementById("storyViewer")) {
            window.location.hash = hash;
            return;
        }
        window.location.href = `/${hash}`;
    });
}

function setPendingReply(message) {
    pendingReply = {
        id: message.id,
        name: senderLabel(message),
        text: messageSnippet(message)
    };
    replyStripName.textContent = pendingReply.name;
    replyStripText.textContent = pendingReply.text;
    replyStrip.hidden = false;
}

function clearPendingReply() {
    pendingReply = null;
    replyStrip.hidden = true;
    replyStripName.textContent = "";
    replyStripText.textContent = "";
}

function clampLeft(preferred, width) {
    const margin = 10;
    const max = window.innerWidth - width - margin;
    return Math.max(margin, Math.min(preferred, max));
}

function closeMessageMenu() {
    menuLayer.hidden = true;
    quickExtra.hidden = true;
    contextMessage = null;
}

function buildQuickReactionBar(message) {
    const mine = messageMarks.myReaction(message.id);
    const buttons = QUICK_REACTIONS.map(emoji => {
        const button = document.createElement("button");
        button.type = "button";
        button.textContent = emoji;
        button.classList.toggle("picked", mine === emoji);
        button.setAttribute("aria-label", `${translate("React with")} ${emoji}`);
        button.addEventListener("click", () => {
            void messageMarks.toggleReaction(message.id, emoji);
            closeMessageMenu();
        });
        return button;
    });
    const more = document.createElement("button");
    more.type = "button";
    more.className = "quick-more";
    more.textContent = "+";
    more.setAttribute("aria-label", translate("More reactions"));
    more.addEventListener("click", event => {
        event.stopPropagation();
        quickExtra.hidden = !quickExtra.hidden;
        if (quickExtra.hidden) return;
        const layerBox = menuLayer.getBoundingClientRect();
        const rowBox = quickRow.getBoundingClientRect();
        quickExtra.style.left = `${clampLeft(rowBox.left - layerBox.left, quickExtra.offsetWidth || 280)}px`;
        quickExtra.style.top = `${rowBox.bottom - layerBox.top + 6}px`;
    });
    quickExtra.replaceChildren(...MORE_REACTIONS.map(emoji => {
        const button = document.createElement("button");
        button.type = "button";
        button.textContent = emoji;
        button.addEventListener("click", () => {
            void messageMarks.toggleReaction(message.id, emoji);
            closeMessageMenu();
        });
        return button;
    }));
    quickRow.replaceChildren(...buttons, more);
}

function openMessageMenu(message, bubble) {
    if (!currentUser || message.pending || message.deleted_for_everyone) return;
    contextMessage = message;
    const sent = message.sender_id === currentUser.id;
    buildQuickReactionBar(message);

    const text = (message.content || "").trim();
    const ageMs = Date.now() - new Date(message.created_at).getTime();
    contextButtons.copy.hidden = !text;
    contextButtons.note.hidden = !text;
    contextButtons.edit.hidden = !(sent && text && !message.media_url &&
        ageMs < MESSAGE_EDIT_WINDOW_MS);
    const starLabel = contextButtons.star.querySelector("span:last-child");
    starLabel.textContent = translate(messageMarks.isStarred(message.id) ? "Remove from starred" : "Star");

    menuLayer.hidden = false;
    quickExtra.hidden = true;

    const layerBox = menuLayer.getBoundingClientRect();
    const bubbleBox = bubble.getBoundingClientRect();
    const quickWidth = quickRow.offsetWidth || 300;
    const quickHeight = quickRow.offsetHeight || 50;
    let quickTop = bubbleBox.top - layerBox.top - quickHeight - 10;
    if (quickTop < 4) quickTop = bubbleBox.bottom - layerBox.top + 10;
    quickRow.style.top = `${quickTop}px`;
    quickRow.style.left = `${clampLeft(
        (sent ? bubbleBox.right - quickWidth : bubbleBox.left) - layerBox.left,
        quickWidth
    )}px`;

    const menuWidth = menuList.offsetWidth || 236;
    const menuHeight = menuList.offsetHeight || 300;
    let menuTop = quickTop + quickHeight + 8;
    if (menuTop + menuHeight > layerBox.height - 8) {
        menuTop = Math.max(8, layerBox.height - menuHeight - 8);
    }
    menuList.style.top = `${menuTop}px`;
    menuList.style.left = `${clampLeft(
        (sent ? bubbleBox.right - menuWidth : bubbleBox.left) - layerBox.left,
        menuWidth
    )}px`;
}

function messageFromTarget(target) {
    const row = target.closest?.(".message[data-message-id]");
    if (!row) return null;
    const message = displayedMessages.find(item => item.id === row.dataset.messageId);
    if (!message || message.pending || message.deleted_for_everyone) return null;
    return { message, bubble: row.querySelector(".bubble") || row };
}

let pressTimer = null;
let pressStart = { x: 0, y: 0 };

function cancelMessagePress() {
    if (pressTimer) window.clearTimeout(pressTimer);
    pressTimer = null;
}

elements.chatMessages.addEventListener("pointerdown", event => {
    if (event.pointerType === "mouse" && event.button !== 0) return;
    const found = messageFromTarget(event.target);
    if (!found) return;
    pressStart = { x: event.clientX, y: event.clientY };
    cancelMessagePress();
    pressTimer = window.setTimeout(() => {
        pressTimer = null;
        navigator.vibrate?.(12);
        openMessageMenu(found.message, found.bubble);
    }, 360);
});

elements.chatMessages.addEventListener("pointermove", event => {
    if (!pressTimer) return;
    if (Math.abs(event.clientX - pressStart.x) > 12 || Math.abs(event.clientY - pressStart.y) > 12) {
        cancelMessagePress();
    }
});

for (const eventName of ["pointerup", "pointercancel", "pointerleave"]) {
    elements.chatMessages.addEventListener(eventName, cancelMessagePress);
}

elements.chatMessages.addEventListener("contextmenu", event => {
    const found = messageFromTarget(event.target);
    if (!found) return;
    event.preventDefault();
    cancelMessagePress();
    openMessageMenu(found.message, found.bubble);
});

menuLayer.addEventListener("click", event => {
    if (event.target === menuLayer) closeMessageMenu();
});

document.addEventListener("keydown", event => {
    if (event.key === "Escape" && !menuLayer.hidden) closeMessageMenu();
});

/* ---- Long-press on a chat row ------------------------------------------
   The nine actions WhatsApp puts under a held finger. Archive, mute, lock,
   list, clear and delete go through chat-organize — on the account once the
   SQL is pasted, on this phone until then. Read, favourite and block reuse
   what the chat list already knew how to do. */

const chatOrganize = createChatOrganize({
    getSupabase: () => supabase,
    getUserId: () => currentUser?.id,
    onWarning: error => console.warn("Chat settings stayed on this device:", error?.message || error)
});

const chatLock = createChatLock({ getUserId: () => currentUser?.id });

const chatMenuLayer = document.getElementById("chatMenuLayer");
const chatMenuList = document.getElementById("chatContextMenu");
const chatListPanel = document.getElementById("chatListPanel");
const chatListNames = document.getElementById("chatListNames");
const chatListForm = document.getElementById("chatListForm");
const chatListInput = document.getElementById("chatListInput");
const chatConfirmDialog = document.getElementById("chat-confirm-dialog");
const chatConfirmTitle = document.getElementById("chat-confirm-title");
const chatConfirmBody = document.getElementById("chat-confirm-body");
const chatConfirmOk = document.getElementById("chat-confirm-ok");
const chatConfirmCancel = document.getElementById("chat-confirm-cancel");
const archivedCountBadge = document.getElementById("archived-count");
const chatMenuButtons = {
    read: document.getElementById("chat-ctx-read"),
    archive: document.getElementById("chat-ctx-archive"),
    mute: document.getElementById("chat-ctx-mute"),
    lock: document.getElementById("chat-ctx-lock"),
    favorite: document.getElementById("chat-ctx-favorite"),
    list: document.getElementById("chat-ctx-list"),
    block: document.getElementById("chat-ctx-block"),
    clear: document.getElementById("chat-ctx-clear"),
    delete: document.getElementById("chat-ctx-delete")
};

let contextPeer = null;
let chatMenuOpenedAt = 0;

chatOrganize.onUpdated(() => renderStudents());

function chatPeerOf(student) {
    return { kind: "student", id: student.id, name: studentName(student), student };
}

function chatPeerOfGroup(group) {
    return { kind: "group", id: group.id, name: group.name, group };
}

/* A chat someone deleted from the list comes back the moment a newer message
   lands, which is the only behaviour that makes a delete safe to offer. */
function chatRowIsHidden(peerId, lastActivityAt) {
    const hiddenAt = chatOrganize.flagsFor(peerId).hiddenAt;
    if (!hiddenAt) return false;
    const latest = Date.parse(lastActivityAt || "");
    const until = Date.parse(hiddenAt);
    return !Number.isFinite(latest) || latest <= until;
}

function chatPeerUnread(peer) {
    if (peer.kind === "group") return Number(groupById(peer.id)?.unread_count || 0);
    return latestByStudent.get(peer.id)?.unread || 0;
}

function setChatMenuLabel(button, text) {
    button.querySelector("span:last-child").textContent = translate(text);
}

function closeChatMenu() {
    chatMenuLayer.hidden = true;
    chatListPanel.hidden = true;
    contextPeer = null;
}

function openChatMenu(peer, anchor) {
    if (!currentUser) return;
    contextPeer = peer;
    chatMenuOpenedAt = Date.now();
    const flags = chatOrganize.flagsFor(peer.id);
    const unread = chatPeerUnread(peer);

    setChatMenuLabel(chatMenuButtons.read, unread ? "Mark as read" : "Mark as unread");
    chatMenuButtons.read.hidden = peer.kind === "group" && !unread;
    setChatMenuLabel(chatMenuButtons.archive, flags.archived ? "Unarchive" : "Archive");
    setChatMenuLabel(chatMenuButtons.mute, flags.muted ? "Unmute notifications" : "Mute notifications");
    setChatMenuLabel(chatMenuButtons.lock, flags.locked ? "Unlock chat" : "Lock chat");
    chatMenuButtons.favorite.hidden = peer.kind !== "student";
    setChatMenuLabel(chatMenuButtons.favorite,
        favoriteStudentIds.has(peer.id) ? "Remove from favorites" : "Add to favorites");
    chatMenuButtons.list.querySelector("span:last-child").textContent = flags.list
        ? `${translate("List")}: ${flags.list}`
        : translate("Add to list");
    chatMenuButtons.block.hidden = peer.kind !== "student";
    setChatMenuLabel(chatMenuButtons.block,
        blockedStudentIds.has(peer.id) ? "Unblock" : `${translate("Block")} ${peer.name}`);

    chatMenuList.hidden = false;
    chatListPanel.hidden = true;
    chatMenuLayer.hidden = false;

    const layerBox = chatMenuLayer.getBoundingClientRect();
    const anchorBox = anchor.getBoundingClientRect();
    const menuWidth = chatMenuList.offsetWidth || 236;
    const menuHeight = chatMenuList.offsetHeight || 380;
    let top = anchorBox.top - layerBox.top + 6;
    if (top + menuHeight > layerBox.height - 8) top = Math.max(8, layerBox.height - menuHeight - 8);
    const left = clampLeft(anchorBox.left - layerBox.left, menuWidth);
    chatMenuList.style.top = `${top}px`;
    chatMenuList.style.left = `${left}px`;
    chatListPanel.style.top = `${top}px`;
    chatListPanel.style.left = `${left}px`;
}

function showChatListPanel(peer) {
    const current = chatOrganize.flagsFor(peer.id).list;
    const names = [...new Set([...chatOrganize.listNames(), current].filter(Boolean))];
    chatListNames.replaceChildren();
    if (!names.length) {
        const empty = document.createElement("p");
        empty.className = "chat-list-empty";
        empty.textContent = translate("No lists yet. Create one below.");
        chatListNames.appendChild(empty);
    }
    for (const name of names) {
        const button = document.createElement("button");
        button.type = "button";
        button.setAttribute("role", "menuitem");
        button.textContent = `${current === name ? "✓ " : "＋ "}${name}`;
        button.addEventListener("click", () => {
            void chatOrganize.setFlag(peer.id, "list", current === name ? "" : name);
            closeChatMenu();
        });
        chatListNames.appendChild(button);
    }
    chatListPanel.hidden = false;
    chatListInput.value = "";
}

function askChatConfirm({ title, body, confirmLabel, danger = false }) {
    chatConfirmTitle.textContent = translate(title);
    chatConfirmBody.textContent = translate(body);
    chatConfirmOk.textContent = translate(confirmLabel);
    chatConfirmOk.classList.toggle("message-action-danger", danger);
    chatConfirmOk.onclick = () => {
        chatConfirmDialog.dataset.answer = "yes";
        chatConfirmDialog.close();
    };
    chatConfirmCancel.onclick = () => chatConfirmDialog.close();
    chatConfirmDialog.dataset.answer = "no";
    chatConfirmDialog.showModal();
    return new Promise(resolve => {
        chatConfirmDialog.addEventListener(
            "close",
            () => resolve(chatConfirmDialog.dataset.answer === "yes"),
            { once: true }
        );
    });
}

async function markPeerRead(peer) {
    try {
        if (peer.kind === "group") {
            await markGroupRead(supabase, peer.id);
            const group = groupById(peer.id);
            if (group) group.unread_count = 0;
        } else {
            const { error } = await supabase.from("messages")
                .update({ is_read: true })
                .eq("receiver_id", currentUser.id)
                .eq("sender_id", peer.id)
                .eq("is_read", false);
            if (error) throw error;
            const current = latestByStudent.get(peer.id);
            if (current) latestByStudent.set(peer.id, { ...current, unread: 0 });
        }
        renderStudents();
    } catch (error) {
        console.error("Could not mark the chat as read:", error);
        showNotice(`Could not mark as read: ${error.message}`, true);
    }
}

async function markPeerUnread(peer) {
    try {
        const { error } = await supabase.from("messages")
            .update({ is_read: false })
            .eq("receiver_id", currentUser.id)
            .eq("sender_id", peer.id)
            .eq("is_read", true);
        if (error) throw error;
        const current = latestByStudent.get(peer.id);
        if (current) {
            latestByStudent.set(peer.id, {
                latest: current.latest,
                unread: Math.max(1, current.unread || 0)
            });
        }
        renderStudents();
    } catch (error) {
        console.error("Could not mark the chat as unread:", error);
        showNotice(`Could not mark as unread: ${error.message}`, true);
    }
}

async function togglePeerArchive(peer) {
    const archived = !chatOrganize.flagsFor(peer.id).archived;
    await chatOrganize.setFlag(peer.id, "archived", archived);
    if (archived && chatMenuIsOpen(peer)) {
        elements.messaging.classList.remove("chat-open");
    }
    showNotice(translate(archived ? "Chat archived." : "Chat unarchived."));
}

function chatMenuIsOpen(peer) {
    return activeStudent?.id === peer.id || activeCommunity?.id === peer.id;
}

async function togglePeerMute(peer) {
    const muted = !chatOrganize.flagsFor(peer.id).muted;
    await chatOrganize.setFlag(peer.id, "muted", muted);
    if (muted) void dismissMessageAlert(peer.id);
    showNotice(translate(muted
        ? "Notifications are off for this chat."
        : "Notifications are back on for this chat."));
}

async function togglePeerLock(peer) {
    const locked = !chatOrganize.flagsFor(peer.id).locked;
    try {
        /* Locking has to leave something to unlock with, and unlocking has to
           prove who is holding the phone. */
        if (locked) await chatLock.ensureSetup(peer.name);
        else await chatLock.require(peer.id, peer.name);
    } catch (error) {
        showNotice(error?.message || translate("Verification did not complete."), true);
        return;
    }
    await chatOrganize.setFlag(peer.id, "locked", locked);
    if (!locked) chatLock.release(peer.id);
    showNotice(translate(locked ? "Chat locked." : "Chat unlocked."));
}

async function clearPeerChat(peer) {
    const confirmed = await askChatConfirm({
        title: "Clear this chat?",
        body: "The messages disappear from your phone. The other person keeps theirs.",
        confirmLabel: "Clear chat"
    });
    if (!confirmed) return;
    await chatOrganize.clearChat(peer.id);
    if (chatMenuIsOpen(peer)) {
        displayedMessages = [];
        renderMessages([], true);
        if (peer.kind === "student") cacheConversationMessages(currentUser.id, peer.id, []);
    }
    renderStudents();
    showNotice(translate("Chat cleared."));
}

async function deletePeerChat(peer) {
    const confirmed = await askChatConfirm({
        title: "Delete this chat?",
        body: "It leaves your chat list and its messages are cleared. A new message from them brings it back.",
        confirmLabel: "Delete chat",
        danger: true
    });
    if (!confirmed) return;
    await chatOrganize.deleteChat(peer.id);
    if (chatMenuIsOpen(peer)) {
        displayedMessages = [];
        renderMessages([], true);
        elements.messaging.classList.remove("chat-open");
    }
    if (peer.kind === "student") {
        cacheConversationMessages(currentUser.id, peer.id, []);
        latestByStudent.delete(peer.id);
    }
    void dismissMessageAlert(peer.id);
    renderStudents();
    showNotice(translate("Chat deleted."));
}

chatMenuButtons.read.addEventListener("click", () => {
    const peer = contextPeer;
    closeChatMenu();
    if (!peer) return;
    void (chatPeerUnread(peer) ? markPeerRead(peer) : markPeerUnread(peer));
});

chatMenuButtons.archive.addEventListener("click", () => {
    const peer = contextPeer;
    closeChatMenu();
    if (peer) void togglePeerArchive(peer);
});

chatMenuButtons.mute.addEventListener("click", () => {
    const peer = contextPeer;
    closeChatMenu();
    if (peer) void togglePeerMute(peer);
});

chatMenuButtons.lock.addEventListener("click", () => {
    const peer = contextPeer;
    closeChatMenu();
    if (peer) void togglePeerLock(peer);
});

chatMenuButtons.favorite.addEventListener("click", () => {
    const peer = contextPeer;
    closeChatMenu();
    if (peer?.kind === "student") toggleFavorite(peer.id);
});

chatMenuButtons.list.addEventListener("click", event => {
    event.stopPropagation();
    if (contextPeer) showChatListPanel(contextPeer);
});

chatMenuButtons.block.addEventListener("click", () => {
    const peer = contextPeer;
    closeChatMenu();
    if (peer?.kind === "student") void toggleBlock(peer.student);
});

chatMenuButtons.clear.addEventListener("click", () => {
    const peer = contextPeer;
    closeChatMenu();
    if (peer) void clearPeerChat(peer);
});

chatMenuButtons.delete.addEventListener("click", () => {
    const peer = contextPeer;
    closeChatMenu();
    if (peer) void deletePeerChat(peer);
});

chatListForm.addEventListener("submit", event => {
    event.preventDefault();
    const name = chatListInput.value.trim().slice(0, 40);
    const peer = contextPeer;
    if (!name || !peer) {
        closeChatMenu();
        return;
    }
    void chatOrganize.setFlag(peer.id, "list", name);
    closeChatMenu();
    showNotice(`${translate("Chat added to list")}: ${name}`);
});

chatListPanel.querySelector("[data-cancel]").addEventListener("click", closeChatMenu);

chatMenuLayer.addEventListener("click", event => {
    if (event.target === chatMenuLayer) closeChatMenu();
});

chatListPanel.addEventListener("click", event => event.stopPropagation());

document.addEventListener("keydown", event => {
    if (event.key === "Escape" && !chatMenuLayer.hidden) closeChatMenu();
});

function attachChatRowMenu(item, peer) {
    const anchor = item.querySelector(".conversation") || item;
    let timer = null;
    let start = { x: 0, y: 0 };
    const cancel = () => {
        if (timer) window.clearTimeout(timer);
        timer = null;
    };
    anchor.addEventListener("pointerdown", event => {
        if (event.pointerType === "mouse" && event.button !== 0) return;
        start = { x: event.clientX, y: event.clientY };
        cancel();
        timer = window.setTimeout(() => {
            timer = null;
            navigator.vibrate?.(12);
            openChatMenu(peer, anchor);
        }, 360);
    });
    anchor.addEventListener("pointermove", event => {
        if (!timer) return;
        if (Math.abs(event.clientX - start.x) > 12 || Math.abs(event.clientY - start.y) > 12) cancel();
    });
    for (const eventName of ["pointerup", "pointercancel", "pointerleave"]) {
        anchor.addEventListener(eventName, cancel);
    }
    anchor.addEventListener("contextmenu", event => {
        event.preventDefault();
        cancel();
        openChatMenu(peer, anchor);
    });
}

/* ---- Chat colours ------------------------------------------------------
   One palette for the conversation on screen: eight ready-made sets or any
   colour the member picks. Nothing is ever chosen for them — with no choice
   saved, the shipped bubbles stay exactly as they are. A chat's own colour
   rides on the account (PART 20 theme column); the colour for all chats is
   this phone's setting, so it applies the moment it is picked. */

const chatPanel = document.getElementById("chat-panel");
const coloursPanel = document.getElementById("chat-colours-panel");
const coloursScopeRow = document.getElementById("chat-colours-scope");
const coloursSwatches = document.getElementById("chat-colours-swatches");
const coloursPicker = document.getElementById("chat-colour-picker");
const coloursApply = document.getElementById("chat-colours-apply");
const coloursReset = document.getElementById("chat-colours-reset");
const coloursNotice = document.getElementById("chat-colours-notice");

let coloursScope = "chat";

function isNightMode() {
    return document.body.classList.contains("dark-mode");
}

function activeColourPeer() {
    return activeCommunity?.id || activeStudent?.id || "";
}

function effectiveThemeValue() {
    const peerId = activeColourPeer();
    return (peerId ? chatOrganize.themeFor(peerId) : "") || readGlobalTheme(currentUser?.id);
}

function refreshChatTheme() {
    if (!chatPanel) return;
    applyChatTheme(chatPanel, effectiveThemeValue(), isNightMode());
    markSelectedSwatch(effectiveThemeValue());
}

function showColoursNotice(text, isError) {
    if (!coloursNotice) return;
    coloursNotice.textContent = text;
    coloursNotice.style.color = isError ? "#d13a2f" : "";
}

function markSelectedSwatch(value) {
    const id = themeIdFor(value);
    for (const button of [...coloursSwatches.children]) {
        button.setAttribute("aria-pressed", String(id && button.dataset.theme === id));
    }
}

function buildSwatch(id, label, palette) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "chat-colours-swatch";
    button.dataset.theme = id;
    button.setAttribute("aria-pressed", "false");
    const vars = palette ? buildThemeVars(palette, isNightMode()) : {
        "--page": isNightMode() ? "#0b141a" : "#efeae2",
        "--received": isNightMode() ? "#202c33" : "#ffffff",
        "--sent": isNightMode() ? "#005c4b" : "#d9fdd3",
        "--panel": isNightMode() ? "#111b21" : "#ffffff",
        "--text": isNightMode() ? "#e9edef" : "#111b21"
    };
    for (const name of ["--page", "--received", "--sent"]) {
        const band = document.createElement("i");
        band.style.background = vars[name];
        button.append(band);
    }
    const caption = document.createElement("span");
    caption.textContent = label;
    caption.style.background = vars["--panel"];
    caption.style.color = vars["--text"];
    button.append(caption);
    button.addEventListener("click", () => void chooseColour(id));
    return button;
}

function renderColourSwatches() {
    if (!coloursSwatches) return;
    coloursSwatches.replaceChildren(
        buildSwatch("", translate("Normal"), null),
        ...PRESETS.map(preset => buildSwatch(
            `preset:${preset.id}`,
            translate(preset.name),
            { light: preset.light, dark: preset.dark, name: preset.name }
        ))
    );
    markSelectedSwatch(effectiveThemeValue());
}

function renderColourScope() {
    if (!coloursScopeRow) return;
    coloursScopeRow.replaceChildren();
    for (const [value, label] of [["chat", "Just this chat"], ["all", "All my chats"]]) {
        const option = document.createElement("label");
        const radio = document.createElement("input");
        radio.type = "radio";
        radio.name = "chat-colours-scope";
        radio.value = value;
        radio.checked = coloursScope === value;
        radio.addEventListener("change", () => {
            coloursScope = value;
        });
        option.append(radio, document.createTextNode(translate(label)));
        coloursScopeRow.append(option);
    }
}

async function chooseColour(id) {
    const value = themeIdFor(id);
    const peerId = activeColourPeer();
    if (coloursScope === "all") {
        if (!currentUser) {
            showColoursNotice(translate("Sign in first to keep this colour."), true);
            return;
        }
        writeGlobalTheme(currentUser?.id, value);
        /* A chat that already carries its own colour would hide the new
           default, so choosing for all chats also clears this one's. */
        if (peerId && chatOrganize.themeFor(peerId)) await chatOrganize.setTheme(peerId, "");
        showColoursNotice(translate("Saved for all your chats. A chat with its own colour keeps it."));
    } else {
        if (!peerId) {
            showColoursNotice(translate("Open a chat to colour just that one."), true);
            return;
        }
        await chatOrganize.setTheme(peerId, value);
        showColoursNotice(translate("This chat now has its own colour."));
    }
    refreshChatTheme();
}

if (coloursSwatches) {
    renderColourScope();
    renderColourSwatches();
    coloursApply.addEventListener("click", () => void chooseColour(`color:${coloursPicker.value}`));
    coloursReset.addEventListener("click", () => void chooseColour(""));
    coloursPanel?.addEventListener("toggle", () => {
        if (coloursPanel.open) {
            renderColourSwatches();
            showColoursNotice(translate("Colours change how the chat looks on your phone only."));
        }
    });
    chatOrganize.onUpdated(() => {
        markSelectedSwatch(effectiveThemeValue());
    });
}

function renderArchivedCount() {
    const count = chatOrganize.archivedCount();
    archivedCountBadge.textContent = String(count);
    archivedCountBadge.hidden = count === 0;
}

function chatRowFlags(peerId, displayName) {
    const flags = chatOrganize.flagsFor(peerId);
    if (flags.locked || flags.muted) {
        const mark = document.createElement("span");
        mark.className = "chat-flag";
        mark.textContent = `${flags.locked ? "🔒" : ""}${flags.muted ? "🔕" : ""}`;
        mark.setAttribute("aria-label", flags.locked && flags.muted
            ? translate("Locked and muted")
            : translate(flags.locked ? "Locked chat" : "Muted notifications"));
        displayName.appendChild(mark);
    }
    if (flags.list) {
        const tag = document.createElement("span");
        tag.className = "chat-list-tag";
        tag.textContent = flags.list;
        displayName.appendChild(tag);
    }
    return flags;
}

function buildReactionRow(messageId) {
    const byUser = messageMarks.reactionsFor(messageId);
    const entries = Object.entries(byUser);
    if (!entries.length) return null;
    const counts = new Map();
    for (const [userId, emoji] of entries) {
        const entry = counts.get(emoji) || { count: 0, mine: false };
        entry.count += 1;
        entry.mine = entry.mine || userId === currentUser?.id;
        counts.set(emoji, entry);
    }
    const row = document.createElement("div");
    row.className = "message-reactions";
    for (const [emoji, entry] of counts) {
        const chip = document.createElement("button");
        chip.type = "button";
        chip.className = entry.mine ? "reaction-chip mine" : "reaction-chip";
        chip.textContent = emoji;
        if (entry.count > 1) {
            const count = document.createElement("small");
            count.textContent = String(entry.count);
            chip.appendChild(count);
        }
        chip.addEventListener("click", () => void messageMarks.toggleReaction(messageId, emoji));
        row.appendChild(chip);
    }
    return row;
}

async function copyMessageText(text) {
    try {
        await navigator.clipboard.writeText(text);
        showNotice(translate("Copied."));
    } catch (error) {
        console.error("Could not copy the message:", error);
        const helper = document.createElement("textarea");
        helper.value = text;
        helper.setAttribute("aria-hidden", "true");
        helper.style.position = "fixed";
        helper.style.opacity = "0";
        document.body.appendChild(helper);
        helper.select();
        const copied = document.execCommand("copy");
        helper.remove();
        showNotice(copied ? translate("Copied.") : translate("Could not copy this message."), !copied);
    }
}

function openInlineEdit(message) {
    inlineEditMessage = message;
    editBarInput.value = message.content || "";
    editBar.hidden = false;
    chatCompose.classList.add("is-edit-mode");
    elements.messageInput.blur();
    editBarInput.focus();
    editBarInput.setSelectionRange(editBarInput.value.length, editBarInput.value.length);
}

function closeInlineEdit() {
    inlineEditMessage = null;
    editBar.hidden = true;
    chatCompose.classList.remove("is-edit-mode");
}

function commitInlineEdit() {
    const message = inlineEditMessage;
    if (!message) return;
    const content = editBarInput.value.trim();
    closeInlineEdit();
    if (!content || content === message.content) return;
    void applyMessageAction(message, { content, edited_at: new Date().toISOString() });
}

document.getElementById("edit-bar-cancel").addEventListener("click", closeInlineEdit);
document.getElementById("edit-bar-confirm").addEventListener("click", commitInlineEdit);
editBarInput.addEventListener("keydown", event => {
    if (event.key === "Enter") {
        event.preventDefault();
        commitInlineEdit();
    }
    if (event.key === "Escape") closeInlineEdit();
});

contextButtons.reply.addEventListener("click", () => {
    const message = contextMessage;
    closeMessageMenu();
    if (!message) return;
    if (!replyColumnsAvailable) {
        showNotice(translate(
            "Replies need one database update. Use Finish setup to do it in two taps."), true);
        showSetupCard({
            target: "#conversation-list",
            position: "before",
            reason: translate("Replies and reactions need one database update.")
        });
    }
    setPendingReply(message);
    elements.messageInput.focus();
});

contextButtons.forward.addEventListener("click", () => {
    const message = contextMessage;
    closeMessageMenu();
    if (message) openForwardMenu(message);
});

contextButtons.copy.addEventListener("click", () => {
    const message = contextMessage;
    closeMessageMenu();
    if (message) void copyMessageText(message.content || "");
});

contextButtons.edit.addEventListener("click", () => {
    const message = contextMessage;
    closeMessageMenu();
    if (message) openInlineEdit(message);
});

contextButtons.note.addEventListener("click", () => {
    const message = contextMessage;
    closeMessageMenu();
    if (!message?.content) return;
    try {
        localStorage.setItem("campus-connect-note-draft", message.content);
    } catch {
        showNotice(translate("This phone is blocking saved notes."), true);
        return;
    }
    window.location.assign("/#stories");
});

contextButtons.info.addEventListener("click", () => {
    const message = contextMessage;
    closeMessageMenu();
    if (message) openMessageInfo(message);
});

contextButtons.star.addEventListener("click", () => {
    const message = contextMessage;
    closeMessageMenu();
    if (message) void messageMarks.toggleStar(message.id);
});

contextButtons.delete.addEventListener("click", () => {
    const message = contextMessage;
    closeMessageMenu();
    if (!message) return;
    actionMessage = message;
    editMessageButton.hidden = true;
    messageActionHint.textContent = "";
    messageActionDialog.showModal();
});

contextButtons.more.addEventListener("click", () => {
    const message = contextMessage;
    closeMessageMenu();
    if (message) openMessageActions(message, message.sender_id === currentUser?.id);
});

function messageKindLabel(message) {
    if (isVoiceUrl(message.media_url)) return translate("Voice message");
    if (/\.(mp4|webm|ogg|mov)(\?.*)?$/i.test(message.media_url || "")) return translate("Video");
    if (/\.(avif|bmp|gif|jpe?g|png|svg|webp)(\?.*)?$/i.test(message.media_url || "")) return translate("Photo");
    if (message.media_url) return translate("Document");
    return translate("Text message");
}

function openMessageInfo(message) {
    const sent = message.sender_id === currentUser.id;
    /* The database records only whether a message was read, never whether it
       reached the phone, so the info sheet must not claim "Delivered" while the
       ticks still say "Sent". */
    const read = sent ? (message.is_read ? translate("Read") : translate("Sent")) : translate("Received");
    const rows = [
        [translate(sent ? "From" : "To"), senderLabel(message)],
        [translate("Type"), messageKindLabel(message)],
        [translate("Sent"), new Date(message.created_at).toLocaleString()],
        [translate("Status"), message.failed
            ? translate("Not delivered")
            : message.pending ? translate("Sending…") : read]
    ];
    if (message.edited_at) {
        rows.push([translate("Edited"), new Date(message.edited_at).toLocaleString()]);
    }
    if (message.reply_preview?.message_id) {
        rows.push([translate("Replying to"), message.reply_preview.author || translate("Message")]);
    }
    rows.push([translate("Starred"), messageMarks.isStarred(message.id) ? translate("Yes") : translate("No")]);
    const reactions = Object.values(messageMarks.reactionsFor(message.id));
    if (reactions.length) rows.push([translate("Reactions"), reactions.join(" ")]);
    infoList.replaceChildren();
    for (const [label, value] of rows) {
        const dt = document.createElement("dt");
        dt.textContent = label;
        const dd = document.createElement("dd");
        dd.textContent = value;
        infoList.append(dt, dd);
    }
    infoDialog.showModal();
}

function renderForwardChips() {
    const chips = [...forwardTargets].map(id => {
        const student = allStudents.find(item => item.id === id);
        const chip = document.createElement("button");
        chip.type = "button";
        chip.className = "forward-chip";
        chip.textContent = `✕ ${student ? studentName(student) : translate("Student")}`;
        chip.addEventListener("click", () => {
            forwardTargets.delete(id);
            renderForwardSheet();
        });
        return chip;
    });
    forwardChips.replaceChildren(...chips);
    forwardChips.hidden = !chips.length;
    forwardSendButton.disabled = !chips.length;
    forwardSendButton.textContent = `${translate("Send")}${chips.length ? ` (${chips.length})` : ""}`;
}

function renderForwardSheet() {
    const term = forwardSearch.value.trim().toLowerCase();
    const pool = allStudents.filter(student =>
        student.id !== currentUser.id &&
        student.is_discoverable &&
        isMutualFriend(student.id) &&
        !blockedStudentIds.has(student.id) &&
        memberMatchesSearch(student, term));
    const recent = [...latestByStudent.keys()];
    const ordered = [...pool].sort((left, right) => {
        const leftScore = recent.indexOf(left.id);
        const rightScore = recent.indexOf(right.id);
        return (leftScore < 0 ? 999 : leftScore) - (rightScore < 0 ? 999 : rightScore);
    });
    forwardBody.replaceChildren(...ordered.slice(0, 60).map(student => {
        const row = document.createElement("button");
        row.type = "button";
        row.className = "new-chat-row";
        const avatar = document.createElement("span");
        avatar.className = "avatar";
        setAvatarContent(avatar, student);
        const text = document.createElement("span");
        const name = document.createElement("strong");
        name.textContent = studentName(student);
        appendRoleBadge(name, student);
        const detail = document.createElement("small");
        detail.textContent = forwardTargets.has(student.id)
            ? translate("Tap to remove")
            : translate("Tap to forward");
        text.append(name, detail);
        row.append(avatar, text);
        row.addEventListener("click", () => {
            if (forwardTargets.has(student.id)) forwardTargets.delete(student.id);
            else forwardTargets.add(student.id);
            renderForwardSheet();
        });
        return row;
    }));
    if (!ordered.length) {
        const empty = document.createElement("p");
        empty.className = "channels-empty";
        empty.textContent = translate("No students match that name.");
        forwardBody.replaceChildren(empty);
    }
    renderForwardChips();
}

function openForwardMenu(message) {
    if (!message || message.pending || message.deleted_for_everyone) return;
    if (!message.content && !message.media_url) return;
    forwardSource = message;
    forwardTargets.clear();
    forwardSearch.value = "";
    forwardResult.textContent = translate("Tap to forward");
    renderForwardSheet();
    forwardDialog.showModal();
}

async function sendForward() {
    const message = forwardSource;
    if (!message || !forwardTargets.size) return;
    forwardDialog.close();
    const preview = replyPreviewFrom({
        name: senderLabel(message),
        text: messageSnippet(message),
        forwarded: true,
        id: null
    });
    const payload = {
        sender_id: currentUser.id,
        content: message.content || messageSnippet(message),
        media_url: message.media_url
    };
    if (replyColumnsAvailable) payload.reply_preview = preview;
    const forwardTotal = forwardTargets.size;
    let delivered = 0;
    for (const receiver_id of forwardTargets) {
        try {
            const { data, error } = await supabase.from("messages")
                .insert({ ...payload, receiver_id })
                .select(messageSelectColumns())
                .single();
            if (error) {
                if (replyColumnsAvailable && isMissingMigrationObject(error)) {
                    replyColumnsAvailable = false;
                    delete payload.reply_preview;
                    const retry = await supabase.from("messages")
                        .insert({ ...payload, receiver_id })
                        .select(messageSelectColumns())
                        .single();
                    if (retry.error) throw retry.error;
                    if (retry.data && activeStudent && receiver_id === activeStudent.id) {
                        renderMessages([...displayedMessages, retry.data], true);
                    }
                    continue;
                }
                throw error;
            }
            if (activeStudent && receiver_id === activeStudent.id) {
                renderMessages([...displayedMessages, data], true);
            }
            const previous = latestByStudent.get(receiver_id);
            latestByStudent.set(receiver_id, { latest: data, unread: previous?.unread || 0 });
            delivered += 1;
        } catch (error) {
            console.error("Could not forward the message:", error);
            showNotice(translate("Could not send this to someone who is not your friend."), true);
        }
    }
    forwardTargets.clear();
    renderStudents();
    if (delivered === forwardTotal) {
        showNotice(translate("Forwarded."));
    } else if (delivered > 0) {
        showNotice(translate("Forwarded to your friends only."), true);
    }
}

document.getElementById("forward-close").addEventListener("click", () => forwardDialog.close());
document.getElementById("message-info-close").addEventListener("click", () => infoDialog.close());
document.getElementById("reply-strip-cancel").addEventListener("click", clearPendingReply);
forwardSearch.addEventListener("input", renderForwardSheet);
forwardSendButton.addEventListener("click", () => void sendForward());

function handleRealtimeMessageEdit(message) {
    if (!message?.id || activeCommunity || !activeStudent) return;
    if (message.sender_id !== activeStudent.id && message.receiver_id !== activeStudent.id) return;
    if (!displayedMessages.some(existing => existing.id === message.id)) return;
    patchDisplayedMessage(message.id, {
        content: message.content,
        media_url: message.media_url,
        edited_at: message.edited_at,
        deleted_for_everyone: message.deleted_for_everyone,
        deleted_by: message.deleted_by
    });
}

async function openCommunity(community) {
    conversationLoadId += 1;
    olderMessagesRequestId += 1;
    isLoadingOlderMessages = false;
    hasOlderMessages = false;
    displayedMessages = [];
    activeStudent = null;
    activeCommunity = community;
    resetVoiceMessage();
    elements.messaging.classList.remove("show-calls");
    elements.chatName.textContent = translate(community.kind === "channel" ? "Channel" : "Group chat");
    elements.chatAvatar.replaceChildren();
    elements.chatAvatar.textContent = community.kind === "channel" ? "◉" : "👥";
    closeChatActivity();
    elements.chatStatus.textContent = community.kind === "channel"
        ? "Channel · only its owner can publish."
        : "Group chat · members can join the conversation.";
    elements.callActions.classList.add("hidden");
    renameContactButton.classList.add("hidden");
    renderEmptyMessage("Loading messages…");
    elements.messageInput.disabled = community.kind === "channel" &&
        community.owner_id !== currentUser.id;
    elements.mediaInput.disabled = elements.messageInput.disabled;
    elements.sendButton.disabled = elements.messageInput.disabled;
    startRecordingButton.disabled = elements.messageInput.disabled;
    elements.messaging.classList.add("chat-open");
    applyAccessMode();
    refreshChatTheme();
    setActiveDestination("chats");

    try {
        const messages = await loadCommunityMessages(community);
        renderMessages(messages, true);
        showNotice("");
    } catch (error) {
        console.error("Could not open community:", error);
        showNotice(`Could not load this community: ${error.message}`, true);
    }
    if (community.kind === "channel" && community.owner_id !== currentUser.id) {
        showNotice("You joined this channel. Only its owner can publish messages.");
    }
    void seedQueuedMessages();
}

async function openConversation(student) {
    if (blockedStudentIds.has(student.id)) {
        showNotice("Unblock this member before opening the conversation.", true);
        return;
    }
    /* Every door into a chat runs through here, so this closes them all
       for a stranger. */
    if (!isMutualFriend(student.id)) {
        showNotice(chatDoorNotice(student), true);
        return;
    }
    if (chatOrganize.isLocked(student.id)) {
        try {
            await chatLock.require(student.id, studentName(student));
        } catch (error) {
            showNotice(error?.message ||
                translate("This chat stays locked until you verify your identity."), true);
            return;
        }
    }
    const loadId = ++conversationLoadId;
    clearPendingReply();
    closeInlineEdit();
    closeMessageMenu();
    olderMessagesRequestId += 1;
    isLoadingOlderMessages = false;
    hasOlderMessages = false;
    displayedMessages = [];
    activeStudent = student;
    if (!allStudents.some(profile => profile.id === student.id)) {
        allStudents.push(student);
    }
    activeCommunity = null;
    markGroupHeaders();
    resetVoiceMessage();
    elements.messaging.classList.remove("show-calls");
    elements.chatName.textContent = studentName(student);
    appendRoleBadge(elements.chatName, student);
    renameContactButton.classList.remove("hidden");
    setAvatarContent(elements.chatAvatar, student);
    openChatActivity(student.id);
    refreshChatStatus();
    elements.messageInput.disabled = false;
    elements.mediaInput.disabled = false;
    elements.sendButton.disabled = false;
    startRecordingButton.disabled = false;
    elements.callActions.classList.remove("hidden");
    elements.messaging.classList.add("chat-open");
    applyAccessMode();
    refreshChatTheme();
    setActiveDestination("chats");
    callManager?.setSelectedStudent(student);
    /* Opening the chat is the promise that its alert was seen, so only that one
       conversation's notification leaves the shade. */
    void dismissMessageAlert(student.id);
    renderStudents();
    /* The saved copy of this chat goes up at once and the network only arrives to
       correct it, so tapping a name opens it instantly the way WhatsApp does. */
    const savedMessages = getCachedConversationMessages(currentUser.id, student.id);
    if (savedMessages?.length) {
        renderMessages(savedMessages, true);
    } else {
        renderEmptyMessage("Loading messages…");
    }

    try {
        const { messages, hasMore } = await loadMessages(student);
        if (loadId !== conversationLoadId || activeStudent?.id !== student.id) return;
        hasOlderMessages = hasMore;
        const previous = latestByStudent.get(student.id);
        latestByStudent.set(student.id, {
            latest: previous?.latest || messages[messages.length - 1],
            unread: 0
        });
        renderMessages(messages, true);
        renderStudents();
        showNotice("");
        elements.messageInput.focus();
    } catch (error) {
        console.error("Could not open conversation:", error);
        const cached = getCachedConversationMessages(currentUser.id, student.id);
        if (cached?.length) {
            hasOlderMessages = false;
            const previous = latestByStudent.get(student.id);
            latestByStudent.set(student.id, {
                latest: previous?.latest || cached[cached.length - 1],
                unread: 0
            });
            renderMessages(cached, true);
            renderStudents();
            showNotice(translate("You appear to be offline. Showing saved messages."));
        } else {
            showNotice(`Could not load this conversation: ${error.message}`, true);
        }
    }
    void seedQueuedMessages();
}

// A shared invite arrives as /messages.html?to=<username> or ?chat=<id>.
// Resolving it through the profiles policy is deliberate: Row Level
// Security decides visibility, so a member who hid from search — or who
// blocked the visitor — simply returns no row.
async function openInvitedChat() {
    const { to, chat } = readInviteParams();
    if (!to && !chat) return;

    const resolve = (columns) => {
        let request = supabase
            .from("profiles")
            .select(columns)
            .neq("id", currentUser.id)
            .limit(1);
        return chat ? request.eq("id", chat) : request.eq("username", to);
    };
    let result = await resolve(profileColumns());
    if (result.error && noteMissingRoleColumn(result.error)) {
        result = await resolve(PROFILE_BASE_COLUMNS);
    }
    const { data, error } = result;

    clearInviteParams();
    if (error) {
        console.error("Could not resolve the invite link:", error);
        reportPartialLoadFailure("the invite link", error);
        return;
    }

    const target = (data || [])[0];
    if (!target) {
        showNotice(translate("This invite link no longer works."), true);
        return;
    }
    await openConversation(target);
}

function renderInvitePanel() {
    const handle = currentUser?.username || "";
    invitePanel.hidden = !currentUser;
    inviteHandle.textContent = handle ? `@${handle}` : translate("Choose a username first");
    inviteLinkOutput.textContent = handle ? buildInviteUrl(handle) : "";
    inviteQrContainer.replaceChildren();
}

/* A send is convert + upload + insert, and any of the three can stall forever
   on a half-dead campus connection. The deadline only fires while nothing at all
   is happening, so a slow-but-moving upload is never killed. */
function withSendDeadline(run) {
    let timer = null;
    let abandon;
    const idle = new Promise((resolve, reject) => { abandon = reject; });
    const keepAlive = () => {
        if (timer !== null) window.clearTimeout(timer);
        timer = window.setTimeout(() => {
            const error = new Error(translate("The connection timed out."));
            error.name = "TimeoutError";
            abandon(error);
        }, SEND_IDLE_TIMEOUT_MS);
    };
    keepAlive();
    return Promise.race([run(keepAlive), idle])
        .finally(() => window.clearTimeout(timer));
}

function insertedMessageSelect(entry) {
    return entry.community
        ? "id, sender_id, content, media_url, created_at"
        : messageSelectColumns();
}

async function deliverMessage(entry, keepAlive) {
    const table = entry.community ? "community_messages" : "messages";
    /* The attachment is uploaded once and kept on the entry: a retry after a
        failed insert must not orphan the first file or upload it a second time. */
    if (entry.file && !entry.mediaUrl) {
        const source = entry.file.type.startsWith("audio/") && !entry.file.name.startsWith("voice-message-")
            ? new File([entry.file], `voice-message-${entry.file.name}`, { type: entry.file.type })
            : entry.file;
        const prepared = await prepareVideoForUpload(source, {
            onStage: (stage, ratio) => {
                if (stage === "loading") {
                    showNotice(translate("Getting the video converter ready..."));
                    return;
                }
                keepAlive();
                showNotice(`${translate("Converting your video so every phone can play it")} ${Math.round(ratio * 100)}%`);
            }
        });
        const uploadSource = await prepareImageForUpload(prepared.file);
        entry.mediaUrl = await uploadCampusMedia(
            supabase,
            currentUser.id,
            uploadSource,
            (sent, total) => {
                keepAlive();
                showNotice(`${translate("Uploading attachment")}: ${Math.round(sent / total * 100)}%`);
            }
        );
        if (prepared.warning) showNotice(translate(prepared.warning), true);
    }

    const replyFields = entry.replySnapshot && replyColumnsAvailable
        ? { reply_to: entry.replySnapshot.message_id, reply_preview: entry.replySnapshot }
        : {};
    const row = entry.community
        ? {
            id: entry.rowId,
            community_id: entry.community.id,
            sender_id: currentUser.id,
            content: entry.content,
            media_url: entry.mediaUrl
        }
        : {
            id: entry.rowId,
            sender_id: currentUser.id,
            receiver_id: entry.recipient.id,
            content: entry.content,
            media_url: entry.mediaUrl,
            ...replyFields
        };
    const runInsert = payload => supabase
        .from(table)
        .insert(payload)
        .select(insertedMessageSelect(entry))
        .single();

    let result = await runInsert(row);
    if (result.error && Object.keys(replyFields).length && isMissingMigrationObject(result.error)) {
        replyColumnsAvailable = false;
        result = await runInsert({ ...row, reply_to: undefined, reply_preview: undefined });
    }
    if (result.error?.code === "23505") {
        /* The row id is made on this device, so a duplicate key can only mean an
           earlier attempt of this same message reached the server after we had
           already given up on it. Re-read it rather than send it twice. */
        const landed = await supabase.from(table)
            .select(insertedMessageSelect(entry))
            .eq("id", entry.rowId)
            .maybeSingle();
        if (!landed.error && landed.data) return landed.data;
    }
    if (result.error) throw result.error;
    return result.data;
}

function pruneFailedSends() {
    for (const [pendingId, entry] of failedSends) {
        if (entry.loadId !== conversationLoadId) failedSends.delete(pendingId);
    }
}

/* A send we gave up on can still land after the timeout. When that row arrives
   from the server, the "not delivered" ghost goes with it. */
function dropLandedSend(message) {
    if (!message?.id) return;
    const pendingId = `pending-${message.id}`;
    if (!failedSends.delete(pendingId)) return;
    displayedMessages = displayedMessages.filter(existing => existing.id !== pendingId);
}

const MAX_OUTBOX_ATTEMPTS = 3;
let outboxFlushInFlight = false;
let outboxFlushAgain = false;

function noopKeepAlive() {}

function outboxSnapshot(entry) {
    return {
        rowId: entry.rowId,
        kind: entry.community ? "community" : "direct",
        recipientId: entry.recipient ? entry.recipient.id : "",
        communityId: entry.community ? entry.community.id : "",
        content: entry.content || "",
        mediaUrl: entry.mediaUrl || "",
        file: entry.file || null,
        replySnapshot: entry.replySnapshot || null,
        createdAt: new Date().toISOString(),
        savedAt: Date.now(),
        attempts: entry.attempts || 0
    };
}

async function queueOutbox(entry) {
    try {
        await savePending(outboxSnapshot(entry));
    } catch (error) {
        console.error("Could not queue the message for retry:", error);
    }
}

function entryFromPending(pending) {
    const recipient = pending.kind === "direct" && pending.recipientId
        ? (allStudents.find(student => student.id === pending.recipientId) || { id: pending.recipientId })
        : null;
    const community = pending.kind === "community" && pending.communityId
        ? { id: pending.communityId }
        : null;
    return {
        rowId: pending.rowId,
        recipient,
        community,
        content: pending.content,
        mediaUrl: pending.mediaUrl || null,
        file: pending.file || null,
        replySnapshot: pending.replySnapshot || null
    };
}

/* Re-send everything the queue holds, oldest first, without touching the
   composer. One run is in flight at a time; a trigger that lands mid-run is
   absorbed by one trailing re-check. After MAX_OUTBOX_ATTEMPTS automatic
   failures an entry is left for the manual tap, so a persistently rejected send
   cannot cause a retry storm. The existing 23505 re-read keeps every attempt
   idempotent, so a queued send can never double-deliver. */
async function flushOutbox() {
    if (outboxFlushInFlight) {
        outboxFlushAgain = true;
        return;
    }
    if (!currentUser || !supabase) return;
    outboxFlushInFlight = true;
    let resent = 0;
    try {
        let anotherPass = true;
        while (anotherPass) {
            anotherPass = false;
            const pendingList = await listPending();
            for (const pending of pendingList) {
                if (outboxFlushAgain) {
                    outboxFlushAgain = false;
                    anotherPass = true;
                    break;
                }
                if ((pending.attempts || 0) >= MAX_OUTBOX_ATTEMPTS) continue;
                try {
                    await deliverMessage(entryFromPending(pending), noopKeepAlive);
                    await clearPending(pending.rowId).catch(() => {});
                    if (pending.kind === "direct" && pending.recipientId) {
                        void announcePush(supabase, {
                            toUser: pending.recipientId,
                            title: currentUser?.username || "Campus Connect",
                            text: pending.content || translate("New message"),
                            thread: pending.recipientId
                        });
                    }
                    resent += 1;
                } catch {
                    await bumpAttempts(pending.rowId).catch(() => {});
                }
            }
        }
    } finally {
        outboxFlushInFlight = false;
    }
    if (resent === 1) showNotice(translate("Re-sent your message."));
    else if (resent > 1) showNotice(translate("Re-sent {n} messages.").split("{n}").join(String(resent)));
}

/* Show a queued send that the automatic retry gave up on, so a message typed
   before the app was put away is still visible and tappable when the chat is
   next opened — not silently lost. Only an at-cap entry gets a ghost; while it
   is still under the retry cap the flush handles it quietly in the background. */
async function seedQueuedMessages() {
    if (!currentUser) return;
    let pendingList;
    try {
        pendingList = await listPending();
    } catch {
        return;
    }
    const mine = pendingList.filter(pending =>
        (activeStudent && pending.kind === "direct" && pending.recipientId === activeStudent.id) ||
        (activeCommunity && pending.kind === "community" && pending.communityId === activeCommunity.id)
    );
    if (!mine.length) return;
    const loadId = conversationLoadId;
    const recipient = activeStudent;
    const community = activeCommunity;
    let ghosts = 0;
    for (const pending of mine) {
        const pendingId = `pending-${pending.rowId}`;
        if (!failedSends.has(pendingId)) {
            failedSends.set(pendingId, {
                pendingId,
                rowId: pending.rowId,
                recipient,
                community,
                content: pending.content,
                file: pending.file || null,
                mediaUrl: pending.mediaUrl || null,
                replySnapshot: pending.replySnapshot || null,
                loadId,
                attempts: pending.attempts || 0,
                isCurrentConversation: () =>
                    loadId === conversationLoadId &&
                    (recipient
                        ? activeStudent && activeStudent.id === recipient.id
                        : activeCommunity && activeCommunity.id === community.id)
            });
        }
        if ((pending.attempts || 0) >= MAX_OUTBOX_ATTEMPTS &&
            !displayedMessages.some(message => message.id === pendingId)) {
            displayedMessages.push({
                id: pendingId,
                sender_id: currentUser.id,
                receiver_id: recipient ? recipient.id : null,
                content: pending.content || "📎",
                media_url: pending.mediaUrl || null,
                created_at: pending.createdAt,
                reply_preview: pending.replySnapshot || null,
                pending: false,
                failed: true
            });
            ghosts += 1;
        }
    }
    if (ghosts) renderMessages(displayedMessages, true);
}

async function attemptSend(entry) {
    failedSends.set(entry.pendingId, entry);
    pruneFailedSends();
    await queueOutbox(entry);
    elements.sendButton.disabled = true;
    showNotice(entry.file && !entry.mediaUrl
        ? translate("Uploading attachment...")
        : translate("Sending..."));
    try {
        const data = await withSendDeadline(keepAlive => deliverMessage(entry, keepAlive));
        failedSends.delete(entry.pendingId);
        await clearPending(entry.rowId).catch(() => {});
        if (entry.replySource && pendingReply === entry.replySource) clearPendingReply();
        if (entry.community) applyGroupMessage(data);
        /* The receiver's phone only rings if their app is shut, and it is the
           server that does the ringing — see supabase/functions/send-push. */
        if (entry.recipient) {
            void announcePush(supabase, {
                toUser: entry.recipient.id,
                title: currentUser?.username || "Campus Connect",
                text: entry.content || translate("New message"),
                thread: entry.recipient.id
            });
        }

        if (entry.isCurrentConversation()) {
            elements.messageInput.value = "";
            elements.mediaInput.value = "";
            resetVoiceMessage();
            elements.messageInput.style.height = "";
            renderMessages([
                ...displayedMessages.filter(message =>
                    message.id !== entry.pendingId && message.id !== data.id
                ),
                data
            ], true);
        }
        if (entry.recipient) {
            const previous = latestByStudent.get(entry.recipient.id);
            latestByStudent.set(entry.recipient.id, {
                latest: data,
                unread: previous?.unread || 0
            });
            renderStudents();
        }
        showNotice("");
    } catch (error) {
        console.error("Could not send message:", error);
        if (entry.isCurrentConversation()) {
            patchDisplayedMessage(entry.pendingId, { pending: false, failed: true });
        }
        showNotice(!navigator.onLine
            ? translate("Queued — will send when you're back online.")
            : error?.name === "TimeoutError"
                ? translate("Message not delivered. Tap it to send again.")
                : `${translate("Message not delivered")}: ${error.message}. ${translate("Tap it to send again.")}`, true);
    } finally {
        elements.sendButton.disabled = false;
        syncComposer();
        if (entry.isCurrentConversation()) elements.messageInput.focus();
    }
}

async function retryFailedSend(pendingId) {
    const entry = failedSends.get(pendingId);
    if (!entry) return;
    if (!entry.isCurrentConversation()) {
        showNotice(translate("Open this chat again to send the message."), true);
        return;
    }
    patchDisplayedMessage(pendingId, { pending: true, failed: false });
    await attemptSend(entry);
}

async function sendMessage(event) {
    event.preventDefault();
    const recipient = activeStudent;
    const community = activeCommunity;

    if (community?.kind === "channel" &&
        community.owner_id !== currentUser.id) {
        showNotice("Only channel owners can publish messages.", true);
        return;
    }
    const content = elements.messageInput.value.trim();
    const file = recordedVoiceFile || elements.mediaInput.files[0];
    if (recordedVoiceFile && elements.mediaInput.files[0]) {
        showNotice("Send the voice message or attached file separately.", true);
        return;
    }
    if (!content && !file) return;
    if (!recipient && !community) {
        showNotice("Open a chat on the left before sending a message.", true);
        return;
    }
    const viewOnceTake = pendingViewOnce && Boolean(file);
    pendingViewOnce = false;
    const sendContent = viewOnceTake ? VIEW_ONCE_MARK + (content || "👻") : content;
    if (sendContent.length > 5000) {
        showNotice("Messages must be 5,000 characters or fewer.", true);
        return;
    }
    if (file) {
        try {
            await validateCampusMedia(file, { knownDurationSeconds: file.durationSeconds });
        } catch (error) {
            showNotice(error.message, true);
            return;
        }
    }
    if (!confirmContentWarning(content, file)) return;

    // The message is on its way: stop the "typing…" line instead of letting it
    // sit for another three seconds.
    chatActivity?.setActivity("");

    const rowId = crypto.randomUUID();
    const pendingId = `pending-${rowId}`;
    const replySource = pendingReply;
    const replySnapshot = replyPreviewFrom(pendingReply);
    const loadId = conversationLoadId;
    const isCurrentConversation = () =>
        loadId === conversationLoadId &&
        (recipient ? activeStudent?.id === recipient.id : activeCommunity?.id === community.id);
    if (isCurrentConversation()) {
        renderMessages([...displayedMessages, {
            id: pendingId,
            sender_id: currentUser.id,
            receiver_id: recipient?.id,
            content: sendContent || (file ? "📎 Uploading attachment…" : ""),
            media_url: null,
            created_at: new Date().toISOString(),
            reply_preview: replySnapshot,
            pending: true
        }], true);
    }
    await attemptSend({
        pendingId,
        rowId,
        recipient,
        community,
        content: sendContent,
        file,
        mediaUrl: null,
        replySource,
        replySnapshot,
        loadId,
        isCurrentConversation
    });
}

function formatClock(ms) {
    const seconds = Math.max(0, Math.floor(ms / 1000));
    return `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, "0")}`;
}

function buildRecorderBars() {
    if (recWave.childElementCount) return;
    for (let index = 0; index < RECORDER_BAR_COUNT; index += 1) {
        recWave.appendChild(document.createElement("i"));
    }
}

function stopLiveWave() {
    if (recorderRaf) window.cancelAnimationFrame(recorderRaf);
    recorderRaf = undefined;
    recorderAnalyser = undefined;
    /* One context per recording, closed with the recording. A context left open
       keeps the phone's audio pipeline awake between takes, and the next clip
       then carries whatever the speaker was still doing. */
    if (recorderContext) {
        recorderContext.close().catch(() => {});
        recorderContext = undefined;
    }
}

function startLiveWave(stream) {
    buildRecorderBars();
    recWave.classList.add("live");
    const bars = [...recWave.children];
    bars.forEach(bar => { bar.style.height = "18%"; });
    try {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (!AudioCtx) return;
        const ctx = new AudioCtx();
        recorderContext = ctx;
        const source = ctx.createMediaStreamSource(stream);
        const analyser = ctx.createAnalyser();
        analyser.fftSize = 128;
        source.connect(analyser);
        recorderAnalyser = analyser;
        const data = new Uint8Array(analyser.frequencyBinCount);
        const tick = () => {
            if (!recorderAnalyser) return;
            recorderAnalyser.getByteFrequencyData(data);
            const step = Math.max(1, Math.floor(data.length / bars.length));
            for (let i = 0; i < bars.length; i += 1) {
                const value = data[i * step] || 0;
                bars[i].style.height = `${Math.max(12, Math.min(100, (value / 255) * 120))}%`;
            }
            recorderRaf = window.requestAnimationFrame(tick);
        };
        tick();
    } catch (error) {
        console.error("Live waveform unavailable:", error);
    }
}

function showRecorder(mode) {
    voiceRecorderMode = mode;
    chatActivity?.setActivity(mode === "recording" ? "recording" : "");
    buildRecorderBars();
    recWave.classList.toggle("live", mode === "recording");
    voiceRecorder.hidden = false;
    elements.messageForm.style.display = "none";
    emojiPicker.style.display = "none";
    recPlay.classList.toggle("mode-recording", mode === "recording");
    recPlay.classList.toggle("mode-review", mode === "review");
    recPlay.classList.remove("playing");
    recPlay.classList.toggle("review", mode === "review");
    recPlay.setAttribute("aria-label", mode === "review" ? "Play recording" : "Stop recording");
    sendVoiceButton.disabled = mode !== "review";
    if (mode === "recording") {
        recTimer.textContent = "0:00";
        [...recWave.children].forEach(bar => { bar.style.height = "18%"; });
    }
}

function hideRecorder() {
    voiceRecorderMode = "hidden";
    chatActivity?.setActivity("");
    stopLiveWave();
    if (voicePreviewAudio) {
        voicePreviewAudio.pause();
        voicePreviewAudio = undefined;
    }
    if (voicePreviewUrl) {
        try { URL.revokeObjectURL(voicePreviewUrl); } catch { /* ignore */ }
        voicePreviewUrl = undefined;
    }
    voiceRecorder.hidden = true;
    elements.messageForm.style.display = "";
    emojiPicker.style.display = "";
    recPlay.classList.remove("review", "mode-recording", "mode-review", "playing");
    sendVoiceButton.disabled = false;
}

function resetVoiceMessage() {
    window.clearInterval(recordingTimer);
    recordingTimer = undefined;
    // The microphone track belongs to the session's warm stream: keep it
    // alive so iOS does not re-prompt on the next recording or call.
    recordingStream = undefined;
    mediaRecorder = undefined;
    recordingChunks = [];
    recordedVoiceFile = undefined;
    recordingStartedAt = undefined;
    hideRecorder();
    syncComposer();
    startRecordingButton.disabled = !currentUser ||
        (!activeStudent && (!activeCommunity ||
            (activeCommunity.kind === "channel" && activeCommunity.owner_id !== currentUser.id)));
}

async function startVoiceRecording() {
    if (!currentUser || (!activeStudent && !activeCommunity) || mediaRecorder) return;
    if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder) {
        showNotice("Voice recording is not supported in this browser. Try a current browser over HTTPS.", true);
        return;
    }

    try {
        recordingStream = await grantRecordingAudio();
        const mimeType = [
            "audio/webm;codecs=opus",
            "audio/ogg;codecs=opus",
            "audio/mp4"
        ].find(type => typeof MediaRecorder.isTypeSupported === "function" &&
            MediaRecorder.isTypeSupported(type));
        const recorder = new MediaRecorder(recordingStream, mimeType ? { mimeType } : undefined);
        mediaRecorder = recorder;
        recordingChunks = [];
        recorder.addEventListener("dataavailable", event => {
            if (event.data.size) recordingChunks.push(event.data);
        });
        recorder.addEventListener("error", event => {
            console.error("Voice recording failed:", event.error);
            showNotice(`Voice recording failed: ${event.error?.message || "microphone error"}`, true);
            resetVoiceMessage();
        });
        recorder.addEventListener("stop", () => {
            if (mediaRecorder !== recorder) return;
            // Warm stream keeps the mic track alive for the next recording or call.
            recordingStream = undefined;
            window.clearInterval(recordingTimer);
            recordingTimer = undefined;
            const durationMs = recordingStartedAt ? Date.now() - recordingStartedAt : 0;
            const blob = new Blob(recordingChunks, { type: recorder.mimeType || "audio/webm" });
            if (!blob.size) {
                showNotice("The voice message was empty. Check your microphone and try again.", true);
                resetVoiceMessage();
                return;
            }
            const extension = recorder.mimeType.includes("ogg") ? "ogg"
                : recorder.mimeType.includes("mp4") ? "m4a" : "webm";
            recordedVoiceFile = new File(
                [blob],
                `voice-message-${Date.now()}.${extension}`,
                { type: recorder.mimeType || "audio/webm" }
            );
            // The clip's own header has no length, but the stopwatch does.
            recordedVoiceFile.durationSeconds = durationMs / 1000;
            enterReviewMode(blob, durationMs);
            syncComposer();
        });
        recorder.start();
        recordingStartedAt = Date.now();
        showRecorder("recording");
        startLiveWave(recordingStream);
        recordingTimer = window.setInterval(() => {
            const elapsed = Date.now() - recordingStartedAt;
            recTimer.textContent = formatClock(elapsed);
            if (elapsed >= MAX_RECORDING_MS && recorder.state === "recording") {
                showNotice("Voice messages are limited to 10 minutes.");
                recorder.stop();
            }
        }, 250);
    } catch (error) {
        console.error("Could not start voice recording:", error);
        resetVoiceMessage();
        // A refused permission must not stay "warm": recording has to ask again
        // so a change made in the phone settings takes effect.
        if (error?.name === "NotAllowedError") stopWarmStream();
        showNotice(`Could not record the voice message: ${permissionHint(error)}`, true);
    }
}

function enterReviewMode(blob, durationMs) {
    stopLiveWave();
    showRecorder("review");
    recTimer.textContent = formatClock(durationMs);
    // Freeze a plausible waveform for the recorded clip.
    const bars = [...recWave.children];
    bars.forEach((bar, index) => {
        const seed = Math.sin(index * 12.9898) * 43758.5453;
        const height = 22 + (seed - Math.floor(seed)) * 70;
        bar.style.height = `${height}%`;
    });
    const url = URL.createObjectURL(blob);
    voicePreviewUrl = url;
    voicePreviewAudio = new Audio(url);
    voicePreviewAudio.addEventListener("ended", () => {
        pauseIconState();
    });
}

function pauseIconState() {
    recPlay.classList.remove("playing");
}

function toggleVoicePreview() {
    if (!voicePreviewAudio) return;
    if (voicePreviewAudio.paused) {
        void voicePreviewAudio.play();
        recPlay.classList.add("playing");
    } else {
        voicePreviewAudio.pause();
        pauseIconState();
    }
}

function stopVoiceRecording() {
    if (mediaRecorder?.state === "recording") mediaRecorder.stop();
}

function discardVoiceRecording() {
    resetVoiceMessage();
}

// ---- WhatsApp Business style composer ------------------------------

const ATTACH_ACCEPT = {
    document: ".pdf,.txt,.csv,.rtf,.doc,.docx,.xls,.xlsx,.ppt,.pptx",
    photo: "image/*",
    gif: "image/gif",
    camera: "image/*"
};

function insertEmoji(emoji) {
    const field = elements.messageInput;
    const start = field.selectionStart ?? field.value.length;
    const end = field.selectionEnd ?? start;
    field.value = field.value.slice(0, start) + emoji + field.value.slice(end);
    field.focus();
    field.selectionStart = field.selectionEnd = start + emoji.length;
    syncComposer();
}


function composerHasContent() {
    return elements.messageInput.value.trim().length > 0 ||
        elements.mediaInput.files.length > 0 ||
        Boolean(recordedVoiceFile);
}

function syncComposer() {
    const hasContent = composerHasContent();
    elements.sendButton.hidden = !hasContent;
    if (!mediaRecorder && !recordedVoiceFile) {
        startRecordingButton.hidden = hasContent;
    }
}

function closeAttachMenu() {
    attachMenu.hidden = true;
    attachButton.setAttribute("aria-expanded", "false");
}

function openFilePicker(kind, options = {}) {
    if (elements.mediaInput.disabled) return;
    closeAttachMenu();
    // Every picker open decides the ghost afresh: a cancelled view-once can
    // never arm a later ordinary photo send.
    pendingViewOnce = Boolean(options.viewOnce);
    elements.mediaInput.accept = ATTACH_ACCEPT[kind] || ATTACH_ACCEPT.document;
    if (kind === "camera") elements.mediaInput.setAttribute("capture", "environment");
    else elements.mediaInput.removeAttribute("capture");
    elements.mediaInput.value = "";
    elements.mediaInput.click();
}

function appendToMessageInput(text) {
    const current = elements.messageInput.value.trim();
    elements.messageInput.value = current ? `${current}\n${text}` : text;
    syncComposer();
    elements.messageInput.focus();
}

function attachCurrentLocation() {
    closeAttachMenu();
    if (!navigator.geolocation) {
        showNotice("This device cannot share a location. Type the place name in the message instead.", true);
        return;
    }
    showNotice("Getting your location…");
    navigator.geolocation.getCurrentPosition(position => {
        const { latitude, longitude } = position.coords;
        const link = `https://maps.google.com/?q=${latitude.toFixed(6)},${longitude.toFixed(6)}`;
        appendToMessageInput(`📍 ${link}`);
    }, error => {
        showNotice(`Could not get your location: ${error.message}. Allow location access and try again.`, true);
    }, { timeout: 12000 });
}

async function attachContact() {
    closeAttachMenu();
    if (navigator.contacts?.select) {
        try {
            const picks = await navigator.contacts.select(["name", "tel"], { multiple: true });
            if (!picks?.length) return;
            const text = picks.map(contact => {
                const name = contact.name?.[0] || "Contact";
                const tel = contact.tel?.[0] || "";
                return tel ? `${name}: ${tel}` : name;
            }).join("\n");
            appendToMessageInput(`👤 ${text}`);
            return;
        } catch (error) {
            console.warn("Contact picker failed:", error);
        }
    }
    showNotice("This device does not let the app read contacts here. Type the name and number in the message.");
}

function buildEmojiPicker() {
    if (emojiPicker.childElementCount) return;
    for (const [name, glyphs] of EMOJI_GROUPS) {
        const section = document.createElement("div");
        section.className = "emoji-section";
        const heading = document.createElement("h4");
        heading.textContent = translate(name);
        const grid = document.createElement("div");
        grid.className = "emoji-grid";
        for (const emoji of Array.from(glyphs)) {
            const button = document.createElement("button");
            button.type = "button";
            button.textContent = emoji;
            button.addEventListener("click", () => insertEmoji(emoji));
            grid.appendChild(button);
        }
        section.append(heading, grid);
        emojiPicker.appendChild(section);
    }
}

attachButton.addEventListener("click", () => {
    attachMenu.hidden = !attachMenu.hidden;
    attachButton.setAttribute("aria-expanded", String(!attachMenu.hidden));
});
document.addEventListener("click", event => {
    if (!attachMenu.hidden && !attachMenu.contains(event.target) && event.target !== attachButton) {
        closeAttachMenu();
    }
});
document.getElementById("attach-document").addEventListener("click", () => openFilePicker("document"));
document.getElementById("attach-photo").addEventListener("click", () => openFilePicker("photo"));
document.getElementById("attach-gif").addEventListener("click", () => openFilePicker("gif"));
document.getElementById("attach-camera").addEventListener("click", () => openFilePicker("photo"));
document.getElementById("attach-location").addEventListener("click", attachCurrentLocation);
document.getElementById("attach-contact").addEventListener("click", attachContact);
document.getElementById("attach-poll").addEventListener("click", openPollDialog);
document.getElementById("attach-view-once").addEventListener("click", openViewOncePicker);
const pollDialogEl = document.getElementById("pollDialog");
if (pollDialogEl) {
    document.getElementById("pollAddOption").addEventListener("click", () => {
        const rows = document.getElementById("pollOptions");
        if (rows) addPollOptionRow(rows, "");
    });
    document.getElementById("pollCreate").addEventListener("click", () => { void createPollFromDialog(); });
    document.getElementById("pollCancel").addEventListener("click", () => pollDialogEl.close());
}
cameraShortcut.addEventListener("click", () => openFilePicker("camera"));
emojiToggle.addEventListener("click", () => {
    buildEmojiPicker();
    emojiPicker.hidden = !emojiPicker.hidden;
});

chatOptionsButton.addEventListener("click", () => {
    const collapsed = chatHeading.classList.toggle("filters-collapsed");
    chatOptionsButton.setAttribute("aria-expanded", String(!collapsed));
});

chatCameraButton.addEventListener("click", () => {
    if (!activeStudent && !activeCommunity) {
        showNotice("Open a chat first, then tap the camera to snap and send.");
        return;
    }
    openFilePicker("camera");
});

chatNewButton.addEventListener("click", () => {
    void openNewChatSheet();
});

callsAddButton.addEventListener("click", () => {
    toggleCallsPicker(!callsPicker.classList.contains("open"));
});

for (const button of document.querySelectorAll("[data-calls-action]")) {
    button.addEventListener("click", () => {
        const action = button.dataset.callsAction;
        if (action === "call") {
            toggleCallsPicker(true);
        } else if (action === "favorites") {
            if (!favoriteStudentIds.size) {
                showNotice(translate("No favorite chats yet. Tap a chat in Chats and use the star."));
            }
            toggleCallsPicker(true, true);
        } else if (action === "keypad") {
            syncDial();
            keypadDialog.showModal();
        } else if (action === "schedule") {
            openScheduleDialog();
        }
    });
}

/* Whether this phone will still ring after the app is closed is the one part of
   Calls the student cannot see for himself, so the menu reports what the service
   actually says instead of making a promise. */
let callWatchCodeShown = "";

async function refreshCallWatchRow() {
    if (!callWatchButton) return;
    const row = callWatchRow(await readCallWatchState(), translate);
    callWatchButton.textContent = row.text;
    // Four states have a phone screen behind them; the rest can only be reported.
    callWatchButton.disabled = !row.opens;
    callWatchCodeShown = row.code;
    void showCallWatchCrash();
    return row;
}

/* A student cannot show us a logcat, so whatever this phone wrote down about the
   last time it stopped by itself is read here, once, and put in the menu he can
   screenshot. */
async function showCallWatchCrash() {
    if (!callCrashLine) return;
    const line = await readCallWatchCrash();
    if (!line) {
        callCrashLine.hidden = true;
        callCrashLine.textContent = "";
        return;
    }
    callCrashLine.textContent = `${translate("The app stopped on its own once:")} ${line}`;
    callCrashLine.hidden = false;
}
callsMenuButton.addEventListener("click", () => {
    callsMenuDialog.showModal();
    void refreshCallWatchRow();
});
callWatchButton?.addEventListener("click", () => {
    void applyCallWatchFix(callWatchCodeShown).then(() => refreshCallWatchRow());
});
/* The fix itself happens outside this app, on a screen of the phone's, so the row
   is read again the moment he comes back rather than waiting for him to think of
   opening the menu a second time. */
document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible" && callsMenuDialog?.open) {
        void refreshCallWatchRow();
    }
});
clearCallHistoryButton.addEventListener("click", () => {
    if (!currentUser) return;
    clearCallLog(currentUser.id);
    // Cleared here means cleared everywhere, or the misses walk straight back.
    void callWatchClearMissed();
    callsMenuDialog.close();
    renderCallHistory();
    showNotice(translate("Call history cleared."));
});

dialPad.addEventListener("click", event => {
    const key = event.target.closest("button[data-digit]");
    if (!key) return;
    dialDisplay.value += key.dataset.digit;
    syncDial();
});
dialDisplay.addEventListener("input", syncDial);
dialCallLink.addEventListener("click", event => {
    if (!digitsOnly(dialDisplay.value)) {
        event.preventDefault();
        return;
    }
    if (dialMatch) {
        event.preventDefault();
        startDialCall();
    }
});
dialFindButton.addEventListener("click", inviteByPhone);

scheduleCallSaveButton.addEventListener("click", () => {
    const student = allStudents.find(item => item.id === scheduleCallContact.value);
    const at = Date.parse(scheduleCallTime.value);
    if (!student) {
        showNotice(translate("Choose a contact to call."), true);
        return;
    }
    if (!Number.isFinite(at) || at <= Date.now()) {
        showNotice(translate("Pick a time in the future."), true);
        return;
    }
    addScheduledCall(currentUser.id, {
        peerId: student.id,
        peerName: studentName(student),
        mode: "voice",
        at
    });
    scheduleCallDialog.close();
    renderCallHistory();
    showNotice(`${translate("Call reminder set for")} ${formatWhen(at)}.`);
});
scheduleCallCancelButton.addEventListener("click", () => scheduleCallDialog.close());

newChatCloseButton.addEventListener("click", () => newChatDialog.close());
newChatContactButton.addEventListener("click", () => {
    newChatResult.textContent = translate("Type a name, @username or phone number.");
    newChatSearch.focus();
});
newChatGroupButton.addEventListener("click", () => {
    newChatDialog.close();
    openGroupPicker("create");
});
chatGroupButton.addEventListener("click", () => openGroupPicker("create"));
groupCreateCloseButton.addEventListener("click", () => groupCreateDialog.close());
groupCreateCancelButton.addEventListener("click", () => groupCreateDialog.close());
groupCreateSaveButton.addEventListener("click", () => void submitGroupPicker());
groupNameField.addEventListener("input", renderGroupPicked);
let groupPickerDebounce;
groupMemberSearch.addEventListener("input", () => {
    window.clearTimeout(groupPickerDebounce);
    const value = groupMemberSearch.value;
    groupPickerDebounce = window.setTimeout(() => renderGroupMemberPicker(value), 160);
});
groupInfoCloseButton.addEventListener("click", () => groupInfoDialog.close());
groupInfoRenameButton.addEventListener("click", () => {
    if (activeCommunity) void renameGroup(activeCommunity);
});
groupInfoAddButton.addEventListener("click", () => {
    if (activeCommunity) openGroupPicker("add", activeCommunity);
});
groupInfoLeaveButton.addEventListener("click", () => {
    if (activeCommunity) void leaveGroup(activeCommunity);
});
groupInfoDeleteButton.addEventListener("click", () => {
    if (activeCommunity) void deleteGroup(activeCommunity);
});
elements.chatName.addEventListener("click", () => {
    if (activeCommunity) void openGroupInfo();
});
elements.chatStatus.addEventListener("click", () => {
    if (activeCommunity) void openGroupInfo();
});
let newChatDebounce;
newChatSearch.addEventListener("input", () => {
    window.clearTimeout(newChatDebounce);
    const value = newChatSearch.value;
    newChatDebounce = window.setTimeout(() => renderNewChatSheet(value), 160);
});

window.addEventListener("campus-connect:call-log-updated", () => {
    if (elements.messaging.classList.contains("show-calls")) renderCallHistory();
    if (activeStudent && !activeCommunity) renderMessages(displayedMessages);
});

window.addEventListener("campus-connect:open-chat", event => {
    const peerId = event.detail?.peerId;
    if (!peerId) return;
    const student = allStudents.find(item => item.id === peerId);
    if (!student) {
        showNotice(translate("That contact is not on Campus Connect yet."), true);
        return;
    }
    elements.messaging.classList.remove("show-calls");
    setActiveDestination("chats");
    void openConversation(student);
});

buildDialKeys();

async function refresh({ refreshProfiles = false } = {}) {
    if (isRefreshing || !currentUser) return;
    isRefreshing = true;

    try {
        await loadStudentsAndConversations({ refreshProfiles });
        if (activeStudent) refreshChatStatus();
        if (activeChatFilter !== "groups" && elements.search.value.trim().length >= 2) {
            await searchMembers(elements.search.value.trim(), "conversations", ++searchRequestId);
        } else if (callsSearch.value.trim().length >= 2) {
            await searchMembers(callsSearch.value.trim(), "calls", ++searchRequestId);
        }
        if (activeStudent) {
            const { messages, hasMore } = await loadMessages(activeStudent);
            hasOlderMessages = hasMore || displayedMessages.length > messages.length;
            renderMessages(mergeCurrentMessages(messages));
        } else if (activeCommunity) {
            const messages = await loadCommunityMessages(activeCommunity);
            renderMessages(messages);
        }
    } catch (error) {
        console.error("Could not refresh messages:", error);
        showNotice(`Could not refresh messages: ${error.message}`, true);
    } finally {
        isRefreshing = false;
    }
}

async function handleRealtimeMessage(message) {
    dropLandedSend(message);
    const otherId = message.sender_id === currentUser.id
        ? message.receiver_id
        : message.sender_id;
    let student = allStudents.find(profile => profile.id === otherId);

    if (!student) {
        const { data, error } = await supabase
            .from("profiles")
            .select("id, username, full_name, course, avatar_url, contact_email, contact_phone, share_email, share_phone")
            .eq("id", otherId)
            .maybeSingle();
        if (error) throw error;
        if (!data) return;
        student = data;
        allStudents.push(student);
    }

    const previous = latestByStudent.get(otherId);
    const latest = !previous || message.created_at > previous.latest.created_at
        ? message
        : previous.latest;
    const isIncoming = message.receiver_id === currentUser.id;
    const isOpenConversation = activeStudent?.id === otherId;
    latestByStudent.set(otherId, {
        latest,
        unread: Math.max(0, previous?.unread || 0) +
            (isIncoming && !isOpenConversation ? 1 : 0)
    });
    renderStudents();

    if (isIncoming && !chatOrganize.isMuted(otherId)) {
        void playMessageTone({ gentle: isOpenConversation });
    }

    /* A message nobody is looking at still has to reach them. The alert is only
       raised while the app is hidden so the phone icon picks up the number, and
       a muted chat keeps its messages to itself. */
    if (isIncoming && !isOpenConversation && document.visibilityState !== "visible" &&
        !chatOrganize.isMuted(otherId)) {
        void notifyIncomingMessage({
            peerId: otherId,
            title: studentName(student),
            body: message.reply_preview?.story_id
                ? `${translate("In reply to your status")}: ${messageSnippet(message)}`
                : messageSnippet(message),
            unread: totalUnread()
        });
    }

    if (isOpenConversation) {
        if (displayedMessages.some(existing => existing.id === message.id)) return;
        const loadId = conversationLoadId;
        const { messages, hasMore } = await loadMessages(student);
        if (loadId !== conversationLoadId || activeStudent?.id !== otherId) return;
        hasOlderMessages = hasMore || displayedMessages.length > messages.length;
        latestByStudent.set(otherId, { latest, unread: 0 });
        renderMessages(mergeCurrentMessages(messages));
        renderStudents();
    }
}

async function handleRealtimeCommunityMessage(message) {
    applyGroupMessage(message);
    if (message.sender_id !== currentUser?.id && groupById(message.community_id)) {
        void playMessageTone({ gentle: activeCommunity?.id === message.community_id });
    }
    if (activeCommunity?.id !== message.community_id) return;
    const community = activeCommunity;
    const messages = await loadCommunityMessages(community);
    if (activeCommunity?.id === community.id) {
        renderMessages(messages);
        if (community.id) void markGroupRead(supabase, community.id);
    }
}

function subscribeToMessageUpdates() {
    messagesChannel = supabase
        .channel(`campus-messages-${currentUser.id}`)
        .on("postgres_changes", {
            event: "INSERT",
            schema: "public",
            table: "messages",
            filter: `receiver_id=eq.${currentUser.id}`
        }, ({ new: message }) => {
            void handleRealtimeMessage(message).catch(error => {
                console.error("Could not process a new message:", error);
            });
        })
        .on("postgres_changes", {
            event: "INSERT",
            schema: "public",
            table: "messages",
            filter: `sender_id=eq.${currentUser.id}`
        }, ({ new: message }) => {
            void handleRealtimeMessage(message).catch(error => {
                console.error("Could not process a sent message update:", error);
            });
        })
        .on("postgres_changes", {
            event: "UPDATE",
            schema: "public",
            table: "messages"
        }, ({ new: message }) => {
            handleRealtimeMessageEdit(message);
        })
        .on("postgres_changes", {
            event: "INSERT",
            schema: "public",
            table: "community_messages"
        }, ({ new: message }) => {
            void handleRealtimeCommunityMessage(message).catch(error => {
                console.error("Could not process a community message:", error);
            });
        })
        .subscribe(status => {
            const wasConnected = messagesRealtimeConnected;
            messagesRealtimeConnected = status === "SUBSCRIBED";
            if (messagesRealtimeConnected && !wasConnected) void refresh();
        });
}

function stopMessageUpdates() {
    messagesRealtimeConnected = false;
    if (!messagesChannel || !supabase) return;
    void supabase.removeChannel(messagesChannel).catch(error => {
        console.error("Could not stop message updates:", error);
    });
    messagesChannel = undefined;
}

// A "SUBSCRIBED" realtime channel only proves the socket opened, not that the
// database is publishing changes. Keep polling so chats still update when
// realtime is silently unavailable.
function startMessageRefreshTimers() {
    if (!refreshTimer) {
        refreshTimer = window.setInterval(() => {
            if (document.visibilityState !== "visible") return;
            void updateLastSeen();
            void loadStudentsAndConversations({ refreshProfiles: true }).catch(error => {
                console.error("Could not refresh student presence:", error);
                showNotice(`Could not refresh student presence: ${error.message}`, true);
            });
        }, REFRESH_INTERVAL_MS);
    }
    if (!messagesPollTimer) {
        messagesPollTimer = window.setInterval(() => {
            if (document.visibilityState !== "visible") return;
            void refresh();
        }, MESSAGE_POLL_INTERVAL_MS);
    }
}

function renderThemeLabel(dark) {
    elements.themeToggle.textContent = translate(dark ? "☀️ Day Mode" : "🌙 Night Mode");
    elements.themeToggle.setAttribute("aria-pressed", String(dark));
}

function applyTheme() {
    renderThemeLabel(initializeTheme(renderThemeLabel));
}

function toggleTheme() {
    renderThemeLabel(toggleThemeMode());
    /* Every palette has a day and a night side, so switching modes has to
       repaint the chat and the colour cards with it. */
    if (chatPanel?.hasAttribute("data-chat-theme")) refreshChatTheme();
    else renderColourSwatches();
}

async function initialize() {
    applyTheme();
    applyAccessMode();

    try {
        ({ supabase } = await import("../lib/supabase.js"));
        ({ uploadCampusMedia, validateCampusMedia, prepareImageForUpload } = await import("../lib/media.js"));
        ({ prepareVideoForUpload } = await import("../lib/video-convert.js"));
        clearPreloadRetry();
        const boot = await resolveBootUser(supabase);
        if (boot.error && !boot.user && navigator.onLine) throw boot.error;

        currentUser = boot.user;
        applyAccessMode();
        setOfflineBanner(boot.offline);
        if (sendMembersToBulletin(currentUser)) return;
        renderInvitePanel();
        void updateLastSeen();
        /* The staff role is one round trip and the screens behind it have no
           reason to stand still while it lands: it flies on its own and hands
           the staff tools over the moment it arrives. */
        const staffRolePromise = loadMyStaffRole().catch(() => {});
        staffRolePromise.then(() => { void ensureStaffAccess(); });
        const bottomNav = document.querySelector(".bottom-nav");
        bottomNav.hidden = !currentUser;
        if (!currentUser) {
            if (window.location.hash === "#calls") {
                window.history.replaceState({}, document.title, window.location.pathname + window.location.search);
            }
            showNotice("You need an account to chat.");
            renderEmptyMessage("Sign in to Campus Connect to message your friends.", true);
            elements.conversationList.replaceChildren();
            chatFilterButtons.find(button => button.dataset.chatFilter === "groups").disabled = true;
            for (const control of elements.communityForm.elements) {
                control.disabled = true;
            }
            elements.communitiesList.textContent = "Sign in to discover or create groups and channels.";
            return;
        }

        appLock?.destroy();
        await runUiStep("app lock", async () => {
            appLock = initializeAppLock(
                document.getElementById("biometric-lock-toggle"),
                currentUser.id
            );
        });
        document.getElementById("biometric-lock-toggle").hidden = false;

        /* Archived, muted and locked chats have to be known before the list
           paints, otherwise a hidden chat flashes on screen for a moment. That
           rule stands - but the reading of those settings starts here beside
           the list's own round trips, and the list waits for it before it
           paints, instead of the whole boot waiting for it before the list
           even asked for anything. */
        const organizePromise = chatOrganize.load().catch(error => {
            reportPartialLoadFailure("your chat settings", error);
        });

        favoriteStorageKey = `campus-favorite-chats:${currentUser.id}`;
        try {
            const savedFavorites = JSON.parse(localStorage.getItem(favoriteStorageKey) || "[]");
            if (Array.isArray(savedFavorites) && savedFavorites.every(id => typeof id === "string")) {
                favoriteStudentIds = new Set(savedFavorites);
            }
        } catch (error) {
            console.error("Could not load favorite chats:", error);
            showNotice(`Could not load favorite chats: ${error.message}`, true);
        }
        pendingChatInviteStorageKey = `campus-pending-chat-invites:${currentUser.id}`;
        pendingChatInviteIds = new Set();
        try {
            const savedInvites = JSON.parse(localStorage.getItem(pendingChatInviteStorageKey) || "[]");
            if (Array.isArray(savedInvites) && savedInvites.every(id => typeof id === "string")) {
                pendingChatInviteIds = new Set(savedInvites);
            }
        } catch (error) {
            console.error("Could not load pending chat invitations:", error);
            showNotice(`Could not load pending chat invitations: ${error.message}`, true);
        }

        if (window.location.hash === "#calls") {
            elements.messaging.classList.add("show-calls");
            setActiveDestination("calls");
            renderCallHistory();
        }

        startMessageRefreshTimers();
        await runUiStep("conversation list", async () => {
            await loadStudentsAndConversations({
                organizeReady: organizePromise,
                staffReady: staffRolePromise
            });
            refreshChatTheme();
        });
        void loadCommunitiesSafely();
        void flushOutbox();
        /* The found-document row belongs in the same list, so it is read on the
           same pass and never blocks the chats a student came here to open. */
        void refreshFoundChats();
        void loadNavProfilePhoto();
        applyRequestedChatFilter();
        await runUiStep("calls and live message updates", async () => {
            /* These two do not depend on each other, so they run side by side and
               the page is interactive a round trip sooner. */
            await Promise.all([
                (async () => {
                    callManager = createCallManager(supabase, currentUser, showNotice);
                    renderCallHistory();
                    startScheduledCallTimer();
                    void refreshNativeMisses();
                })(),
                subscribeToMessageUpdates()
            ]);
        });
        /* Asked here rather than on first launch so the prompt appears while the
           student is actually looking at the chats. */
        void askNotificationPermission();
        /* Push is the half that keeps working once the app is shut. When a
           notification is tapped the list is simply re-read, because the phone
           may have missed several messages while it was asleep. */
        /* Until a Firebase project exists, the APK carries its own listener with
           no WebView in it. This is the hand-off that lets a call still ring
           after the student swipes the app away - and the menu row that tells him
           whether it actually worked on his phone. */
        void startCallWatch();
        void refreshCallWatchRow();
        /* Both kinds of alert name the person it came from, so an alert that was
           tapped opens that conversation instead of dropping the student back on
           the list. */
        const openChatForPeer = peerId => {
            if (!/^[0-9a-f-]{36}$/i.test(String(peerId || ""))) return;
            const params = new URLSearchParams(window.location.search);
            params.set("chat", peerId);
            window.history.replaceState({}, document.title,
                `${window.location.pathname}?${params.toString()}`);
            void openInvitedChat();
        };
        void registerPush(supabase, data => {
            if (currentUser && !activeStudent && !activeCommunity) {
                void loadStudentsAndConversations().catch(() => {});
            }
            if (data?.kind === "call") {
                /* A live offer on this very phone needs no notice - the ringing
                   dialog is already up, and "call them back" would contradict it. */
                if (callManager?.hasLiveOffer()) return;
                /* A phone that wakes from a push cannot answer a call that was
                   offered a minute ago, so the honest move is to put the two of
                   them in the chat and say what happened. */
                showNotice(translate("They called while this phone was away from the app. Call them back."), true);
                openChatForPeer(data.from || data.thread);
                return;
            }
            if (!activeStudent && !activeCommunity) openChatForPeer(data?.from || data?.thread);
        }).then(result => {
            /* Push and the Android watch are two ways of saying the same thing, so
               the moment Firebase proves it holds this phone the watch is told to
               stop speaking. Nothing changes while push is missing. */
            void markCallWatchPush(result);
        });
        renderInvitePanel();
        /* Tapping a chat's own alert should open that conversation rather than
           drop the student back on the list. */
        void watchNotificationChatTap(openChatForPeer);
        /* A ringing alert wakes the phone carrying the call it woke him for, and
           until now nothing on this page ever asked for it: the watch handed the
           name over, the page dropped it, and only a link shaped ?call=<id> -
           which the APK never builds - said anything. So a phone woken to a call
           that had already gone came back to a silent chat list. Both ways in
           now land the same way, and only once. */
        let wokenCallSaid = false;
        const announceWokenCall = (callId, peerId) => {
            if (!callId || wokenCallSaid) return;
            window.setTimeout(() => {
                /* Only speak once this page has actually reached the signalling
                   table - otherwise a slow load announces a call one second
                   before its own ringing dialog shows up for it. */
                if (!callManager?.heardFromSignaling()) return;
                if (callManager?.hasLiveOffer()) return;
                wokenCallSaid = true;
                showNotice(translate("They called while this phone was away from the app. Call them back."), true);
                if (peerId) openChatForPeer(peerId);
            }, 5000);
        };
        const wokenParams = new URLSearchParams(window.location.search);
        announceWokenCall(wokenParams.get("call"), wokenParams.get("peer"));
        void callWatchLaunchTarget().then(woken => announceWokenCall(woken.callId, woken.peerId));
        await runUiStep("chat invitation", async () => {
            await openInvitedChat();
        });
        void updateLastSeen();
    } catch (error) {
        console.error("Could not initialize messaging:", error);
        const reason = error.message || "Could not connect to Campus Connect.";
        showNotice(reason, true);
        renderEmptyMessage(`Messaging could not connect: ${reason}`);
        if (currentUser) {
            void loadStudentsAndConversations().then(loadCommunitiesSafely).catch(() => {});
        }
    }
}

window.addEventListener("offline", () => {
    showNotice(translate("You appear to be offline. Showing saved chats and messages."));
    if (currentUser && !activeStudent && !activeCommunity) {
        restoreOfflineChats();
    }
});

window.addEventListener("online", () => {
    if (!currentUser) return;
    showNotice("");
    void loadStudentsAndConversations().catch(() => {});
    void flushOutbox();
});

elements.search.addEventListener("input", () => {
    if (activeChatFilter === "groups") {
        renderCommunities();
    } else {
        students = allStudents;
        renderStudents();
        const query = normalizeMemberSearch(elements.search.value);
        if (query.length >= 2 || genderSearch.value) {
            scheduleMemberSearch(query, "conversations");
        } else {
            searchRequestId += 1;
        }
    }
});

document.getElementById("conversation-search-form").addEventListener("submit", event => {
    event.preventDefault();
    const query = normalizeMemberSearch(elements.search.value);
    elements.search.value = query;
    if (activeChatFilter === "groups") {
        renderCommunities();
    } else if (query || genderSearch.value) {
        window.clearTimeout(searchDebounceTimer);
        void searchMembers(query, "conversations", ++searchRequestId);
    } else {
        searchRequestId += 1;
        students = allStudents;
        renderStudents();
    }
});

genderSearch.addEventListener("change", () => {
    const query = normalizeMemberSearch(elements.search.value);
    if (query.length >= 2 || genderSearch.value) {
        window.clearTimeout(searchDebounceTimer);
        void searchMembers(query, "conversations", ++searchRequestId);
    } else {
        searchRequestId += 1;
        students = allStudents;
        renderStudents();
    }
});

callsGenderSearch.addEventListener("change", () => {
    const query = normalizeMemberSearch(callsSearch.value);
    if (query.length >= 2 || callsGenderSearch.value) {
        window.clearTimeout(searchDebounceTimer);
        void searchMembers(query, "calls", ++searchRequestId);
    } else {
        searchRequestId += 1;
        renderCallDirectory(visibleCallContacts());
    }
});

document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible" && currentUser) {
        void updateLastSeen();
        void refresh({ refreshProfiles: true });
        void flushOutbox();
    }
});
callsSearch.addEventListener("input", () => {
    const query = normalizeMemberSearch(callsSearch.value);
    if (query.length >= 2 || callsGenderSearch.value) {
        scheduleMemberSearch(query, "calls");
    } else {
        searchRequestId += 1;
        renderCallDirectory(visibleCallContacts());
    }
});
async function selectChatFilter(button) {
    activeChatFilter = button.dataset.chatFilter;
    chatFilterButtons.forEach(filterButton => {
        filterButton.setAttribute(
            "aria-pressed",
            String(filterButton === button)
        );
    });
    const showGroups = activeChatFilter === "groups";
    /* The Groups tab keeps the discover panel, but my own groups stay in the
       list above it: a group you are already in belongs where you look for a
       conversation, not behind a search. */
    elements.communityPanel.classList.toggle("hidden", !showGroups);
    elements.search.placeholder = translate(showGroups
        ? "Search groups and channels..."
        : "Search members and universities...");
    elements.search.setAttribute("aria-label", translate(showGroups
        ? "Search groups and channels"
        : "Search members by name, username, or university."));
    elements.search.value = "";
    searchRequestId += 1;

    students = allStudents;
    renderStudents();

    if (showGroups) {
        try {
            await loadCommunities();
        } catch (error) {
            console.error("Could not load groups and channels:", error);
            elements.communityNotice.textContent = `Could not load communities: ${error.message}`;
            elements.communityNotice.classList.add("error");
        }
    }
}

chatFilterButtons.forEach(button => {
    button.addEventListener("click", () => selectChatFilter(button));
});

// The Profile tab links straight to a filter, so honour it when the page loads.
function applyRequestedChatFilter() {
    const params = new URLSearchParams(window.location.search);
    const wanted = params.get("filter");
    const button = chatFilterButtons.find(item => item.dataset.chatFilter === wanted);
    if (!button || wanted === "all") return;
    params.delete("filter");
    const query = params.toString();
    window.history.replaceState({}, document.title, `${window.location.pathname}${query ? `?${query}` : ""}`);
    void selectChatFilter(button);
}
document.addEventListener("campus-connect:language-change", () => {
    applyTheme();
    renderStudents();
    renderCommunities();
    renderCallDirectory(allStudents);
});
elements.communityForm.addEventListener("submit", async event => {
    event.preventDefault();
    const name = document.getElementById("community-name").value.trim();
    const description = document.getElementById("community-description").value.trim();
    const kind = document.getElementById("community-kind").value;
    const button = document.getElementById("create-community-button");
    if (name.length < 3 || name.length > 80 || description.length > 500) {
        elements.communityNotice.textContent = "Names must be 3–80 characters and descriptions no longer than 500.";
        elements.communityNotice.classList.add("error");
        return;
    }

    button.disabled = true;
    elements.communityNotice.classList.remove("error");
    elements.communityNotice.textContent = "Creating...";
    try {
        const { data: communityId, error } = await supabase.rpc("create_community", {
            p_name: name,
            p_description: description,
            p_kind: kind
        });
        if (error) throw error;
        elements.communityForm.reset();
        await loadCommunities();
        const created = communities.find(community => community.id === communityId);
        if (!created) throw new Error("Community was created but is not visible. Refresh and try again.");
        elements.communityNotice.textContent = "Community created.";
        await openCommunity(created);
    } catch (error) {
        console.error("Could not create community:", error);
        elements.communityNotice.textContent = `Could not create community: ${error.message}`;
        elements.communityNotice.classList.add("error");
    } finally {
        button.disabled = false;
    }
});
elements.communitiesList.addEventListener("click", async event => {
    const button = event.target.closest("button[data-action]");
    if (!button) return;
    const community = communities.find(item => item.id === button.dataset.id);
    if (!community) return;
    button.disabled = true;
    elements.communityNotice.classList.remove("error");
    try {
        if (button.dataset.action === "join") {
            const { error } = await supabase.from("community_members").insert({
                community_id: community.id,
                user_id: currentUser.id,
                role: "member"
            });
            if (error) throw error;
            await loadCommunities();
            await openCommunity(community);
        } else if (button.dataset.action === "leave") {
            const { error } = await supabase.from("community_members")
                .delete()
                .eq("community_id", community.id)
                .eq("user_id", currentUser.id);
            if (error) throw error;
            if (activeCommunity?.id === community.id) {
                activeCommunity = null;
                elements.messaging.classList.remove("chat-open");
                renderEmptyMessage("You left this community.");
            }
            await loadCommunities();
        } else {
            await openCommunity(community);
        }
    } catch (error) {
        console.error("Could not update community membership:", error);
        elements.communityNotice.textContent = `Could not update this community: ${error.message}`;
        elements.communityNotice.classList.add("error");
    } finally {
        button.disabled = false;
    }
});
callsSearch?.addEventListener("input", () => {
    renderCallDirectory(allStudents);
});
document.getElementById("calls-search-form").addEventListener("submit", event => {
    event.preventDefault();
    const query = normalizeMemberSearch(callsSearch.value);
    callsSearch.value = query;
    if (query || genderSearch.value) {
        window.clearTimeout(searchDebounceTimer);
        void searchMembers(query, "calls", ++searchRequestId);
    } else {
        searchRequestId += 1;
        renderCallDirectory(visibleCallContacts());
    }
});
document.querySelector('[data-destination="calls"]').addEventListener("click", () => {
    if (!currentUser) {
        window.location.assign("/");
        return;
    }
    elements.messaging.classList.remove("chat-open");
    elements.messaging.classList.add("show-calls");
    setActiveDestination("calls");
    renderCallHistory();
    if (callsPicker.classList.contains("open")) renderCallDirectory(visibleCallContacts());
});
document.querySelectorAll(".bottom-nav [data-destination]").forEach(link => {
    link.addEventListener("click", () => {
        if (link.dataset.destination !== "calls") {
            setActiveDestination(link.dataset.destination);
        }
    });
});
function setActiveDestination(destination) {
    document.querySelectorAll(".bottom-nav [data-destination]").forEach(link => {
        const active = link.dataset.destination === destination;
        link.classList.toggle("active", active);
        if (link.tagName === "A") {
            if (active) link.setAttribute("aria-current", "page");
            else link.removeAttribute("aria-current");
        } else {
            link.setAttribute("aria-pressed", String(active));
        }
    });
}
elements.messageForm.addEventListener("submit", sendMessage);
blockChatMemberButton.addEventListener("click", () => {
    if (activeStudent) void toggleBlock(activeStudent);
});
startRecordingButton.addEventListener("click", event => {
    event.preventDefault();
    if (startRecordingButton.disabled || mediaRecorder) return;
    void startVoiceRecording();
});
startRecordingButton.addEventListener("contextmenu", event => event.preventDefault());
recPlay.addEventListener("click", () => {
    if (voiceRecorderMode === "recording") stopVoiceRecording();
    else if (voiceRecorderMode === "review") toggleVoicePreview();
});
sendVoiceButton.addEventListener("click", () => {
    if (voiceRecorderMode === "recording") stopVoiceRecording();
    else elements.messageForm.requestSubmit();
});
discardVoiceButton.addEventListener("click", discardVoiceRecording);
document.getElementById("close-member-profile").addEventListener("click", () => {
    memberProfileDialog.close();
});
messageMemberProfileButton.addEventListener("click", async () => {
    if (!memberProfileStudent) return;
    const student = memberProfileStudent;
    memberProfileDialog.close();
    await openConversation(student);
});
copyInviteLinkButton.addEventListener("click", () => {
    void copyLink(buildInviteUrl(currentUser?.username));
});
shareInviteLinkButton.addEventListener("click", () => {
    void shareMyInvite(currentUser?.username).catch(error => {
        console.error("Could not share the invite link:", error);
        showNotice(`Could not share your invite link: ${error.message}`, true);
    });
});
invitePanel.addEventListener("toggle", () => {
    if (!invitePanel.open || !currentUser || inviteQrContainer.childElementCount) return;
    void renderInviteQr(inviteQrContainer, buildInviteUrl(currentUser.username));
});
elements.messageInput.addEventListener("keydown", event => {
    if (event.key === "Enter" && !event.shiftKey && !event.isComposing) {
        event.preventDefault();
        elements.messageForm.requestSubmit();
    }
});
elements.messageInput.addEventListener("input", () => {
    elements.messageInput.style.height = "auto";
    elements.messageInput.style.height = `${Math.min(elements.messageInput.scrollHeight, 130)}px`;
    if (elements.messageInput.value.trim()) chatActivity?.noteTyping();
    syncComposer();
});
elements.mediaInput.addEventListener("change", syncComposer);
elements.mediaInput.addEventListener("cancel", () => { pendingViewOnce = false; });
document.getElementById("back-button").addEventListener("click", () => {
    elements.messaging.classList.remove("chat-open");
});
elements.themeToggle.addEventListener("click", toggleTheme);
document.getElementById("logout-button").addEventListener("click", async () => {
    if (!supabase) {
        window.location.assign("/");
        return;
    }

    /* This has to happen before signOut: the row is owned by the session, and
       after it is gone the next student to hold this phone would keep
       receiving the previous one's alerts. */
    await forgetPush(supabase);
    /* Same reason as the push token: the call watch polls with this session, and
       the next student to hold this phone must not inherit it. */
    await stopCallWatch();
    const { error } = await supabase.auth.signOut();
    if (error) {
        console.error("Could not sign out:", error);
        showNotice(`Could not sign out: ${error.message}`, true);
        return;
    }
    forgetOfflineUser();
    clearUserChatCache(currentUser?.id);
    clearUserChatFlags(currentUser?.id);
    clearUserChatTheme(currentUser?.id);
    clearChatTheme(chatPanel);
    void clearUserSnapshots(currentUser?.id);
    currentUser = null;
    callManager?.dispose();
    stopMessageUpdates();
    appLock?.destroy();
    appLock = null;
    window.location.assign("/");
});
window.addEventListener("beforeunload", () => {
    window.clearInterval(refreshTimer);
    window.clearInterval(messagesPollTimer);
    window.clearInterval(recordingTimer);
    // The warm stream releases itself on pagehide (media-grant.js).
    callManager?.dispose();
    stopMessageUpdates();
});

initialize();
